var require = meteorInstall({"lib":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/collections.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Mongo Collections                                                                                                  //
Spheres = new Mongo.Collection('spheres');                                                                            // 2
Providers = new Mongo.Collection('providers');                                                                        // 3
Consumers = new Mongo.Collection('consumers');                                                                        // 4
ConsumersByUser = new Mongo.Collection('consumersByUser');                                                            // 5
ProvidersByUser = new Mongo.Collection('providersByUser');                                                            // 6
Attributes = new Mongo.Collection('attributes');                                                                      // 7
AttributesDefinition = new Mongo.Collection('attributesDefinition');                                                  // 8
                                                                                                                      //
ConsumersInSphere = new Mongo.Collection('consumersInSphere');                                                        // 10
CategoriesByProviders = new Mongo.Collection('categoriesByProviders');                                                // 11
AttributesByProviders = new Mongo.Collection('attributesByProviders');                                                // 12
AttributesBySphere = new Mongo.Collection('attributesBySphere');                                                      // 13
SpheresByUser = new Mongo.Collection('spheresByUser');                                                                // 14
                                                                                                                      //
RegisteredEmails = new Mongo.Collection('registeredEmails');                                                          // 16
RegisteredIds = new Mongo.Collection('registeredIds');                                                                // 17
Entities = new Mongo.Collection('entities');                                                                          // 18
                                                                                                                      //
EntitiesRequestedFromEntities = new Mongo.Collection('entitiesRequestedFromEntities');                                // 21
EntitiesRequestedFromUsers = new Mongo.Collection('entitiesRequestedFromUsers');                                      // 22
AdminEntities = new Mongo.Collection('adminEntities');                                                                // 23
EntitiesAssociated = new Mongo.Collection('entitiesAssociated');                                                      // 24
                                                                                                                      //
EntitiesWithRelationship = new Mongo.Collection('entitiesWithRelationship');                                          // 26
PeopleWithRelationship = new Mongo.Collection('peopleWithRelationship');                                              // 27
                                                                                                                      //
UsersRequestedFromEntities = new Mongo.Collection('usersRequestedFromEntities');                                      // 29
UsersRequestedFromUsers = new Mongo.Collection('usersRequestedFromUsers');                                            // 30
AdminUsers = new Mongo.Collection('adminUsers');                                                                      // 31
UsersAssociated = new Mongo.Collection('usersAssociated');                                                            // 32
                                                                                                                      //
People = new Mongo.Collection('people');                                                                              // 34
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/routes.js                                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
// Router configuration                                                                                               //
Router.configure({                                                                                                    // 3
  loadingTemplate: 'loading_purple',                                                                                  // 4
  defaultBreadcrumbTitle: 'Home',                                                                                     // 5
  defaultBreadcrumbLastLink: true                                                                                     // 6
});                                                                                                                   // 3
                                                                                                                      //
//Routers                                                                                                             //
Router.route('/', {                                                                                                   // 10
  name: 'login',                                                                                                      // 11
  template: 'index'                                                                                                   // 12
});                                                                                                                   // 10
                                                                                                                      //
Router.route('/index', {                                                                                              // 15
  name: 'index',                                                                                                      // 16
  template: 'index'                                                                                                   // 17
});                                                                                                                   // 15
                                                                                                                      //
Router.route('/register', {                                                                                           // 20
  waitOn: function waitOn() {                                                                                         // 21
    return Meteor.subscribe('getRegisteredEmailsandRegisteredIds');                                                   // 22
  }                                                                                                                   // 23
});                                                                                                                   // 20
                                                                                                                      //
Router.route('/home');                                                                                                // 26
                                                                                                                      //
Router.route('/my_spheres', {                                                                                         // 28
  template: 'my_spheres',                                                                                             // 29
  parent: 'home',                                                                                                     // 30
  title: 'My Spheres',                                                                                                // 31
  waitOn: function waitOn() {                                                                                         // 32
    var user = Session.get('user');                                                                                   // 33
    var spheresUrl = user._links.spheres.href;                                                                        // 34
    return Meteor.subscribe('getSpheresByUser', spheresUrl);                                                          // 35
  }                                                                                                                   // 36
});                                                                                                                   // 28
                                                                                                                      //
Router.route('/new_sphere', {                                                                                         // 39
  name: 'new_sphere',                                                                                                 // 40
  template: 'new_sphere',                                                                                             // 41
  title: 'new Sphere',                                                                                                // 42
  parent: 'my_spheres',                                                                                               // 43
  waitOn: function waitOn() {                                                                                         // 44
    var user = Session.get('user');                                                                                   // 45
    var providersUrl = user._links.providers.href;                                                                    // 46
    var consumersUrl = user._links.consumers.href;                                                                    // 47
    var attributes = Attributes.find().fetch();                                                                       // 48
    var providers = ProvidersByUser.find().fetch();                                                                   // 49
    var providerLinks = [];                                                                                           // 50
                                                                                                                      //
    var providerNames = [];                                                                                           // 52
                                                                                                                      //
    for (p in providers) {                                                                                            // 54
      var provider = providers[p];                                                                                    // 55
      var providerLink = provider.attributesLink;                                                                     // 56
      providerLinks.push(providerLink);                                                                               // 57
      providerNames.push(provider.name);                                                                              // 58
    }                                                                                                                 // 59
                                                                                                                      //
    var sphere = Session.get('sphere');                                                                               // 61
    var sphereAttributesUrl = null;                                                                                   // 62
    var sphereConsumerUrl = null;                                                                                     // 63
    if (sphere != null) {                                                                                             // 64
      sphereAttributesUrl = sphere._links.attributes.href;                                                            // 65
      sphereConsumerUrl = sphere._links.consumers.href;                                                               // 66
    }                                                                                                                 // 67
                                                                                                                      //
    var sphereUserUrl = user._links.spheres.href;                                                                     // 69
                                                                                                                      //
    return [Meteor.subscribe('getProvidersByUser', providersUrl), Meteor.subscribe('getAttributesByProviders', providerNames), Meteor.subscribe('getAttributesBySphere', sphereAttributesUrl), Meteor.subscribe('getConsumersByUser', consumersUrl), Meteor.subscribe('getConsumersInSphere', sphereConsumerUrl)];
  }                                                                                                                   // 78
});                                                                                                                   // 39
                                                                                                                      //
Router.route('/my_providers', {                                                                                       // 81
  template: 'my_providers',                                                                                           // 82
  title: 'My Providers',                                                                                              // 83
  parent: 'home'                                                                                                      // 84
});                                                                                                                   // 81
                                                                                                                      //
Router.route('/new_provider', {                                                                                       // 87
  template: 'new_provider',                                                                                           // 88
  title: 'New Provider',                                                                                              // 89
  parent: 'my_providers',                                                                                             // 90
  waitOn: function waitOn() {                                                                                         // 91
    var user = Session.get('user');                                                                                   // 92
    var providersUrl = user._links.providers.href;                                                                    // 93
    return [Meteor.subscribe('getProviders'), Meteor.subscribe('getProvidersByUser', providersUrl)];                  // 94
  }                                                                                                                   // 97
});                                                                                                                   // 87
                                                                                                                      //
Router.route('/my_consumers', {                                                                                       // 100
  template: 'my_consumers',                                                                                           // 101
  parent: 'home',                                                                                                     // 102
  title: 'Consumers'                                                                                                  // 103
});                                                                                                                   // 100
                                                                                                                      //
Router.route('/new_consumer', {                                                                                       // 106
  template: 'new_consumer',                                                                                           // 107
  title: 'New Consumer',                                                                                              // 108
  parent: 'my_consumers',                                                                                             // 109
  waitOn: function waitOn() {                                                                                         // 110
    var user = Session.get('user');                                                                                   // 111
    var consumersUrl = user._links.consumers.href;                                                                    // 112
    return [Meteor.subscribe('getConsumers'), Meteor.subscribe('getConsumersByUser', consumersUrl)];                  // 113
  }                                                                                                                   // 117
});                                                                                                                   // 106
                                                                                                                      //
Router.route('/my_profile', {                                                                                         // 120
  template: 'my_profile',                                                                                             // 121
  title: 'My Profile',                                                                                                // 122
  parent: 'home',                                                                                                     // 123
  data: function data() {                                                                                             // 124
    return Session.get('user');                                                                                       // 125
  }                                                                                                                   // 126
});                                                                                                                   // 120
                                                                                                                      //
Router.route('/my_entities', {                                                                                        // 129
  template: 'my_entities',                                                                                            // 130
  title: 'My Entities',                                                                                               // 131
  parent: 'home'                                                                                                      // 132
});                                                                                                                   // 129
                                                                                                                      //
Router.route('/new_entity', {                                                                                         // 135
  template: 'new_entity',                                                                                             // 136
  title: 'New Entity',                                                                                                // 137
  parent: 'my_entities',                                                                                              // 138
  waitOn: function waitOn() {                                                                                         // 139
    var userEmail = Session.get('user').email;                                                                        // 140
    return [Meteor.subscribe('getEntities'), Meteor.subscribe('getEntitiesWithRelationship', userEmail)];             // 141
  }                                                                                                                   // 145
});                                                                                                                   // 135
                                                                                                                      //
Router.route('/entity_profile', {                                                                                     // 148
  template: 'entity_profile',                                                                                         // 149
  title: 'Entity Profile',                                                                                            // 150
  parent: 'home',                                                                                                     // 151
  data: function data() {                                                                                             // 152
    return Session.get('user');                                                                                       // 153
  }                                                                                                                   // 154
});                                                                                                                   // 148
                                                                                                                      //
Router.route('/people', {                                                                                             // 157
  template: 'people',                                                                                                 // 158
  title: 'People',                                                                                                    // 159
  parent: 'home',                                                                                                     // 160
  data: function data() {                                                                                             // 161
    return Session.get('user');                                                                                       // 162
  }                                                                                                                   // 163
});                                                                                                                   // 157
                                                                                                                      //
Router.route('/new_person', {                                                                                         // 166
  template: 'new_person',                                                                                             // 167
  title: 'New User',                                                                                                  // 168
  parent: 'people',                                                                                                   // 169
  waitOn: function waitOn() {                                                                                         // 170
    var entityEmail = Session.get('user').email;                                                                      // 171
    return [Meteor.subscribe('getPeople'), Meteor.subscribe('getPeopleWithRelationship', entityEmail)];               // 172
  }                                                                                                                   // 176
});                                                                                                                   // 166
                                                                                                                      //
var loginRequired = function loginRequired() {                                                                        // 179
  var userSession = Session.get('user');                                                                              // 180
  if (userSession != null && userSession != undefined) {                                                              // 181
    this.next();                                                                                                      // 182
  } else {                                                                                                            // 183
    Router.go('login');                                                                                               // 184
  }                                                                                                                   // 185
};                                                                                                                    // 186
Router.onBeforeAction(loginRequired, { except: ['login', 'register', 'index', 'forgotPassword', 'changePassword'] });
                                                                                                                      //
var cleanSphereSessionVariable = function cleanSphereSessionVariable() {};                                            // 190
                                                                                                                      //
Router.onAfterAction(cleanSphereSessionVariable, { except: ['newSphere'] });                                          // 192
                                                                                                                      //
// New routes for Dashboard                                                                                           //
                                                                                                                      //
Router.route('/dashboard', {                                                                                          // 198
  name: 'dashboard',                                                                                                  // 199
  template: 'dashboard'                                                                                               // 200
});                                                                                                                   // 198
                                                                                                                      //
Router.route('/user', {                                                                                               // 203
  name: 'user',                                                                                                       // 204
  template: 'user',                                                                                                   // 205
  data: function data() {                                                                                             // 206
    return Session.get('user');                                                                                       // 207
  }                                                                                                                   // 208
});                                                                                                                   // 203
                                                                                                                      //
Router.route('/providers', {                                                                                          // 211
  name: 'providers',                                                                                                  // 212
  template: 'providers'                                                                                               // 213
});                                                                                                                   // 211
                                                                                                                      //
Router.route('/consumers', {                                                                                          // 216
  name: 'consumers',                                                                                                  // 217
  template: 'consumers'                                                                                               // 218
});                                                                                                                   // 216
                                                                                                                      //
Router.route('/spheres', {                                                                                            // 221
  name: 'spheres',                                                                                                    // 222
  template: 'spheres'                                                                                                 // 223
});                                                                                                                   // 221
                                                                                                                      //
Router.route('/entities', {                                                                                           // 226
  name: 'entities',                                                                                                   // 227
  template: 'entities'                                                                                                // 228
});                                                                                                                   // 226
                                                                                                                      //
Router.route('/notifications', {                                                                                      // 231
  name: 'notifications',                                                                                              // 232
  template: 'notifications'                                                                                           // 233
});                                                                                                                   // 231
                                                                                                                      //
Router.route('/template', {                                                                                           // 236
  name: 'template',                                                                                                   // 237
  template: 'template'                                                                                                // 238
});                                                                                                                   // 236
                                                                                                                      //
Router.route('/icons', {                                                                                              // 241
  name: 'icons',                                                                                                      // 242
  template: 'icons'                                                                                                   // 243
});                                                                                                                   // 241
                                                                                                                      //
Router.route('/users_entity', {                                                                                       // 246
  name: 'users_entity',                                                                                               // 247
  template: 'users_entity'                                                                                            // 248
});                                                                                                                   // 246
                                                                                                                      //
Router.route('/entity', {                                                                                             // 251
  name: 'entity',                                                                                                     // 252
  template: 'entity'                                                                                                  // 253
});                                                                                                                   // 251
                                                                                                                      //
Router.route('/forgotPassword', {                                                                                     // 256
  name: 'forgotPassword',                                                                                             // 257
  template: 'forgotPassword',                                                                                         // 258
  waitOn: function waitOn() {                                                                                         // 259
    return Meteor.subscribe('getRegisteredEmailsandRegisteredIds');                                                   // 260
  }                                                                                                                   // 261
});                                                                                                                   // 256
                                                                                                                      //
Router.route('/changePassword', {                                                                                     // 264
  name: 'changePassword',                                                                                             // 265
  template: 'changePassword'                                                                                          // 266
});                                                                                                                   // 264
                                                                                                                      //
Router.route('/authorization', {                                                                                      // 269
  name: 'authorization',                                                                                              // 270
  template: 'authorization'                                                                                           // 271
});                                                                                                                   // 269
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"LMP.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/LMP.js                                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
//declare a simple async function                                                                                     //
function delayedMessge(delay, message, callback) {                                                                    // 2
  setTimeout(function () {                                                                                            // 3
    callback(null, message);                                                                                          // 4
  }, delay);                                                                                                          // 5
}                                                                                                                     // 6
                                                                                                                      //
Meteor.methods({                                                                                                      // 10
                                                                                                                      //
  'upsertSphere': function upsertSphere(sphereObject, httpCommand) {                                                  // 12
    if (httpCommand == 'POST') {                                                                                      // 13
      var url = host + slash + spheres;                                                                               // 14
      var response = HTTP.post(url, {                                                                                 // 15
        data: {                                                                                                       // 16
          identifier: sphereObject.identifier,                                                                        // 17
          name: sphereObject.name,                                                                                    // 18
          description: sphereObject.description,                                                                      // 19
          type: sphereObject.type,                                                                                    // 20
          enabled: sphereObject.isEnabled,                                                                            // 21
          deleted: sphereObject.isDeleted,                                                                            // 22
          dataextracted: sphereObject.isDataExtracted                                                                 // 23
        },                                                                                                            // 16
        auth: basic_auth                                                                                              // 25
      });                                                                                                             // 15
      return response;                                                                                                // 27
    } else {                                                                                                          // 29
      var response = HTTP.put(sphereObject.url, {                                                                     // 30
        data: {                                                                                                       // 31
          identifier: sphereObject.identifier,                                                                        // 32
          name: sphereObject.name,                                                                                    // 33
          description: sphereObject.description,                                                                      // 34
          type: sphereObject.type,                                                                                    // 35
          enabled: sphereObject.isEnabled,                                                                            // 36
          deleted: sphereObject.isDeleted,                                                                            // 37
          dataextracted: sphereObject.isDataExtracted                                                                 // 38
        },                                                                                                            // 31
        auth: basic_auth                                                                                              // 40
      });                                                                                                             // 30
      return response;                                                                                                // 42
    }                                                                                                                 // 43
  },                                                                                                                  // 44
                                                                                                                      //
  'upsertEntity': function upsertEntity(entityObject, userUrl) {                                                      // 46
    var url = host + slash + entities;                                                                                // 47
    console.log('in upsertEntity');                                                                                   // 48
    console.log(url);                                                                                                 // 49
    var response = HTTP.post(url, {                                                                                   // 50
      data: {                                                                                                         // 51
        identifier: entityObject.identifier,                                                                          // 52
        name: entityObject.name,                                                                                      // 53
        description: entityObject.description,                                                                        // 54
        email: entityObject.email                                                                                     // 55
      },                                                                                                              // 51
      auth: basic_auth                                                                                                // 57
    });                                                                                                               // 50
    console.log(response);                                                                                            // 59
    var location = response.headers.location;                                                                         // 60
    console.log(location);                                                                                            // 61
    return location;                                                                                                  // 62
  },                                                                                                                  // 63
                                                                                                                      //
  'updateEntityRequests': function updateEntityRequests(userUrl, entityUrls) {                                        // 65
    console.log('in updateEntityRequests');                                                                           // 66
                                                                                                                      //
    var entityUrlString = _.map(entityUrls, function (url) {                                                          // 68
      return url + '\n';                                                                                              // 69
    }).join('').trim();                                                                                               // 70
                                                                                                                      //
    var response = HTTP.put(userUrl, {                                                                                // 72
      headers: {                                                                                                      // 73
        "Content-Type": "text/uri-list"                                                                               // 74
      },                                                                                                              // 73
      content: entityUrlString,                                                                                       // 76
      auth: basic_auth                                                                                                // 77
    });                                                                                                               // 72
    return response;                                                                                                  // 79
  },                                                                                                                  // 80
                                                                                                                      //
  'updateEntity': function updateEntity(entityObject, entityUrl) {                                                    // 82
    var response = HTTP.patch(entityUrl, {                                                                            // 83
      data: {                                                                                                         // 84
        name: entityObject.name,                                                                                      // 85
        description: entityObject.description,                                                                        // 86
        email: entityObject.email,                                                                                    // 87
        identifier: entityObject.identifier                                                                           // 88
      },                                                                                                              // 84
      auth: basic_auth                                                                                                // 90
    });                                                                                                               // 83
  },                                                                                                                  // 92
                                                                                                                      //
  'joinSphereAndConsumer': function joinSphereAndConsumer(sphereConsumerUrl, consumersUrl) {                          // 94
    var urlConsumersString = '';                                                                                      // 95
    for (url in consumersUrl) {                                                                                       // 96
      urlConsumersString += consumersUrl[url] + '\n';                                                                 // 97
    }                                                                                                                 // 98
                                                                                                                      //
    return HTTP.put(sphereConsumerUrl, {                                                                              // 100
      headers: {                                                                                                      // 101
        "Content-Type": "text/uri-list"                                                                               // 102
      },                                                                                                              // 101
      content: urlConsumersString,                                                                                    // 104
      auth: basic_auth                                                                                                // 105
    });                                                                                                               // 100
  },                                                                                                                  // 107
                                                                                                                      //
  'joinSphereAndAttributes': function joinSphereAndAttributes(sphereAttributesUrl, attributesUrl) {                   // 109
    var urlAttributesString = '';                                                                                     // 110
    for (url in attributesUrl) {                                                                                      // 111
      urlAttributesString += attributesUrl[url] + '\n';                                                               // 112
    }                                                                                                                 // 113
                                                                                                                      //
    return HTTP.put(sphereAttributesUrl, {                                                                            // 115
      headers: {                                                                                                      // 116
        "Content-Type": "text/uri-list"                                                                               // 117
      },                                                                                                              // 116
      content: urlAttributesString,                                                                                   // 119
      auth: basic_auth                                                                                                // 120
    });                                                                                                               // 115
  },                                                                                                                  // 123
                                                                                                                      //
  'upsertProvider': function upsertProvider(providerObject) {                                                         // 125
    var url = host + slash + providers;                                                                               // 126
    var response = HTTP.post(url, {                                                                                   // 127
      data: {                                                                                                         // 128
        identifier: providerObject.identifier,                                                                        // 129
        name: providerObject.name,                                                                                    // 130
        description: providerObject.description,                                                                      // 131
        url: providerObject.url,                                                                                      // 132
        isEnabled: providerObject.isEnabled,                                                                          // 133
        isDeleted: providerObject.isDeleted                                                                           // 134
      },                                                                                                              // 128
      auth: basic_auth                                                                                                // 136
    });                                                                                                               // 127
    return response;                                                                                                  // 138
  },                                                                                                                  // 139
                                                                                                                      //
  'joinPersonAndProvider': function joinPersonAndProvider(urlProviderPerson, urlProviders) {                          // 141
    var urlProvidersString = '';                                                                                      // 142
    for (url in urlProviders) {                                                                                       // 143
      urlProvidersString += urlProviders[url] + '\n';                                                                 // 144
    }                                                                                                                 // 145
    console.log(urlProviderPerson);                                                                                   // 146
    console.log(urlProvidersString);                                                                                  // 147
    return HTTP.put(urlProviderPerson, {                                                                              // 148
      headers: {                                                                                                      // 149
        "Content-Type": " text/uri-list",                                                                             // 150
        "auth": "web@hotmail.com:EurecatLMP2016!"                                                                     // 151
      },                                                                                                              // 149
      content: urlProvidersString,                                                                                    // 153
      auth: basic_auth                                                                                                // 154
    });                                                                                                               // 148
  },                                                                                                                  // 156
                                                                                                                      //
  'deletePersonAndProviderRelation': function deletePersonAndProviderRelation(providerId, userId) {                   // 158
    console.log('deletePersonAndProviderRelation');                                                                   // 159
    var url = host + slash + "delete/provider/" + providerId + "/user/" + userId;                                     // 160
                                                                                                                      //
    return HTTP.get(url, http_options);                                                                               // 162
  },                                                                                                                  // 163
                                                                                                                      //
  'joinPersonAndConsumer': function joinPersonAndConsumer(urlConsumerPerson, urlConsumers) {                          // 165
    var urlConsumersString = '';                                                                                      // 166
    for (url in urlConsumers) {                                                                                       // 167
      urlConsumersString += urlConsumers[url] + '\n';                                                                 // 168
    }                                                                                                                 // 169
    console.log('joinPersonAndConsumer');                                                                             // 170
    console.log(urlConsumersString);                                                                                  // 171
    console.log('---------------------------------------------------');                                               // 172
    return HTTP.put(urlConsumerPerson, {                                                                              // 173
      headers: {                                                                                                      // 174
        "Content-Type": "text/uri-list"                                                                               // 175
      },                                                                                                              // 174
      content: urlConsumersString,                                                                                    // 177
      auth: basic_auth                                                                                                // 178
    });                                                                                                               // 173
  },                                                                                                                  // 180
                                                                                                                      //
  'joinPersonAndSphere': function joinPersonAndSphere(urlSpherePerson, urlSpheres) {                                  // 182
    var urlSpheresString = '';                                                                                        // 183
    console.log('joinPersonAndSphere');                                                                               // 184
    for (url in urlSpheres) {                                                                                         // 185
      urlSpheresString += urlSpheres[url] + '\n';                                                                     // 186
    }                                                                                                                 // 187
    console.log(urlSpheresString);                                                                                    // 188
    return HTTP.put(urlSpherePerson, {                                                                                // 189
      headers: {                                                                                                      // 190
        "Content-Type": "text/uri-list"                                                                               // 191
      },                                                                                                              // 190
      content: urlSpheresString,                                                                                      // 193
      auth: basic_auth                                                                                                // 194
    });                                                                                                               // 189
  },                                                                                                                  // 196
                                                                                                                      //
  'upsertConsumer': function upsertConsumer(consumerObject) {                                                         // 198
    var url = host + slash + consumers;                                                                               // 199
    var response = HTTP.post(url, {                                                                                   // 200
      data: {                                                                                                         // 201
        identifier: consumerObject.identifier,                                                                        // 202
        name: consumerObject.name,                                                                                    // 203
        description: consumerObject.description,                                                                      // 204
        isEnabled: consumerObject.isEnabled,                                                                          // 205
        isDeleted: consumerObject.isDeleted                                                                           // 206
      },                                                                                                              // 201
      auth: basic_auth                                                                                                // 208
    });                                                                                                               // 200
    return response;                                                                                                  // 210
  },                                                                                                                  // 211
                                                                                                                      //
  'updateSphereEnabled': function updateSphereEnabled(enabled, sphereUrl) {                                           // 213
    var response = HTTP.patch(sphereUrl, {                                                                            // 214
      data: {                                                                                                         // 215
        enabled: enabled                                                                                              // 216
      },                                                                                                              // 215
      http_options: http_options                                                                                      // 218
    });                                                                                                               // 214
    return response;                                                                                                  // 220
  },                                                                                                                  // 221
                                                                                                                      //
  'updateProviderEnabled': function updateProviderEnabled(enabled, providerUrl) {                                     // 223
    var response = HTTP.patch(providerUrl, {                                                                          // 224
      data: {                                                                                                         // 225
        enabled: enabled                                                                                              // 226
      },                                                                                                              // 225
      auth: basic_auth                                                                                                // 228
    });                                                                                                               // 224
    return response;                                                                                                  // 230
  },                                                                                                                  // 231
                                                                                                                      //
  'registerUser': function registerUser(personObject) {                                                               // 233
    var _id = Meteor.userId();                                                                                        // 234
    var url = host + slash + people + slash;                                                                          // 235
    var response = HTTP.post(url, {                                                                                   // 236
      data: {                                                                                                         // 237
        identifier: _id,                                                                                              // 238
        name: personObject.name,                                                                                      // 239
        surname: personObject.surname,                                                                                // 240
        phone: personObject.phone,                                                                                    // 241
        email: personObject.email,                                                                                    // 242
        password: personObject.password,                                                                              // 243
        identifier: personObject.personal_id                                                                          // 244
      },                                                                                                              // 237
      auth: basic_auth                                                                                                // 246
    }, function (error, response) {                                                                                   // 236
      if (error) {                                                                                                    // 248
        console.log('Error in registerUser');                                                                         // 249
        console.log(error);                                                                                           // 250
      } else {                                                                                                        // 251
        console.log('User added correctly!');                                                                         // 252
        console.log(response);                                                                                        // 253
      }                                                                                                               // 254
    });                                                                                                               // 255
  },                                                                                                                  // 256
                                                                                                                      //
  'loginWithPassword': function (_loginWithPassword) {                                                                // 258
    function loginWithPassword(_x) {                                                                                  // 258
      return _loginWithPassword.apply(this, arguments);                                                               // 258
    }                                                                                                                 // 258
                                                                                                                      //
    loginWithPassword.toString = function () {                                                                        // 258
      return _loginWithPassword.toString();                                                                           // 258
    };                                                                                                                // 258
                                                                                                                      //
    return loginWithPassword;                                                                                         // 258
  }(function (loginObject) {                                                                                          // 258
    var url = host + slash + loginWithPassword + questionMark + emailParameter + loginObject.email + ampersand + passwordParameter + loginObject.password;
    console.log(url);                                                                                                 // 261
    try {                                                                                                             // 262
      var response = HTTP.get(url, http_options);                                                                     // 263
      console.log(response);                                                                                          // 264
                                                                                                                      //
      var code = JSON.parse(response.statusCode);                                                                     // 266
      if (code == undefined || code == null) {                                                                        // 267
        throw new Meteor.Error('400', 'User not found', 'Bad request. Please check with your administrator.');        // 268
        return;                                                                                                       // 269
      } else if (code == 401) {                                                                                       // 270
        throw new Meteor.Error('401', 'Unauthorized access', 'Wrogn authentication');                                 // 271
        return;                                                                                                       // 272
      }                                                                                                               // 273
                                                                                                                      //
      var getUserUrl = host + slash + people + slash + search + slash + findByEmail + loginObject.email;              // 275
      console.log(getUserUrl);                                                                                        // 277
      var response = HTTP.get(getUserUrl, http_options);                                                              // 278
      var user = JSON.parse(response.content);                                                                        // 279
      if (user == undefined || user == null) {                                                                        // 280
        throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                            // 281
      }                                                                                                               // 282
      return user;                                                                                                    // 283
    } catch (error) {                                                                                                 // 284
      console.log('Error while authenticating the user... ' + error);                                                 // 285
      throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                              // 286
    }                                                                                                                 // 287
  }),                                                                                                                 // 288
                                                                                                                      //
  //Old                                                                                                               //
  'getSpheresByPerson': function getSpheresByPerson(spheresUrl) {                                                     // 291
    try {                                                                                                             // 292
      var response = HTTP.get(spheresUrl, http_options);                                                              // 293
      var content = JSON.parse(response.content);                                                                     // 295
      var spheresList = content._embedded.spheres;                                                                    // 296
      return spheresList;                                                                                             // 297
    } catch (error) {                                                                                                 // 298
      console.log(error);                                                                                             // 299
    }                                                                                                                 // 300
    return [];                                                                                                        // 301
  },                                                                                                                  // 302
                                                                                                                      //
  'getSpheresByUser': function getSpheresByUser(spheresUrl) {                                                         // 304
    try {                                                                                                             // 305
      var response = HTTP.get(spheresUrl, http_options);                                                              // 306
      var content = JSON.parse(response.content);                                                                     // 308
      var spheresList = content._embedded.spheres;                                                                    // 309
      return spheresList;                                                                                             // 310
    } catch (error) {                                                                                                 // 311
      console.log(error);                                                                                             // 312
    }                                                                                                                 // 313
    return [];                                                                                                        // 314
  },                                                                                                                  // 315
                                                                                                                      //
  'getSphere': function getSphere(sphereUrl) {                                                                        // 317
    try {                                                                                                             // 318
      var response = HTTP.get(sphereUrl, http_options);                                                               // 319
      var content = JSON.parse(response.content);                                                                     // 321
      return content;                                                                                                 // 322
    } catch (error) {                                                                                                 // 323
      console.log(error);                                                                                             // 324
    }                                                                                                                 // 325
    return '';                                                                                                        // 326
  },                                                                                                                  // 327
                                                                                                                      //
  'updateUser': function updateUser(user) {                                                                           // 329
    HTTP.put(user.link, {                                                                                             // 330
      data: {                                                                                                         // 331
        name: user.name,                                                                                              // 332
        surname: user.surname,                                                                                        // 333
        phone: user.phone,                                                                                            // 334
        email: user.email,                                                                                            // 335
        password: user.password,                                                                                      // 336
        personal_id: user.personal_id,                                                                                // 337
                                                                                                                      //
        identifier: user.identifier,                                                                                  // 339
        address: user.address,                                                                                        // 340
        postalCode: user.postalCode,                                                                                  // 341
        city: user.city,                                                                                              // 342
        country: user.country,                                                                                        // 343
        description: user.description                                                                                 // 344
      },                                                                                                              // 331
      auth: basic_auth                                                                                                // 346
    });                                                                                                               // 330
  },                                                                                                                  // 348
                                                                                                                      //
  'getConsumersByUser': function getConsumersByUser(consumersUrl) {                                                   // 350
    try {                                                                                                             // 351
      var response = HTTP.get(consumersUrl, http_options);                                                            // 352
      var content = JSON.parse(response.content);                                                                     // 354
      var consumersList = content._embedded.consumers;                                                                // 355
      return consumersList;                                                                                           // 356
    } catch (error) {                                                                                                 // 357
      console.log(error);                                                                                             // 358
    }                                                                                                                 // 359
    return [];                                                                                                        // 360
  },                                                                                                                  // 361
                                                                                                                      //
  'getProvidersByUser': function getProvidersByUser(providersUrl) {                                                   // 363
    try {                                                                                                             // 364
      var response = HTTP.get(providersUrl, http_options);                                                            // 365
      var content = JSON.parse(response.content);                                                                     // 367
      var providersList = content._embedded.providers;                                                                // 368
      return providersList;                                                                                           // 369
    } catch (error) {                                                                                                 // 370
      console.log(error);                                                                                             // 371
    }                                                                                                                 // 372
    return [];                                                                                                        // 373
  },                                                                                                                  // 374
                                                                                                                      //
  'joinPersonAndEntities': function joinPersonAndEntities(urlPersonEntities, entitiesUrl) {                           // 376
    var urlEntitiesString = '';                                                                                       // 377
    for (url in entitiesUrl) {                                                                                        // 378
      urlEntitiesString += entitiesUrl[url] + '\n';                                                                   // 379
    }                                                                                                                 // 380
    return HTTP.put(urlPersonEntities, {                                                                              // 381
      headers: {                                                                                                      // 382
        "Content-Type": "text/uri-list"                                                                               // 383
      },                                                                                                              // 382
      content: urlEntitiesString,                                                                                     // 385
      auth: basic_auth                                                                                                // 386
    });                                                                                                               // 381
  },                                                                                                                  // 388
                                                                                                                      //
  'getAndDeletePersonOrganizationRelationshipsByEntityEmail': function getAndDeletePersonOrganizationRelationshipsByEntityEmail(entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipsByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                      //
    var response = HTTP.get(url, http_options);                                                                       // 395
    var content = JSON.parse(response.content);                                                                       // 397
    var associations = content._embedded.personEntityRelationships;                                                   // 398
                                                                                                                      //
    _.each(associations, function (association) {                                                                     // 400
      var associationLink = association._links.self.href;                                                             // 401
      HTTP.call('DELETE', associationLink, http_options);                                                             // 402
    });                                                                                                               // 403
    return content;                                                                                                   // 404
  },                                                                                                                  // 405
                                                                                                                      //
  'deleteEntity': function deleteEntity(entityUrl) {                                                                  // 407
    var response = HTTP.call('DELETE', entityUrl, http_options);                                                      // 408
  },                                                                                                                  // 409
                                                                                                                      //
  'getEntity': function getEntity(entityUrl) {                                                                        // 411
    var response = HTTP.get(entityUrl, http_options);                                                                 // 412
    var entity = JSON.parse(response.content);                                                                        // 413
    if (entity == undefined || entity == null) {                                                                      // 414
      throw new Meteor.Error('404', 'Entity not found', 'Entity not found in the Database');                          // 415
    }                                                                                                                 // 416
    return entity;                                                                                                    // 417
  },                                                                                                                  // 418
                                                                                                                      //
  'getPersonOrganizationRelationshipByEntityEmailAndPersonEmail': function getPersonOrganizationRelationshipByEntityEmailAndPersonEmail(userEmail, entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipByEntityEmailAndPersonEmail + questionMark + 'entityEmail=' + entityEmail + ampersand + 'personEmail=' + userEmail;
    console.log(url);                                                                                                 // 424
    var response = HTTP.get(url, http_options);                                                                       // 425
    console.log(response);                                                                                            // 426
    var content = JSON.parse(response.content);                                                                       // 427
    var associationLink = content._links.self.href;                                                                   // 428
    return associationLink;                                                                                           // 429
  },                                                                                                                  // 430
                                                                                                                      //
  'changePersonOrganizationState': function changePersonOrganizationState(associationLink, state) {                   // 432
    HTTP.patch(associationLink, {                                                                                     // 433
      data: {                                                                                                         // 434
        state: state                                                                                                  // 435
      },                                                                                                              // 434
      auth: basic_auth                                                                                                // 437
    });                                                                                                               // 433
  },                                                                                                                  // 439
                                                                                                                      //
  'deletePersonOrganizationRelationship': function deletePersonOrganizationRelationship(associationLink) {            // 441
    console.log('deleting personOrganizationRelationship...');                                                        // 442
    var response = HTTP.call('delete', associationLink, http_options);                                                // 443
  },                                                                                                                  // 444
                                                                                                                      //
  'insertPersonOrganizationRelationship': function insertPersonOrganizationRelationship(userUrl, entityUrl, state) {  // 446
    console.log('insertPersonOrganizationRelationship');                                                              // 447
                                                                                                                      //
    var personEntityRelationshipsUrl = host + slash + personEntityRelationships;                                      // 449
                                                                                                                      //
    var response = HTTP.post(personEntityRelationshipsUrl, {                                                          // 451
      data: {                                                                                                         // 452
        state: state,                                                                                                 // 453
        organization: entityUrl,                                                                                      // 454
        person: userUrl                                                                                               // 455
      },                                                                                                              // 452
      auth: basic_auth                                                                                                // 457
    });                                                                                                               // 451
    return response;                                                                                                  // 459
  },                                                                                                                  // 460
                                                                                                                      //
  'findTokenByproviderNameAndUserEmail': function findTokenByproviderNameAndUserEmail(providerName, email) {          // 462
    console.log('in findTokenByproviderNameAndUserEmail');                                                            // 463
                                                                                                                      //
    var url = host + slash + tokens + slash + search + slash + findTokensByProviderNameAndUserEmail + questionMark + providerNameParameter + providerName + ampersand + emailParameter + email;
    try {                                                                                                             // 467
      var response = HTTP.get(url, http_options);                                                                     // 468
      var content = JSON.parse(response.content);                                                                     // 469
      if (content._embedded.tokens.length > 0) return content._embedded.tokens[0].token;else return null;             // 470
    } catch (error) {                                                                                                 // 474
      console.log(error);                                                                                             // 475
      return null;                                                                                                    // 476
    }                                                                                                                 // 477
  },                                                                                                                  // 478
                                                                                                                      //
  'getAuthorizationUrl': function getAuthorizationUrl(providerName, email) {                                          // 480
    console.log('in getAuthorizationUrl');                                                                            // 481
    var url = host + slash + authorizationUrl + questionMark + providerParameter + providerName + ampersand + emailParameter + email + ampersand + redirectUrlParameter + redirectUrl;
                                                                                                                      //
    try {                                                                                                             // 486
      console.log(url);                                                                                               // 487
      var response = HTTP.get(url, http_options);                                                                     // 488
      return response.data.authorizationUrl;                                                                          // 489
    } catch (error) {                                                                                                 // 490
      console.log(error);                                                                                             // 491
      return null;                                                                                                    // 492
    }                                                                                                                 // 493
  },                                                                                                                  // 494
                                                                                                                      //
  'getToken': function getToken(authorizationData) {                                                                  // 496
    console.log('in getToken');                                                                                       // 497
    var url = host + slash + newToken + questionMark + providerParameter + authorizationData.provider + ampersand + emailParameter + authorizationData.email + ampersand + codeParameter + authorizationData.code + ampersand + redirectUrlParameter + redirectUrl;
                                                                                                                      //
    try {                                                                                                             // 504
      var response = HTTP.get(url, http_options);                                                                     // 505
      console.log('token: ' + response.content);                                                                      // 506
      return response.content;                                                                                        // 507
    } catch (error) {                                                                                                 // 508
      console.log(error);                                                                                             // 509
    }                                                                                                                 // 510
  },                                                                                                                  // 511
                                                                                                                      //
  'getEntitiesWithRelationship': function getEntitiesWithRelationship(userEmail) {                                    // 513
    console.log('in getEntitiesWithRelationship');                                                                    // 514
    var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmail + questionMark + emailParameter + userEmail;
                                                                                                                      //
    try {                                                                                                             // 518
      var response = HTTP.get(url, http_options);                                                                     // 519
      var content = JSON.parse(response.content);                                                                     // 520
      var entitiesList = content._embedded.entities;                                                                  // 521
                                                                                                                      //
      return entitiesList;                                                                                            // 523
    } catch (error) {                                                                                                 // 524
      console.log('error in getEntitiesWithRelationship');                                                            // 525
      console.log(error);                                                                                             // 526
      return null;                                                                                                    // 527
    }                                                                                                                 // 528
  },                                                                                                                  // 529
                                                                                                                      //
  'sendEmailResetPassword': function sendEmailResetPassword(email) {                                                  // 531
    console.log('in sendEmailResetPassword');                                                                         // 532
    var url = host + slash + person + slash + resetPassword + questionMark + emailParameter + email + ampersand + recoverUrlParameter + encodeURI(recoverUrl);
    console.log(url);                                                                                                 // 535
    try {                                                                                                             // 536
      var response = HTTP.get(url, http_options);                                                                     // 537
    } catch (error) {                                                                                                 // 538
      console.log('error in sendEmailResetPassword');                                                                 // 539
      console.log(error);                                                                                             // 540
    }                                                                                                                 // 541
  },                                                                                                                  // 542
                                                                                                                      //
  'resetAndSavePassword': function resetAndSavePassword(objectResetPassword) {                                        // 544
    console.log('in resetAndSavePassword');                                                                           // 545
    var url = host + slash + person + slash + savePassword;                                                           // 546
    try {                                                                                                             // 547
      var response = HTTP.post(url, {                                                                                 // 548
        data: {                                                                                                       // 549
          email: objectResetPassword.email,                                                                           // 550
          token: objectResetPassword.token,                                                                           // 551
          password: objectResetPassword.password                                                                      // 552
        },                                                                                                            // 549
        auth: basic_auth                                                                                              // 554
      });                                                                                                             // 548
    } catch (error) {                                                                                                 // 556
      console.log('error in resetAndSavePassword');                                                                   // 557
      console.log(error);                                                                                             // 558
      throw new Meteor.Error("save-password-failed", error);                                                          // 559
    }                                                                                                                 // 560
  }                                                                                                                   // 561
});                                                                                                                   // 10
                                                                                                                      //
Meteor.publish('getConsumers', function () {                                                                          // 566
  var self = this;                                                                                                    // 567
  var url = host + slash + consumers;                                                                                 // 568
  try {                                                                                                               // 569
    var response = HTTP.get(url, http_options);                                                                       // 570
    var content = JSON.parse(response.content);                                                                       // 571
    var consumersList = content._embedded.consumers;                                                                  // 572
    for (c in consumersList) {                                                                                        // 573
      var consumer = {                                                                                                // 574
        identifier: consumersList[c].identifier,                                                                      // 575
        name: consumersList[c].name,                                                                                  // 576
        description: consumersList[c].description,                                                                    // 577
        link: consumersList[c]._links.consumer.href                                                                   // 578
                                                                                                                      //
      };                                                                                                              // 574
      //TODO: CHANGE ID FROM CONSUMER.IDENTIFIER TO CONSUMER.ID                                                       //
      self.added('consumers', consumer.identifier, consumer);                                                         // 582
    }                                                                                                                 // 583
    self.ready();                                                                                                     // 584
  } catch (error) {                                                                                                   // 585
    console.log('Error in getConsumers');                                                                             // 586
    console.log(error);                                                                                               // 587
  }                                                                                                                   // 588
});                                                                                                                   // 589
                                                                                                                      //
/*Meteor.publish('getSpheres', function(){                                                                            //
  var self = this;                                                                                                    //
  var url = host + slash + spheres;                                                                                   //
  try{                                                                                                                //
    var response = HTTP.get(url, http_options);                                                                       //
    var content = JSON.parse(response.content);                                                                       //
    spheresList = content._embedded.spheres;                                                                          //
    for (s in spheresList){                                                                                           //
      var sphere = {                                                                                                  //
        name:           spheresList[c].name,                                                                          //
        description:    spheresList[c].description,                                                                   //
        type:           spheresList[c].type                                                                           //
      }                                                                                                               //
      self.added('spheres', Random.id(), sphere);                                                                     //
    }                                                                                                                 //
    self.ready();                                                                                                     //
  } catch (error){                                                                                                    //
    console.log('Error in getSpheres');                                                                               //
    console.log(error);                                                                                               //
  }                                                                                                                   //
});*/                                                                                                                 //
                                                                                                                      //
Meteor.publish('getProviders', function () {                                                                          // 613
  console.log('getProviders');                                                                                        // 614
  var self = this;                                                                                                    // 615
  var url = host + slash + providers;                                                                                 // 616
  try {                                                                                                               // 617
    var response = HTTP.get(url, http_options);                                                                       // 618
    var content = JSON.parse(response.content);                                                                       // 619
    var providersList = content._embedded.providers;                                                                  // 620
    for (p in providersList) {                                                                                        // 621
                                                                                                                      //
      var provider = {                                                                                                // 623
        id: providersList[p].id,                                                                                      // 624
        name: providersList[p].name,                                                                                  // 625
        description: providersList[p].description,                                                                    // 626
        type: providersList[p].type,                                                                                  // 627
        url: providersList[p].url,                                                                                    // 628
        enabled: providersList[p].enabled,                                                                            // 629
        deleted: providersList[p].deleted,                                                                            // 630
        link: providersList[p]._links.provider.href,                                                                  // 631
        oAuth: providersList[p].oAuth,                                                                                // 632
        oAuthUrl: providersList[p].oAuthUrl                                                                           // 633
      };                                                                                                              // 623
      /*self.added('providers', Random.id(), provider);*/                                                             //
      self.added('providers', provider.id, provider);                                                                 // 636
    }                                                                                                                 // 637
    self.ready();                                                                                                     // 638
  } catch (error) {                                                                                                   // 639
    console.log('Error in getProviders');                                                                             // 640
    console.log(error);                                                                                               // 641
  }                                                                                                                   // 642
});                                                                                                                   // 643
                                                                                                                      //
Meteor.publish('getProvidersByUser', function (providersUrl) {                                                        // 645
  console.log('getProvidersByUser');                                                                                  // 646
  var self = this;                                                                                                    // 647
                                                                                                                      //
  if (providersUrl != null) {                                                                                         // 649
    try {                                                                                                             // 650
      var response = HTTP.get(providersUrl, http_options);                                                            // 651
      var content = JSON.parse(response.content);                                                                     // 652
      var providersList = content._embedded.providers;                                                                // 653
                                                                                                                      //
      for (p in providersList) {                                                                                      // 655
        var provider = {                                                                                              // 656
          id: providersList[p].id,                                                                                    // 657
          name: providersList[p].name,                                                                                // 658
          description: providersList[p].description,                                                                  // 659
          type: providersList[p].type,                                                                                // 660
          url: providersList[p].url,                                                                                  // 661
          enabled: providersList[p].enabled,                                                                          // 662
          deleted: providersList[p].deleted,                                                                          // 663
          link: providersList[p]._links.provider.href,                                                                // 664
          attributesLink: providersList[p]._links.attributeMaps.href                                                  // 665
        };                                                                                                            // 656
        self.added('providersByUser', provider.id, provider);                                                         // 667
      }                                                                                                               // 668
    } catch (error) {                                                                                                 // 669
      console.log('Error in getProvidersByUser');                                                                     // 670
      console.log(error);                                                                                             // 671
    }                                                                                                                 // 672
  }                                                                                                                   // 673
  console.log('---------------------------------------------------');                                                 // 674
  self.ready();                                                                                                       // 675
});                                                                                                                   // 676
                                                                                                                      //
Meteor.publish('getConsumersInSphere', function (sphereConsumersUrl) {                                                // 678
  var self = this;                                                                                                    // 679
  console.log(sphereConsumersUrl);                                                                                    // 680
  if (sphereConsumersUrl != null) {                                                                                   // 681
    try {                                                                                                             // 682
      var response = HTTP.get(sphereConsumersUrl, http_options);                                                      // 683
      var content = JSON.parse(response.content);                                                                     // 684
      var consumers = content._embedded.consumers;                                                                    // 685
                                                                                                                      //
      _.each(consumers, function (consumer) {                                                                         // 687
        consumer.link = consumer._links.self.href;                                                                    // 688
        self.added('consumersInSphere', consumer.identifier, consumer);                                               // 689
      });                                                                                                             // 690
    } catch (error) {                                                                                                 // 692
      console.log('Error in getConsumersInSphere');                                                                   // 693
      console.log(error);                                                                                             // 694
    }                                                                                                                 // 695
  }                                                                                                                   // 696
  self.ready();                                                                                                       // 697
});                                                                                                                   // 698
                                                                                                                      //
Meteor.publish('getCategoriesByProviders', function (providerNames) {                                                 // 700
  console.log('getCategoriesByProviders');                                                                            // 701
  var self = this;                                                                                                    // 702
  var url = host + slash + providers + slash + search + slash + findCategoriesByProviderNamesList + providerNames;    // 703
  try {                                                                                                               // 704
    var response = HTTP.get(url, http_options);                                                                       // 705
    var content = JSON.parse(response.content);                                                                       // 706
    var attributeCategories = content._embedded.attributeCategories;                                                  // 707
    for (a in attributeCategories) {                                                                                  // 708
      var attribute = {                                                                                               // 709
        name: attributeCategories[a].name                                                                             // 710
      };                                                                                                              // 709
      self.added('categoriesByProviders', Random.id(), attribute);                                                    // 712
    }                                                                                                                 // 713
  } catch (error) {                                                                                                   // 714
    console.log('Error in getCategoriesByProviders');                                                                 // 715
    console.log(error);                                                                                               // 716
  }                                                                                                                   // 717
  console.log('---------------------------------------------------');                                                 // 718
  self.ready();                                                                                                       // 719
});                                                                                                                   // 720
                                                                                                                      //
Meteor.publish('getAttributes', function () {                                                                         // 722
  console.log('getAttributes');                                                                                       // 723
  var self = this;                                                                                                    // 724
  var url = host + slash + attrs;                                                                                     // 725
  try {                                                                                                               // 726
    var response = HTTP.get(url, http_options);                                                                       // 727
    var content = JSON.parse(response.content);                                                                       // 728
    var attributes = content._embedded.attributes;                                                                    // 729
    for (a in attributes) {                                                                                           // 730
      var attribute = {                                                                                               // 731
        name: attributes[a].name,                                                                                     // 732
        category: attributes[a].subcategory.category.name,                                                            // 733
        subcategory: attributes[a].subcategory.name                                                                   // 734
      };                                                                                                              // 731
      //providerLink:   attributes[a]._links.provider.href                                                            //
      self.added('attributes', Random.id(), attribute);                                                               // 737
    }                                                                                                                 // 738
  } catch (error) {                                                                                                   // 739
    console.log('Error in getAttributes');                                                                            // 740
    console.log(error);                                                                                               // 741
  }                                                                                                                   // 742
  console.log('---------------------------------------------------');                                                 // 743
  self.ready();                                                                                                       // 744
});                                                                                                                   // 745
                                                                                                                      //
Meteor.publish('getAttributesBySphere', function (sphereAttributesUrl) {                                              // 747
  console.log('getAttributesBySphere');                                                                               // 748
  var self = this;                                                                                                    // 749
  if (sphereAttributesUrl != null) {                                                                                  // 750
    try {                                                                                                             // 751
      var response = HTTP.get(sphereAttributesUrl, http_options);                                                     // 752
      var content = JSON.parse(response.content);                                                                     // 753
      var attributes = content._embedded.attributes;                                                                  // 754
      for (a in attributes) {                                                                                         // 755
        var attribute = {                                                                                             // 756
          name: attributes[a].name,                                                                                   // 757
          attributesLink: attributes[a]._links.self.href                                                              // 758
        };                                                                                                            // 756
        self.added('attributesBySphere', Random.id(), attribute);                                                     // 760
      }                                                                                                               // 761
    } catch (error) {                                                                                                 // 762
      console.log('Error in getAttributesBySphere');                                                                  // 763
      console.log(error);                                                                                             // 764
    }                                                                                                                 // 765
  }                                                                                                                   // 766
  console.log('---------------------------------------------------');                                                 // 767
  self.ready();                                                                                                       // 768
});                                                                                                                   // 769
                                                                                                                      //
Meteor.publish('getSpheresByUser', function (spheresUrl) {                                                            // 771
  var self = this;                                                                                                    // 772
  console.log('getSpheresByUser');                                                                                    // 773
  console.log(spheresUrl);                                                                                            // 774
  try {                                                                                                               // 775
    var response = HTTP.get(spheresUrl, http_options);                                                                // 776
    var content = JSON.parse(response.content);                                                                       // 777
    var spheresList = content._embedded.spheres;                                                                      // 778
    for (s in spheresList) {                                                                                          // 779
      var sphere = {                                                                                                  // 780
        id: spheresList[s].id,                                                                                        // 781
        name: spheresList[s].name,                                                                                    // 782
        description: spheresList[s].description,                                                                      // 783
        type: spheresList[s].type,                                                                                    // 784
        link: spheresList[s]._links.self.href,                                                                        // 785
        enabled: spheresList[s].enabled,                                                                              // 786
        dataextracted: spheresList[s].dataextracted                                                                   // 787
      };                                                                                                              // 780
      self.added('spheresByUser', sphere.id, sphere);                                                                 // 789
    }                                                                                                                 // 790
  } catch (error) {                                                                                                   // 791
    console.log('Error in getSpheresByUser');                                                                         // 792
    console.log(error);                                                                                               // 793
  }                                                                                                                   // 794
  console.log('---------------------------------------------------');                                                 // 795
  self.ready();                                                                                                       // 796
});                                                                                                                   // 797
                                                                                                                      //
Meteor.publish('getAttributesByProviders', function (providerNames) {                                                 // 799
  var self = this;                                                                                                    // 800
  console.log('getAttributesByProviders');                                                                            // 801
  if (providerNames.length > 0) {                                                                                     // 802
    try {                                                                                                             // 803
      var url = host + slash + attrs + slash + search + slash + findAttributesByProviderNamesList + providerNames.toString();
      var response = HTTP.get(url, http_options);                                                                     // 805
      var content = JSON.parse(response.content);                                                                     // 806
      var attributes = content._embedded.attributes;                                                                  // 807
      for (a in attributes) {                                                                                         // 808
        var attribute = {                                                                                             // 809
          name: attributes[a].name,                                                                                   // 810
          category: attributes[a].categoryName,                                                                       // 811
          subcategory: attributes[a].subcategoryName,                                                                 // 812
          enabled: attributes[a].enabled,                                                                             // 813
          link: attributes[a]._links.self.href                                                                        // 814
        };                                                                                                            // 809
        self.added('attributesByProviders', Random.id(), attribute);                                                  // 816
      }                                                                                                               // 817
    } catch (error) {                                                                                                 // 820
      console.log('error in getAttributesByProviders');                                                               // 821
      console.log(error);                                                                                             // 822
    }                                                                                                                 // 823
  }                                                                                                                   // 824
  console.log('---------------------------------------------------');                                                 // 825
  self.ready();                                                                                                       // 826
});                                                                                                                   // 827
                                                                                                                      //
Meteor.publish('getConsumersByUser', function (consumersUrl) {                                                        // 829
  console.log('getConsumersByUser');                                                                                  // 830
  console.log(consumersUrl);                                                                                          // 831
  var self = this;                                                                                                    // 832
  if (consumersUrl != null) {                                                                                         // 833
    try {                                                                                                             // 834
      var response = HTTP.get(consumersUrl, http_options);                                                            // 835
      var content = JSON.parse(response.content);                                                                     // 836
      var consumers = content._embedded.consumers;                                                                    // 837
                                                                                                                      //
      _.each(consumers, function (consumer) {                                                                         // 839
        var consumerObject = {                                                                                        // 840
          name: consumer.name,                                                                                        // 841
          link: consumer._links.self.href,                                                                            // 842
          description: consumer.description                                                                           // 843
        };                                                                                                            // 840
        self.added('consumersByUser', Random.id(), consumerObject);                                                   // 845
      });                                                                                                             // 846
    } catch (error) {                                                                                                 // 848
      console.log('Error in getConsumersByUser');                                                                     // 849
      console.log(error);                                                                                             // 850
    }                                                                                                                 // 851
  }                                                                                                                   // 852
  console.log('---------------------------------------------------');                                                 // 853
  self.ready();                                                                                                       // 854
});                                                                                                                   // 855
                                                                                                                      //
Meteor.publish('getRegisteredEmailsandRegisteredIds', function () {                                                   // 857
  console.log('getRegisteredEmailsandRegisteredIds');                                                                 // 858
  var self = this;                                                                                                    // 859
  try {                                                                                                               // 860
    var url = host + slash + people;                                                                                  // 861
    var response = HTTP.get(url, http_options);                                                                       // 862
    var content = JSON.parse(response.content);                                                                       // 863
    var users = content._embedded.people;                                                                             // 864
                                                                                                                      //
    _.each(users, function (user) {                                                                                   // 866
      var email = { email: user.email };                                                                              // 867
      self.added('registeredEmails', Random.id(), email);                                                             // 868
      var personal_id = { personal_id: user.personal_id };                                                            // 869
      self.added('registeredIds', Random.id(), personal_id);                                                          // 870
    });                                                                                                               // 871
  } catch (error) {                                                                                                   // 872
    console.log('Error in getRegisteredEmailsandRegisteredIds');                                                      // 873
    console.log(error);                                                                                               // 874
  }                                                                                                                   // 875
  self.ready();                                                                                                       // 876
});                                                                                                                   // 878
                                                                                                                      //
Meteor.publish('getEntities', function () {                                                                           // 880
  console.log('getEntities');                                                                                         // 881
  var self = this;                                                                                                    // 882
  try {                                                                                                               // 883
    var url = host + slash + entities;                                                                                // 884
    var response = HTTP.get(url, http_options);                                                                       // 885
    var content = JSON.parse(response.content);                                                                       // 886
    var entitiesAPI = content._embedded.entities;                                                                     // 887
                                                                                                                      //
    _.each(entitiesAPI, function (entity) {                                                                           // 889
      var entityObject = {                                                                                            // 890
        name: entity.name,                                                                                            // 891
        description: entity.description,                                                                              // 892
        email: entity.email,                                                                                          // 893
        link: entity._links.self.href,                                                                                // 894
        identifier: entity.identifier                                                                                 // 895
      };                                                                                                              // 890
      self.added('entities', entityObject.identifier, entityObject);                                                  // 897
    });                                                                                                               // 898
  } catch (error) {                                                                                                   // 900
    console.log('Error in getEntities');                                                                              // 901
    console.log(error);                                                                                               // 902
  }                                                                                                                   // 903
  self.ready();                                                                                                       // 904
});                                                                                                                   // 905
                                                                                                                      //
// FOR USERS SCREENS                                                                                                  //
Meteor.publish('getEntitiesRequestedFromEntities', function (userEmail) {                                             // 909
  console.log('getEntitiesRequestedFromEntities');                                                                    // 910
  var self = this;                                                                                                    // 911
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
  try {                                                                                                               // 914
    var response = HTTP.get(url, http_options);                                                                       // 915
    var content = JSON.parse(response.content);                                                                       // 916
    var entitiesAPI = content._embedded.entities;                                                                     // 917
                                                                                                                      //
    _.each(entitiesAPI, function (entity) {                                                                           // 919
      var entityObject = {                                                                                            // 920
        name: entity.name,                                                                                            // 921
        description: entity.description,                                                                              // 922
        email: entity.email,                                                                                          // 923
        link: entity._links.self.href,                                                                                // 924
        identifier: entity.identifier                                                                                 // 925
      };                                                                                                              // 920
      self.added('entitiesRequestedFromEntities', entityObject.identifier, entityObject);                             // 927
    });                                                                                                               // 928
  } catch (error) {                                                                                                   // 929
    console.log('Error in getEntitiesRequestedFromEntities');                                                         // 930
    console.log(error);                                                                                               // 931
  }                                                                                                                   // 932
  self.ready();                                                                                                       // 933
});                                                                                                                   // 934
                                                                                                                      //
Meteor.publish('getEntitiesRequestedFromUsers', function (userEmail) {                                                // 936
  console.log('getEntitiesRequestedFromUsers');                                                                       // 937
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                      //
  var self = this;                                                                                                    // 941
  try {                                                                                                               // 942
    var response = HTTP.get(url, http_options);                                                                       // 943
    var content = JSON.parse(response.content);                                                                       // 944
    var entitiesAPI = content._embedded.entities;                                                                     // 945
                                                                                                                      //
    _.each(entitiesAPI, function (entity) {                                                                           // 947
      var entityObject = {                                                                                            // 948
        name: entity.name,                                                                                            // 949
        description: entity.description,                                                                              // 950
        email: entity.email,                                                                                          // 951
        link: entity._links.self.href,                                                                                // 952
        identifier: entity.identifier                                                                                 // 953
      };                                                                                                              // 948
      self.added('entitiesRequestedFromUsers', entityObject.identifier, entityObject);                                // 955
    });                                                                                                               // 956
  } catch (error) {                                                                                                   // 957
    console.log('Error in getEntitiesRequestedFromUsers');                                                            // 958
    console.log(error);                                                                                               // 959
  }                                                                                                                   // 960
  self.ready();                                                                                                       // 961
});                                                                                                                   // 962
                                                                                                                      //
Meteor.publish('getAdminEntities', function (userEmail) {                                                             // 964
  console.log('getAdminEntities');                                                                                    // 965
  var self = this;                                                                                                    // 966
                                                                                                                      //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                      //
  try {                                                                                                               // 971
    var response = HTTP.get(url, http_options);                                                                       // 972
    var content = JSON.parse(response.content);                                                                       // 973
    var entitiesAPI = content._embedded.entities;                                                                     // 974
                                                                                                                      //
    _.each(entitiesAPI, function (entity) {                                                                           // 976
      var entityObject = {                                                                                            // 977
        name: entity.name,                                                                                            // 978
        description: entity.description,                                                                              // 979
        email: entity.email,                                                                                          // 980
        link: entity._links.self.href,                                                                                // 981
        identifier: entity.identifier                                                                                 // 982
      };                                                                                                              // 977
      self.added('adminEntities', entityObject.identifier, entityObject);                                             // 984
    });                                                                                                               // 985
  } catch (error) {                                                                                                   // 986
    console.log('Error in getAdminEntities');                                                                         // 987
    console.log(error);                                                                                               // 988
  }                                                                                                                   // 989
  self.ready();                                                                                                       // 990
});                                                                                                                   // 991
                                                                                                                      //
Meteor.publish('getEntitiesAssociated', function (userEmail) {                                                        // 993
  console.log('getEntitiesAssociated');                                                                               // 994
  var self = this;                                                                                                    // 995
                                                                                                                      //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                      //
  try {                                                                                                               // 1000
    var response = HTTP.get(url, http_options);                                                                       // 1001
    var content = JSON.parse(response.content);                                                                       // 1002
    var entitiesAPI = content._embedded.entities;                                                                     // 1003
                                                                                                                      //
    _.each(entitiesAPI, function (entity) {                                                                           // 1005
      var entityObject = {                                                                                            // 1006
        name: entity.name,                                                                                            // 1007
        description: entity.description,                                                                              // 1008
        email: entity.email,                                                                                          // 1009
        link: entity._links.self.href,                                                                                // 1010
        identifier: entity.identifier                                                                                 // 1011
      };                                                                                                              // 1006
      self.added('entitiesAssociated', entityObject.identifier, entityObject);                                        // 1013
    });                                                                                                               // 1014
  } catch (error) {                                                                                                   // 1015
    console.log('Error in getEntitiesAssociated');                                                                    // 1016
    console.log(error);                                                                                               // 1017
  }                                                                                                                   // 1018
  self.ready();                                                                                                       // 1019
});                                                                                                                   // 1020
                                                                                                                      //
// Published called from entities screens                                                                             //
Meteor.publish('getUsersRequestedFromEntities', function (entityEmail) {                                              // 1026
  console.log('getUsersRequestedFromEntities');                                                                       // 1027
  var self = this;                                                                                                    // 1028
                                                                                                                      //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
                                                                                                                      //
  try {                                                                                                               // 1033
    var response = HTTP.get(url, http_options);                                                                       // 1034
    var content = JSON.parse(response.content);                                                                       // 1035
    var peopleAPI = content._embedded.people;                                                                         // 1036
                                                                                                                      //
    _.each(peopleAPI, function (person) {                                                                             // 1038
      var personObject = {                                                                                            // 1039
        name: person.name,                                                                                            // 1040
        surname: person.surname,                                                                                      // 1041
        email: person.email,                                                                                          // 1042
        link: person._links.self.href,                                                                                // 1043
        id: person.id                                                                                                 // 1044
                                                                                                                      //
      };                                                                                                              // 1039
      self.added('usersRequestedFromEntities', personObject.id, personObject);                                        // 1047
    });                                                                                                               // 1048
  } catch (error) {                                                                                                   // 1049
    console.log('Error in getUsersRequestedFromEntities');                                                            // 1050
    console.log(error);                                                                                               // 1051
  }                                                                                                                   // 1052
  self.ready();                                                                                                       // 1053
});                                                                                                                   // 1054
                                                                                                                      //
Meteor.publish('getUsersRequestedFromUsers', function (entityEmail) {                                                 // 1056
  console.log('getUsersRequestedFromUsers');                                                                          // 1057
  var self = this;                                                                                                    // 1058
                                                                                                                      //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                      //
  try {                                                                                                               // 1063
    var response = HTTP.get(url, http_options);                                                                       // 1064
    var content = JSON.parse(response.content);                                                                       // 1065
    var peopleAPI = content._embedded.people;                                                                         // 1066
                                                                                                                      //
    _.each(peopleAPI, function (person) {                                                                             // 1068
      var personObject = {                                                                                            // 1069
        name: person.name,                                                                                            // 1070
        surname: person.surname,                                                                                      // 1071
        email: person.email,                                                                                          // 1072
        link: person._links.self.href,                                                                                // 1073
        id: person.id                                                                                                 // 1074
      };                                                                                                              // 1069
      self.added('usersRequestedFromUsers', personObject.id, personObject);                                           // 1076
    });                                                                                                               // 1077
  } catch (error) {                                                                                                   // 1078
    console.log('Error in getUsersRequestedFromUsers');                                                               // 1079
    console.log(error);                                                                                               // 1080
  }                                                                                                                   // 1081
  self.ready();                                                                                                       // 1082
});                                                                                                                   // 1083
                                                                                                                      //
Meteor.publish('getAdminUsers', function (entityEmail) {                                                              // 1085
  console.log('getAdminUsers');                                                                                       // 1086
  var self = this;                                                                                                    // 1087
                                                                                                                      //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                      //
  try {                                                                                                               // 1092
    var response = HTTP.get(url, http_options);                                                                       // 1093
    var content = JSON.parse(response.content);                                                                       // 1094
    var peopleAPI = content._embedded.people;                                                                         // 1095
                                                                                                                      //
    _.each(peopleAPI, function (person) {                                                                             // 1097
      var personObject = {                                                                                            // 1098
        id: person.id,                                                                                                // 1099
        name: person.name,                                                                                            // 1100
        surname: person.surname,                                                                                      // 1101
        email: person.email,                                                                                          // 1102
        link: person._links.self.href                                                                                 // 1103
      };                                                                                                              // 1098
      self.added('adminUsers', personObject.id, personObject);                                                        // 1105
    });                                                                                                               // 1106
  } catch (error) {                                                                                                   // 1107
    console.log('Error in getAdminUsers');                                                                            // 1108
    console.log(error);                                                                                               // 1109
  }                                                                                                                   // 1110
  self.ready();                                                                                                       // 1111
});                                                                                                                   // 1112
                                                                                                                      //
Meteor.publish('getUsersAssociated', function (entityEmail) {                                                         // 1114
  console.log('getUsersAssociated');                                                                                  // 1115
  var self = this;                                                                                                    // 1116
                                                                                                                      //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                      //
  try {                                                                                                               // 1121
    var response = HTTP.get(url, http_options);                                                                       // 1122
    var content = JSON.parse(response.content);                                                                       // 1123
    var peopleAPI = content._embedded.people;                                                                         // 1124
                                                                                                                      //
    _.each(peopleAPI, function (person) {                                                                             // 1126
      var personObject = {                                                                                            // 1127
        name: person.name,                                                                                            // 1128
        description: person.description,                                                                              // 1129
        email: person.email,                                                                                          // 1130
        link: person._links.self.href,                                                                                // 1131
        id: person.id                                                                                                 // 1132
      };                                                                                                              // 1127
      self.added('usersAssociated', personObject.id, personObject);                                                   // 1134
    });                                                                                                               // 1135
  } catch (error) {                                                                                                   // 1136
    console.log('Error in getUsersAssociated');                                                                       // 1137
    console.log(error);                                                                                               // 1138
  }                                                                                                                   // 1139
  self.ready();                                                                                                       // 1140
});                                                                                                                   // 1141
                                                                                                                      //
Meteor.publish('getEntitiesWithRelationship', function (userEmail) {                                                  // 1143
  console.log('getEntitiesWithRelationship');                                                                         // 1144
  var self = this;                                                                                                    // 1145
                                                                                                                      //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmail + questionMark + 'email=' + userEmail;
  try {                                                                                                               // 1149
    var response = HTTP.get(url, http_options);                                                                       // 1150
    var content = JSON.parse(response.content);                                                                       // 1151
    var entitiesAPI = content._embedded.entities;                                                                     // 1152
                                                                                                                      //
    _.each(entitiesAPI, function (entity) {                                                                           // 1154
      var entityObject = {                                                                                            // 1155
        name: entity.name,                                                                                            // 1156
        description: entity.description,                                                                              // 1157
        email: entity.email,                                                                                          // 1158
        link: entity._links.self.href,                                                                                // 1159
        identifier: entity.identifier                                                                                 // 1160
      };                                                                                                              // 1155
      self.added('entitiesWithRelationship', entity.identifier, entityObject);                                        // 1162
    });                                                                                                               // 1163
  } catch (error) {                                                                                                   // 1164
    console.log('Error in getEntitiesWithRelationship');                                                              // 1165
    console.log(error);                                                                                               // 1166
  }                                                                                                                   // 1167
  self.ready();                                                                                                       // 1168
});                                                                                                                   // 1169
                                                                                                                      //
Meteor.publish('getPeople', function () {                                                                             // 1172
  console.log('getPeople');                                                                                           // 1173
  var self = this;                                                                                                    // 1174
  try {                                                                                                               // 1175
    var url = host + slash + people;                                                                                  // 1176
    var response = HTTP.get(url, http_options);                                                                       // 1177
    var content = JSON.parse(response.content);                                                                       // 1178
    var peopleAPI = content._embedded.people;                                                                         // 1179
                                                                                                                      //
    _.each(peopleAPI, function (person) {                                                                             // 1181
      var personObject = {                                                                                            // 1182
        name: person.name,                                                                                            // 1183
        email: person.email,                                                                                          // 1184
        link: person._links.self.href,                                                                                // 1185
        id: person.id                                                                                                 // 1186
      };                                                                                                              // 1182
      self.added('people', personObject.id, personObject);                                                            // 1188
    });                                                                                                               // 1189
  } catch (error) {                                                                                                   // 1191
    console.log('Error in getPeople');                                                                                // 1192
    console.log(error);                                                                                               // 1193
  }                                                                                                                   // 1194
  self.ready();                                                                                                       // 1195
});                                                                                                                   // 1196
                                                                                                                      //
Meteor.publish('getPeopleWithRelationship', function (entityEmail) {                                                  // 1198
  console.log('getPeopleWithRelationship');                                                                           // 1199
  var self = this;                                                                                                    // 1200
                                                                                                                      //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                      //
  try {                                                                                                               // 1205
    var response = HTTP.get(url, http_options);                                                                       // 1206
    var content = JSON.parse(response.content);                                                                       // 1207
    var peopleAPI = content._embedded.people;                                                                         // 1208
                                                                                                                      //
    _.each(peopleAPI, function (person) {                                                                             // 1210
      var personObject = {                                                                                            // 1211
        name: person.name,                                                                                            // 1212
        description: person.description,                                                                              // 1213
        email: person.email,                                                                                          // 1214
        link: person._links.self.href,                                                                                // 1215
        id: person.id                                                                                                 // 1216
      };                                                                                                              // 1211
      self.added('peopleWithRelationship', personObject.id, personObject);                                            // 1218
    });                                                                                                               // 1219
  } catch (error) {                                                                                                   // 1220
    console.log('Error in getPeopleWithRelationship');                                                                // 1221
    console.log(error);                                                                                               // 1222
  }                                                                                                                   // 1223
  self.ready();                                                                                                       // 1224
});                                                                                                                   // 1225
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"constants.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/constants.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/*                                                                                                                    //
* CONSTANTS                                                                                                           //
*/                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
* Backend Servers                                                                                                     //
*/                                                                                                                    //
// Localhost                                                                                                          //
//host = 'http://localhost:8080';                                                                                     //
// Developer Server                                                                                                   //
//host = 'http://172.20.49.20:9763/LmpApi'                                                                            //
//Production Server (Backend located in Eurecat)                                                                      //
host = 'http://84.88.76.5:9763/LmpApi';                                                                               // 13
                                                                                                                      //
/**                                                                                                                   //
* Frontend Servers                                                                                                    //
*/                                                                                                                    //
// Localhost                                                                                                          //
//recoverUrl = 'http://localhost:3000/changePassword'                                                                 //
// Arsys web server - change Password ()                                                                              //
recoverUrl = 'http://82.223.80.51:3000/changePassword';                                                               // 21
// Localhost                                                                                                          //
//redirectUrl = 'http://localhost:3000/authorization'                                                                 //
// Arsys web server - change Password ()                                                                              //
redirectUrl = 'http://82.223.80.51:3000/authorization';                                                               // 25
                                                                                                                      //
slash = '/';                                                                                                          // 28
people = 'people';                                                                                                    // 29
person = 'person';                                                                                                    // 30
consumers = 'consumers';                                                                                              // 31
spheres = 'spheres';                                                                                                  // 32
providers = 'providers';                                                                                              // 33
entities = 'entities';                                                                                                // 34
tokens = 'tokens';                                                                                                    // 35
resetPassword = 'resetPassword';                                                                                      // 36
savePassword = 'savePassword';                                                                                        // 37
newToken = 'newToken';                                                                                                // 38
authorizationUrl = 'authorizationUrl';                                                                                // 39
                                                                                                                      //
emailParameter = "email=";                                                                                            // 42
providerNameParameter = 'providerName=';                                                                              // 43
providerParameter = 'provider=';                                                                                      // 44
userParameter = 'user=';                                                                                              // 45
passwordParameter = 'password=';                                                                                      // 46
recoverUrlParameter = 'recoverUrl=';                                                                                  // 47
redirectUrlParameter = 'redirectUrl=';                                                                                // 48
codeParameter = 'code=';                                                                                              // 49
                                                                                                                      //
attrs = 'attributes';                                                                                                 // 51
search = 'search';                                                                                                    // 52
                                                                                                                      //
findByIdentifier = 'findByIdentifier?identifier=';                                                                    // 54
findByEmail = 'findFirstByEmail?email=';                                                                              // 55
findCategoriesByProviderNamesList = 'findCategoriesByProviderNamesList?providerNames=';                               // 56
findAttributesByProviderNamesList = 'findAttributesByProviderNamesList?names=';                                       // 57
findAttributesByProviderName = 'findAttributesByProviderName?name=';                                                  // 58
findTokensByProviderNameAndUserEmail = 'findTokensByProviderNameAndUserEmail';                                        // 59
                                                                                                                      //
findEntitiesByPersonEmailAndState = 'findEntitiesByPersonEmailAndState';                                              // 62
findPeopleByEntityEmailAndState = 'findPeopleByEntityEmailAndState';                                                  // 63
findPersonEntityRelationshipByEntityEmailAndPersonEmail = 'findPersonEntityRelationshipByEntityEmailAndPersonEmail';  // 64
findPersonEntityRelationshipsByEntityEmail = 'findPersonEntityRelationshipsByEntityEmail';                            // 65
findEntitiesByPersonEmail = 'findEntitiesByPersonEmail';                                                              // 66
findPeopleByEntityEmail = 'findPeopleByEntityEmail';                                                                  // 67
                                                                                                                      //
personEntityRelationships = 'personEntityRelationships';                                                              // 69
                                                                                                                      //
loginWithPassword = 'loginWithPassword';                                                                              // 71
                                                                                                                      //
questionMark = '?';                                                                                                   // 73
                                                                                                                      //
ampersand = '&';                                                                                                      // 75
                                                                                                                      //
basic_auth = 'web@hotmail.com:EurecatLMP2016!';                                                                       // 77
                                                                                                                      //
REQUESTED_FROM_ENTITY = 'REQUESTED_FROM_ENTITY';                                                                      // 79
REQUESTED_FROM_USER = 'REQUESTED_FROM_USER';                                                                          // 80
ASSOCIATED = 'ASSOCIATED';                                                                                            // 81
ADMINISTRATOR = 'ADMINISTRATOR';                                                                                      // 82
                                                                                                                      //
// Environment variables                                                                                              //
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';                                                                       // 86
process.env.DISABLE_WEBSOCKETS = 1;                                                                                   // 87
                                                                                                                      //
http_options = { auth: basic_auth };                                                                                  // 90
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/routes.js");
require("./server/LMP.js");
require("./server/constants.js");
//# sourceMappingURL=app.js.map
