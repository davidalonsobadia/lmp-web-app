var require = meteorInstall({"lib":{"collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections.js                                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// Mongo Collections                                                                                                 //
Spheres = new Mongo.Collection('spheres');                                                                           // 2
Providers = new Mongo.Collection('providers');                                                                       // 3
Consumers = new Mongo.Collection('consumers');                                                                       // 4
ConsumersByUser = new Mongo.Collection('consumersByUser');                                                           // 5
ProvidersByUser = new Mongo.Collection('providersByUser');                                                           // 6
Attributes = new Mongo.Collection('attributes');                                                                     // 7
AttributesDefinition = new Mongo.Collection('attributesDefinition');                                                 // 8
                                                                                                                     //
ConsumersInSphere = new Mongo.Collection('consumersInSphere');                                                       // 10
CategoriesByProviders = new Mongo.Collection('categoriesByProviders');                                               // 11
AttributesByProviders = new Mongo.Collection('attributesByProviders');                                               // 12
AttributesBySphere = new Mongo.Collection('attributesBySphere');                                                     // 13
SpheresByUser = new Mongo.Collection('spheresByUser');                                                               // 14
                                                                                                                     //
RegisteredEmails = new Mongo.Collection('registeredEmails');                                                         // 16
RegisteredIds = new Mongo.Collection('registeredIds');                                                               // 17
Entities = new Mongo.Collection('entities');                                                                         // 18
                                                                                                                     //
EntitiesRequestedFromEntities = new Mongo.Collection('entitiesRequestedFromEntities');                               // 21
EntitiesRequestedFromUsers = new Mongo.Collection('entitiesRequestedFromUsers');                                     // 22
AdminEntities = new Mongo.Collection('adminEntities');                                                               // 23
EntitiesAssociated = new Mongo.Collection('entitiesAssociated');                                                     // 24
                                                                                                                     //
EntitiesWithRelationship = new Mongo.Collection('entitiesWithRelationship');                                         // 26
PeopleWithRelationship = new Mongo.Collection('peopleWithRelationship');                                             // 27
                                                                                                                     //
UsersRequestedFromEntities = new Mongo.Collection('usersRequestedFromEntities');                                     // 29
UsersRequestedFromUsers = new Mongo.Collection('usersRequestedFromUsers');                                           // 30
AdminUsers = new Mongo.Collection('adminUsers');                                                                     // 31
UsersAssociated = new Mongo.Collection('usersAssociated');                                                           // 32
                                                                                                                     //
People = new Mongo.Collection('people');                                                                             // 34
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/routes.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
// Router configuration                                                                                              //
Router.configure({                                                                                                   // 3
  loadingTemplate: 'loader',                                                                                         // 4
  defaultBreadcrumbTitle: 'Home',                                                                                    // 5
  defaultBreadcrumbLastLink: true                                                                                    // 6
});                                                                                                                  // 3
                                                                                                                     //
//Routers                                                                                                            //
Router.route('/', {                                                                                                  // 10
  name: 'login',                                                                                                     // 11
  template: 'login'                                                                                                  // 12
});                                                                                                                  // 10
                                                                                                                     //
Router.route('/register', {                                                                                          // 15
  waitOn: function waitOn() {                                                                                        // 16
    return Meteor.subscribe('getRegisteredEmailsandRegisteredIds');                                                  // 17
  }                                                                                                                  // 18
});                                                                                                                  // 15
                                                                                                                     //
Router.route('/home');                                                                                               // 21
                                                                                                                     //
Router.route('/my_spheres', {                                                                                        // 23
  template: 'my_spheres',                                                                                            // 24
  parent: 'home',                                                                                                    // 25
  title: 'My Spheres',                                                                                               // 26
  waitOn: function waitOn() {                                                                                        // 27
    var user = Session.get('user');                                                                                  // 28
    var spheresUrl = user._links.spheres.href;                                                                       // 29
    return Meteor.subscribe('getSpheresByUser', spheresUrl);                                                         // 30
  }                                                                                                                  // 31
});                                                                                                                  // 23
                                                                                                                     //
Router.route('/new_sphere', {                                                                                        // 34
  name: 'new_sphere',                                                                                                // 35
  template: 'new_sphere',                                                                                            // 36
  title: 'new Sphere',                                                                                               // 37
  parent: 'my_spheres',                                                                                              // 38
  waitOn: function waitOn() {                                                                                        // 39
    var user = Session.get('user');                                                                                  // 40
    var providersUrl = user._links.providers.href;                                                                   // 41
    var consumersUrl = user._links.consumers.href;                                                                   // 42
    var attributes = Attributes.find().fetch();                                                                      // 43
    var providers = ProvidersByUser.find().fetch();                                                                  // 44
    var providerLinks = [];                                                                                          // 45
                                                                                                                     //
    var providerNames = [];                                                                                          // 47
                                                                                                                     //
    for (p in providers) {                                                                                           // 49
      var provider = providers[p];                                                                                   // 50
      var providerLink = provider.attributesLink;                                                                    // 51
      providerLinks.push(providerLink);                                                                              // 52
      providerNames.push(provider.name);                                                                             // 53
    }                                                                                                                // 54
                                                                                                                     //
    var sphere = Session.get('sphere');                                                                              // 56
    var sphereAttributesUrl = null;                                                                                  // 57
    var sphereConsumerUrl = null;                                                                                    // 58
    if (sphere != null) {                                                                                            // 59
      sphereAttributesUrl = sphere._links.attributes.href;                                                           // 60
      sphereConsumerUrl = sphere._links.consumers.href;                                                              // 61
    }                                                                                                                // 62
                                                                                                                     //
    var sphereUserUrl = user._links.spheres.href;                                                                    // 64
                                                                                                                     //
    return [/*Meteor.subscribe('getAttributes')                                                                      // 66
            ,*/Meteor.subscribe('getProvidersByUser', providersUrl), Meteor.subscribe('getAttributesByProviders', providerNames), Meteor.subscribe('getAttributesBySphere', sphereAttributesUrl), Meteor.subscribe('getConsumersByUser', consumersUrl), Meteor.subscribe('getConsumersInSphere', sphereConsumerUrl)];
  }                                                                                                                  // 73
});                                                                                                                  // 34
                                                                                                                     //
Router.route('/my_providers', {                                                                                      // 76
  template: 'my_providers',                                                                                          // 77
  title: 'My Providers',                                                                                             // 78
  parent: 'home'                                                                                                     // 79
});                                                                                                                  // 76
                                                                                                                     //
Router.route('/new_provider', {                                                                                      // 82
  template: 'new_provider',                                                                                          // 83
  title: 'New Provider',                                                                                             // 84
  parent: 'my_providers',                                                                                            // 85
  waitOn: function waitOn() {                                                                                        // 86
    var user = Session.get('user');                                                                                  // 87
    var providersUrl = user._links.providers.href;                                                                   // 88
    return [Meteor.subscribe('getProviders'), Meteor.subscribe('getProvidersByUser', providersUrl)];                 // 89
  }                                                                                                                  // 92
});                                                                                                                  // 82
                                                                                                                     //
Router.route('/my_consumers', {                                                                                      // 95
  template: 'my_consumers',                                                                                          // 96
  parent: 'home',                                                                                                    // 97
  title: 'Consumers'                                                                                                 // 98
});                                                                                                                  // 95
                                                                                                                     //
Router.route('/new_consumer', {                                                                                      // 101
  template: 'new_consumer',                                                                                          // 102
  title: 'New Consumer',                                                                                             // 103
  parent: 'my_consumers',                                                                                            // 104
  waitOn: function waitOn() {                                                                                        // 105
    var user = Session.get('user');                                                                                  // 106
    var consumersUrl = user._links.consumers.href;                                                                   // 107
    return [Meteor.subscribe('getConsumers'), Meteor.subscribe('getConsumersByUser', consumersUrl)];                 // 108
  }                                                                                                                  // 112
});                                                                                                                  // 101
                                                                                                                     //
Router.route('/my_profile', {                                                                                        // 115
  template: 'my_profile',                                                                                            // 116
  title: 'My Profile',                                                                                               // 117
  parent: 'home',                                                                                                    // 118
  data: function data() {                                                                                            // 119
    return Session.get('user');                                                                                      // 120
  }                                                                                                                  // 121
});                                                                                                                  // 115
                                                                                                                     //
Router.route('/my_entities', {                                                                                       // 124
  template: 'my_entities',                                                                                           // 125
  title: 'My Entities',                                                                                              // 126
  parent: 'home'                                                                                                     // 127
});                                                                                                                  // 124
                                                                                                                     //
Router.route('/new_entity', {                                                                                        // 130
  template: 'new_entity',                                                                                            // 131
  title: 'New Entity',                                                                                               // 132
  parent: 'my_entities',                                                                                             // 133
  waitOn: function waitOn() {                                                                                        // 134
    var userEmail = Session.get('user').email;                                                                       // 135
    return [Meteor.subscribe('getEntities'), Meteor.subscribe('getEntitiesWithRelationship', userEmail)];            // 136
  }                                                                                                                  // 140
});                                                                                                                  // 130
                                                                                                                     //
Router.route('/entity_profile', {                                                                                    // 143
  template: 'entity_profile',                                                                                        // 144
  title: 'Entity Profile',                                                                                           // 145
  parent: 'home',                                                                                                    // 146
  data: function data() {                                                                                            // 147
    return Session.get('user');                                                                                      // 148
  }                                                                                                                  // 149
});                                                                                                                  // 143
                                                                                                                     //
Router.route('/people', {                                                                                            // 152
  template: 'people',                                                                                                // 153
  title: 'People',                                                                                                   // 154
  parent: 'home',                                                                                                    // 155
  data: function data() {                                                                                            // 156
    return Session.get('user');                                                                                      // 157
  }                                                                                                                  // 158
});                                                                                                                  // 152
                                                                                                                     //
Router.route('/new_person', {                                                                                        // 161
  template: 'new_person',                                                                                            // 162
  title: 'New User',                                                                                                 // 163
  parent: 'people',                                                                                                  // 164
  waitOn: function waitOn() {                                                                                        // 165
    var entityEmail = Session.get('user').email;                                                                     // 166
    return [Meteor.subscribe('getPeople'), Meteor.subscribe('getPeopleWithRelationship', entityEmail)];              // 167
  }                                                                                                                  // 171
});                                                                                                                  // 161
                                                                                                                     //
var loginRequired = function loginRequired() {                                                                       // 174
  var userSession = Session.get('user');                                                                             // 175
  if (userSession != null && userSession != undefined) {                                                             // 176
    this.next();                                                                                                     // 177
  } else {                                                                                                           // 178
    Router.go('login');                                                                                              // 179
  }                                                                                                                  // 180
};                                                                                                                   // 181
Router.onBeforeAction(loginRequired, { except: ['login', 'register'] });                                             // 182
                                                                                                                     //
var cleanSphereSessionVariable = function cleanSphereSessionVariable() {};                                           // 184
                                                                                                                     //
Router.onAfterAction(cleanSphereSessionVariable, { except: ['newSphere'] });                                         // 186
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"LMP.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/LMP.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
//declare a simple async function                                                                                    //
function delayedMessge(delay, message, callback) {                                                                   // 2
  setTimeout(function () {                                                                                           // 3
    callback(null, message);                                                                                         // 4
  }, delay);                                                                                                         // 5
}                                                                                                                    // 6
                                                                                                                     //
Meteor.methods({                                                                                                     // 10
                                                                                                                     //
  'upsertSphere': function upsertSphere(sphereObject, httpCommand) {                                                 // 12
    if (httpCommand == 'POST') {                                                                                     // 13
      var url = host + slash + spheres;                                                                              // 14
      var response = HTTP.post(url, {                                                                                // 15
        data: {                                                                                                      // 16
          identifier: sphereObject.identifier,                                                                       // 17
          name: sphereObject.name,                                                                                   // 18
          description: sphereObject.description,                                                                     // 19
          type: sphereObject.type,                                                                                   // 20
          enabled: sphereObject.isEnabled,                                                                           // 21
          deleted: sphereObject.isDeleted,                                                                           // 22
          dataextracted: sphereObject.isDataExtracted                                                                // 23
        },                                                                                                           // 16
        auth: basic_auth                                                                                             // 25
      });                                                                                                            // 15
      return response;                                                                                               // 27
    } else {                                                                                                         // 29
      var response = HTTP.put(sphereObject.url, {                                                                    // 30
        data: {                                                                                                      // 31
          identifier: sphereObject.identifier,                                                                       // 32
          name: sphereObject.name,                                                                                   // 33
          description: sphereObject.description,                                                                     // 34
          type: sphereObject.type,                                                                                   // 35
          enabled: sphereObject.isEnabled,                                                                           // 36
          deleted: sphereObject.isDeleted,                                                                           // 37
          dataextracted: sphereObject.isDataExtracted                                                                // 38
        },                                                                                                           // 31
        auth: basic_auth                                                                                             // 40
      });                                                                                                            // 30
      return response;                                                                                               // 42
    }                                                                                                                // 43
  },                                                                                                                 // 44
                                                                                                                     //
  'upsertEntity': function upsertEntity(entityObject, userUrl) {                                                     // 46
    var url = host + slash + entities;                                                                               // 47
                                                                                                                     //
    var response = HTTP.post(url, {                                                                                  // 49
      data: {                                                                                                        // 50
        identifier: entityObject.identifier,                                                                         // 51
        name: entityObject.name,                                                                                     // 52
        description: entityObject.description,                                                                       // 53
        email: entityObject.email                                                                                    // 54
      },                                                                                                             // 50
      auth: basic_auth                                                                                               // 56
    });                                                                                                              // 49
    var location = response.headers.location;                                                                        // 58
    return location;                                                                                                 // 59
  },                                                                                                                 // 60
                                                                                                                     //
  'updateEntityRequests': function updateEntityRequests(userUrl, entityUrls) {                                       // 62
    console.log('in updateEntityRequests');                                                                          // 63
                                                                                                                     //
    var entityUrlString = _.map(entityUrls, function (url) {                                                         // 65
      return url + '\n';                                                                                             // 66
    }).join('').trim();                                                                                              // 67
                                                                                                                     //
    var response = HTTP.put(userUrl, {                                                                               // 69
      headers: {                                                                                                     // 70
        "Content-Type": "text/uri-list"                                                                              // 71
      },                                                                                                             // 70
      content: entityUrlString,                                                                                      // 73
      auth: basic_auth                                                                                               // 74
    });                                                                                                              // 69
    return response;                                                                                                 // 76
  },                                                                                                                 // 77
                                                                                                                     //
  'updateEntity': function updateEntity(entityObject, entityUrl) {                                                   // 79
    var response = HTTP.patch(entityUrl, {                                                                           // 80
      data: {                                                                                                        // 81
        name: entityObject.name,                                                                                     // 82
        description: entityObject.description,                                                                       // 83
        email: entityObject.email                                                                                    // 84
      },                                                                                                             // 81
      auth: basic_auth                                                                                               // 86
    });                                                                                                              // 80
  },                                                                                                                 // 88
                                                                                                                     //
  'joinSphereAndConsumer': function joinSphereAndConsumer(sphereConsumerUrl, consumersUrl) {                         // 90
    var urlConsumersString = '';                                                                                     // 91
    for (url in consumersUrl) {                                                                                      // 92
      urlConsumersString += consumersUrl[url] + '\n';                                                                // 93
    }                                                                                                                // 94
                                                                                                                     //
    return HTTP.put(sphereConsumerUrl, {                                                                             // 96
      headers: {                                                                                                     // 97
        "Content-Type": "text/uri-list"                                                                              // 98
      },                                                                                                             // 97
      content: urlConsumersString,                                                                                   // 100
      auth: basic_auth                                                                                               // 101
    });                                                                                                              // 96
  },                                                                                                                 // 103
                                                                                                                     //
  'joinSphereAndAttributes': function joinSphereAndAttributes(sphereAttributesUrl, attributesUrl) {                  // 105
    var urlAttributesString = '';                                                                                    // 106
    for (url in attributesUrl) {                                                                                     // 107
      urlAttributesString += attributesUrl[url] + '\n';                                                              // 108
    }                                                                                                                // 109
                                                                                                                     //
    return HTTP.put(sphereAttributesUrl, {                                                                           // 111
      headers: {                                                                                                     // 112
        "Content-Type": "text/uri-list"                                                                              // 113
      },                                                                                                             // 112
      content: urlAttributesString,                                                                                  // 115
      auth: basic_auth                                                                                               // 116
    });                                                                                                              // 111
  },                                                                                                                 // 119
                                                                                                                     //
  'upsertProvider': function upsertProvider(providerObject) {                                                        // 121
    var url = host + slash + providers;                                                                              // 122
    var response = HTTP.post(url, {                                                                                  // 123
      data: {                                                                                                        // 124
        identifier: providerObject.identifier,                                                                       // 125
        name: providerObject.name,                                                                                   // 126
        description: providerObject.description,                                                                     // 127
        url: providerObject.url,                                                                                     // 128
        isEnabled: providerObject.isEnabled,                                                                         // 129
        isDeleted: providerObject.isDeleted                                                                          // 130
      },                                                                                                             // 124
      auth: basic_auth                                                                                               // 132
    });                                                                                                              // 123
    return response;                                                                                                 // 134
  },                                                                                                                 // 135
                                                                                                                     //
  'joinPersonAndProvider': function joinPersonAndProvider(urlProviderPerson, urlProviders) {                         // 137
    var urlProvidersString = '';                                                                                     // 138
    for (url in urlProviders) {                                                                                      // 139
      urlProvidersString += urlProviders[url] + '\n';                                                                // 140
    }                                                                                                                // 141
    console.log(urlProviderPerson);                                                                                  // 142
    console.log(urlProvidersString);                                                                                 // 143
    return HTTP.put(urlProviderPerson, {                                                                             // 144
      headers: {                                                                                                     // 145
        "Content-Type": " text/uri-list",                                                                            // 146
        "auth": "web@hotmail.com:EurecatLMP2016!"                                                                    // 147
      },                                                                                                             // 145
      content: urlProvidersString,                                                                                   // 149
      auth: basic_auth                                                                                               // 150
    });                                                                                                              // 144
  },                                                                                                                 // 152
                                                                                                                     //
  'deletePersonAndProviderRelation': function deletePersonAndProviderRelation(providerId, userId) {                  // 154
    console.log('deletePersonAndProviderRelation');                                                                  // 155
    var url = host + slash + "delete/provider/" + providerId + "/user/" + userId;                                    // 156
                                                                                                                     //
    return HTTP.get(url, http_options);                                                                              // 158
  },                                                                                                                 // 159
                                                                                                                     //
  'joinPersonAndConsumer': function joinPersonAndConsumer(urlConsumerPerson, urlConsumers) {                         // 161
    var urlConsumersString = '';                                                                                     // 162
    for (url in urlConsumers) {                                                                                      // 163
      urlConsumersString += urlConsumers[url] + '\n';                                                                // 164
    }                                                                                                                // 165
    console.log('joinPersonAndConsumer');                                                                            // 166
    console.log(urlConsumersString);                                                                                 // 167
    console.log('---------------------------------------------------');                                              // 168
    return HTTP.put(urlConsumerPerson, {                                                                             // 169
      headers: {                                                                                                     // 170
        "Content-Type": "text/uri-list"                                                                              // 171
      },                                                                                                             // 170
      content: urlConsumersString,                                                                                   // 173
      auth: basic_auth                                                                                               // 174
    });                                                                                                              // 169
  },                                                                                                                 // 176
                                                                                                                     //
  'joinPersonAndSphere': function joinPersonAndSphere(urlSpherePerson, urlSpheres) {                                 // 178
    var urlSpheresString = '';                                                                                       // 179
    console.log('joinPersonAndSphere');                                                                              // 180
    for (url in urlSpheres) {                                                                                        // 181
      urlSpheresString += urlSpheres[url] + '\n';                                                                    // 182
    }                                                                                                                // 183
    console.log(urlSpheresString);                                                                                   // 184
    return HTTP.put(urlSpherePerson, {                                                                               // 185
      headers: {                                                                                                     // 186
        "Content-Type": "text/uri-list"                                                                              // 187
      },                                                                                                             // 186
      content: urlSpheresString,                                                                                     // 189
      auth: basic_auth                                                                                               // 190
    });                                                                                                              // 185
  },                                                                                                                 // 192
                                                                                                                     //
  'upsertConsumer': function upsertConsumer(consumerObject) {                                                        // 194
    var url = host + slash + consumers;                                                                              // 195
    var response = HTTP.post(url, {                                                                                  // 196
      data: {                                                                                                        // 197
        identifier: consumerObject.identifier,                                                                       // 198
        name: consumerObject.name,                                                                                   // 199
        description: consumerObject.description,                                                                     // 200
        isEnabled: consumerObject.isEnabled,                                                                         // 201
        isDeleted: consumerObject.isDeleted                                                                          // 202
      },                                                                                                             // 197
      auth: basic_auth                                                                                               // 204
    });                                                                                                              // 196
    return response;                                                                                                 // 206
  },                                                                                                                 // 207
                                                                                                                     //
  'updateSphereEnabled': function updateSphereEnabled(enabled, sphereUrl) {                                          // 209
    var response = HTTP.patch(sphereUrl, {                                                                           // 210
      data: {                                                                                                        // 211
        enabled: enabled                                                                                             // 212
      },                                                                                                             // 211
      http_options: http_options                                                                                     // 214
    });                                                                                                              // 210
    return response;                                                                                                 // 216
  },                                                                                                                 // 217
                                                                                                                     //
  'updateProviderEnabled': function updateProviderEnabled(enabled, providerUrl) {                                    // 219
    var response = HTTP.patch(providerUrl, {                                                                         // 220
      data: {                                                                                                        // 221
        enabled: enabled                                                                                             // 222
      },                                                                                                             // 221
      auth: basic_auth                                                                                               // 224
    });                                                                                                              // 220
    return response;                                                                                                 // 226
  },                                                                                                                 // 227
                                                                                                                     //
  'registerUser': function registerUser(personObject) {                                                              // 229
    var _id = Meteor.userId();                                                                                       // 230
    var url = host + slash + people + slash;                                                                         // 231
    var response = HTTP.post(url, {                                                                                  // 232
      data: {                                                                                                        // 233
        identifier: _id,                                                                                             // 234
        name: personObject.name,                                                                                     // 235
        surname: personObject.surname,                                                                               // 236
        phone: personObject.phone,                                                                                   // 237
        email: personObject.email,                                                                                   // 238
        password: personObject.password,                                                                             // 239
        identifier: personObject.personal_id                                                                         // 240
      },                                                                                                             // 233
      auth: basic_auth                                                                                               // 242
    }, function (error, response) {                                                                                  // 232
      if (error) {                                                                                                   // 244
        console.log('Error in registerUser');                                                                        // 245
        console.log(error);                                                                                          // 246
      } else {                                                                                                       // 247
        console.log('User added correctly!');                                                                        // 248
        console.log(response);                                                                                       // 249
      }                                                                                                              // 250
    });                                                                                                              // 251
  },                                                                                                                 // 252
                                                                                                                     //
  'loginWithPassword': function (_loginWithPassword) {                                                               // 254
    function loginWithPassword(_x) {                                                                                 // 254
      return _loginWithPassword.apply(this, arguments);                                                              // 254
    }                                                                                                                // 254
                                                                                                                     //
    loginWithPassword.toString = function () {                                                                       // 254
      return _loginWithPassword.toString();                                                                          // 254
    };                                                                                                               // 254
                                                                                                                     //
    return loginWithPassword;                                                                                        // 254
  }(function (loginObject) {                                                                                         // 254
    var url = host + slash + loginWithPassword + questionMark + userParameter + loginObject.email + ampersand + passwordParameter + loginObject.password;
    console.log(url);                                                                                                // 257
    try {                                                                                                            // 258
      var response = HTTP.get(url, http_options);                                                                    // 259
      console.log(response);                                                                                         // 260
                                                                                                                     //
      var code = JSON.parse(response.statusCode);                                                                    // 262
      if (code == undefined || code == null) {                                                                       // 263
        throw new Meteor.Error('400', 'User not found', 'Bad request. Please check with your administrator.');       // 264
        return;                                                                                                      // 265
      } else if (code == 401) {                                                                                      // 266
        throw new Meteor.Error('401', 'Unauthorized access', 'Wrogn authentication');                                // 267
        return;                                                                                                      // 268
      }                                                                                                              // 269
                                                                                                                     //
      var getUserUrl = host + slash + people + slash + search + slash + findByEmail + loginObject.email;             // 271
      console.log(getUserUrl);                                                                                       // 273
      var response = HTTP.get(getUserUrl, http_options);                                                             // 274
      var user = JSON.parse(response.content);                                                                       // 275
      if (user == undefined || user == null) {                                                                       // 276
        throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                           // 277
      }                                                                                                              // 278
      return user;                                                                                                   // 279
    } catch (error) {                                                                                                // 280
      console.log('Error while authenticating the user... ' + error);                                                // 281
      throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                             // 282
    }                                                                                                                // 283
  }),                                                                                                                // 284
                                                                                                                     //
  'getSpheresByPerson': function getSpheresByPerson(spheresUrl) {                                                    // 286
    try {                                                                                                            // 287
      var response = HTTP.get(spheresUrl, http_options);                                                             // 288
      var content = JSON.parse(response.content);                                                                    // 290
      var spheresList = content._embedded.spheres;                                                                   // 291
      return spheresList;                                                                                            // 292
    } catch (error) {                                                                                                // 293
      console.log(error);                                                                                            // 294
    }                                                                                                                // 295
    return [];                                                                                                       // 296
  },                                                                                                                 // 297
                                                                                                                     //
  'getSphere': function getSphere(sphereUrl) {                                                                       // 299
    try {                                                                                                            // 300
      var response = HTTP.get(sphereUrl, http_options);                                                              // 301
      var content = JSON.parse(response.content);                                                                    // 303
      return content;                                                                                                // 304
    } catch (error) {                                                                                                // 305
      console.log(error);                                                                                            // 306
    }                                                                                                                // 307
    return '';                                                                                                       // 308
  },                                                                                                                 // 309
                                                                                                                     //
  'updateUser': function updateUser(user) {                                                                          // 311
    HTTP.put(user.link, {                                                                                            // 312
      data: {                                                                                                        // 313
        name: user.name,                                                                                             // 314
        surname: user.surname,                                                                                       // 315
        phone: user.phone,                                                                                           // 316
        email: user.email,                                                                                           // 317
        password: user.password,                                                                                     // 318
        personal_id: user.personal_id                                                                                // 319
      },                                                                                                             // 313
      auth: basic_auth                                                                                               // 321
    });                                                                                                              // 312
  },                                                                                                                 // 323
                                                                                                                     //
  'getConsumersByUser': function getConsumersByUser(consumersUrl) {                                                  // 325
    try {                                                                                                            // 326
      var response = HTTP.get(consumersUrl, http_options);                                                           // 327
      var content = JSON.parse(response.content);                                                                    // 329
      var consumersList = content._embedded.consumers;                                                               // 330
      return consumersList;                                                                                          // 331
    } catch (error) {                                                                                                // 332
      console.log(error);                                                                                            // 333
    }                                                                                                                // 334
    return [];                                                                                                       // 335
  },                                                                                                                 // 336
                                                                                                                     //
  'joinPersonAndEntities': function joinPersonAndEntities(urlPersonEntities, entitiesUrl) {                          // 338
    var urlEntitiesString = '';                                                                                      // 339
    for (url in entitiesUrl) {                                                                                       // 340
      urlEntitiesString += entitiesUrl[url] + '\n';                                                                  // 341
    }                                                                                                                // 342
    return HTTP.put(urlPersonEntities, {                                                                             // 343
      headers: {                                                                                                     // 344
        "Content-Type": "text/uri-list"                                                                              // 345
      },                                                                                                             // 344
      content: urlEntitiesString,                                                                                    // 347
      auth: basic_auth                                                                                               // 348
    });                                                                                                              // 343
  },                                                                                                                 // 350
                                                                                                                     //
  'getAndDeletePersonOrganizationRelationshipsByEntityEmail': function getAndDeletePersonOrganizationRelationshipsByEntityEmail(entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipsByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                     //
    var response = HTTP.get(url, http_options);                                                                      // 357
    var content = JSON.parse(response.content);                                                                      // 359
    var associations = content._embedded.personEntityRelationships;                                                  // 360
                                                                                                                     //
    _.each(associations, function (association) {                                                                    // 362
      var associationLink = association._links.self.href;                                                            // 363
      HTTP.call('DELETE', associationLink, http_options);                                                            // 364
    });                                                                                                              // 365
    return content;                                                                                                  // 366
  },                                                                                                                 // 367
                                                                                                                     //
  'deleteEntity': function deleteEntity(entityUrl) {                                                                 // 369
    var response = HTTP.call('DELETE', entityUrl, http_options);                                                     // 370
  },                                                                                                                 // 371
                                                                                                                     //
  'getEntity': function getEntity(entityUrl) {                                                                       // 373
    var response = HTTP.get(entityUrl, http_options);                                                                // 374
    var entity = JSON.parse(response.content);                                                                       // 375
    if (entity == undefined || entity == null) {                                                                     // 376
      throw new Meteor.Error('404', 'Entity not found', 'Entity not found in the Database');                         // 377
    }                                                                                                                // 378
    return entity;                                                                                                   // 379
  },                                                                                                                 // 380
                                                                                                                     //
  'getPersonOrganizationRelationshipByEntityEmailAndPersonEmail': function getPersonOrganizationRelationshipByEntityEmailAndPersonEmail(userEmail, entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipByEntityEmailAndPersonEmail + questionMark + 'entityEmail=' + entityEmail + ampersand + 'personEmail=' + userEmail;
    var response = HTTP.get(url, http_options);                                                                      // 386
    var content = JSON.parse(response.content);                                                                      // 387
    var associationLink = content._links.self.href;                                                                  // 388
    return associationLink;                                                                                          // 389
  },                                                                                                                 // 390
                                                                                                                     //
  'changePersonOrganizationState': function changePersonOrganizationState(associationLink, state) {                  // 392
    HTTP.patch(associationLink, {                                                                                    // 393
      data: {                                                                                                        // 394
        state: state                                                                                                 // 395
      },                                                                                                             // 394
      auth: basic_auth                                                                                               // 397
    });                                                                                                              // 393
  },                                                                                                                 // 399
                                                                                                                     //
  'deletePersonOrganizationRelationship': function deletePersonOrganizationRelationship(associationLink) {           // 401
    console.log('deleting personOrganizationRelationship...');                                                       // 402
    var response = HTTP.call('delete', associationLink, http_options);                                               // 403
  },                                                                                                                 // 404
                                                                                                                     //
  'insertPersonOrganizationRelationship': function insertPersonOrganizationRelationship(userUrl, entityUrl, state) {
    console.log('insertPersonOrganizationRelationship');                                                             // 407
                                                                                                                     //
    var personEntityRelationshipsUrl = host + slash + personEntityRelationships;                                     // 409
                                                                                                                     //
    var response = HTTP.post(personEntityRelationshipsUrl, {                                                         // 411
      data: {                                                                                                        // 412
        state: state,                                                                                                // 413
        organization: entityUrl,                                                                                     // 414
        person: userUrl                                                                                              // 415
      },                                                                                                             // 412
      auth: basic_auth                                                                                               // 417
    });                                                                                                              // 411
    return response;                                                                                                 // 419
  },                                                                                                                 // 420
                                                                                                                     //
  'findTokenByproviderNameAndUserEmail': function findTokenByproviderNameAndUserEmail(providerName, email) {         // 422
    console.log('in findTokenByproviderNameAndUserEmail');                                                           // 423
                                                                                                                     //
    var url = host + slash + providerTokens + slash + search + slash + findByproviderNameAndUserEmail + questionMark + providerNameParameter + providerName + ampersand + emailParameter + email;
                                                                                                                     //
    try {                                                                                                            // 428
      var response = HTTP.get(url, http_options);                                                                    // 429
      var content = JSON.parse(response.content);                                                                    // 430
      var token = content.token;                                                                                     // 431
      return token;                                                                                                  // 432
    } catch (error) {                                                                                                // 433
      return null;                                                                                                   // 434
    }                                                                                                                // 435
  },                                                                                                                 // 436
                                                                                                                     //
  'createNewToken': function (_createNewToken) {                                                                     // 438
    function createNewToken(_x2, _x3) {                                                                              // 438
      return _createNewToken.apply(this, arguments);                                                                 // 438
    }                                                                                                                // 438
                                                                                                                     //
    createNewToken.toString = function () {                                                                          // 438
      return _createNewToken.toString();                                                                             // 438
    };                                                                                                               // 438
                                                                                                                     //
    return createNewToken;                                                                                           // 438
  }(function (providerName, email) {                                                                                 // 438
    var url = host + slash + createNewToken + questionMark + providerParameter + providerName + ampersand + emailParameter + email;
                                                                                                                     //
    try {                                                                                                            // 442
      return url;                                                                                                    // 443
    } catch (error) {                                                                                                // 444
      console.log(error);                                                                                            // 445
      return null;                                                                                                   // 446
    }                                                                                                                // 447
  })                                                                                                                 // 448
});                                                                                                                  // 10
                                                                                                                     //
Meteor.publish('getConsumers', function () {                                                                         // 451
  var self = this;                                                                                                   // 452
  var url = host + slash + consumers;                                                                                // 453
  try {                                                                                                              // 454
    var response = HTTP.get(url, http_options);                                                                      // 455
    var content = JSON.parse(response.content);                                                                      // 456
    var consumersList = content._embedded.consumers;                                                                 // 457
    for (c in consumersList) {                                                                                       // 458
      var consumer = {                                                                                               // 459
        name: consumersList[c].name,                                                                                 // 460
        description: consumersList[c].description,                                                                   // 461
        link: consumersList[c]._links.consumer.href                                                                  // 462
      };                                                                                                             // 459
      self.added('consumers', Random.id(), consumer);                                                                // 464
    }                                                                                                                // 465
    self.ready();                                                                                                    // 466
  } catch (error) {                                                                                                  // 467
    console.log('Error in getConsumers');                                                                            // 468
    console.log(error);                                                                                              // 469
  }                                                                                                                  // 470
});                                                                                                                  // 471
                                                                                                                     //
Meteor.publish('getSpheres', function () {                                                                           // 473
  var self = this;                                                                                                   // 474
  var url = host + slash + spheres;                                                                                  // 475
  try {                                                                                                              // 476
    var response = HTTP.get(url, http_options);                                                                      // 477
    var content = JSON.parse(response.content);                                                                      // 478
    spheresList = content._embedded.spheres;                                                                         // 479
    for (s in spheresList) {                                                                                         // 480
      var sphere = {                                                                                                 // 481
        name: spheresList[c].name,                                                                                   // 482
        description: spheresList[c].description,                                                                     // 483
        type: spheresList[c].type                                                                                    // 484
      };                                                                                                             // 481
      self.added('spheres', Random.id(), sphere);                                                                    // 486
    }                                                                                                                // 487
    self.ready();                                                                                                    // 488
  } catch (error) {                                                                                                  // 489
    console.log('Error in getSpheres');                                                                              // 490
    console.log(error);                                                                                              // 491
  }                                                                                                                  // 492
});                                                                                                                  // 493
                                                                                                                     //
Meteor.publish('getProviders', function () {                                                                         // 495
  console.log('getProviders');                                                                                       // 496
  var self = this;                                                                                                   // 497
  var url = host + slash + providers;                                                                                // 498
  try {                                                                                                              // 499
    var response = HTTP.get(url, http_options);                                                                      // 500
    var content = JSON.parse(response.content);                                                                      // 501
    var providersList = content._embedded.providers;                                                                 // 502
    for (p in providersList) {                                                                                       // 503
                                                                                                                     //
      var provider = {                                                                                               // 505
        name: providersList[p].name,                                                                                 // 506
        description: providersList[p].description,                                                                   // 507
        type: providersList[p].type,                                                                                 // 508
        url: providersList[p].url,                                                                                   // 509
        enabled: providersList[p].enabled,                                                                           // 510
        deleted: providersList[p].deleted,                                                                           // 511
        link: providersList[p]._links.provider.href,                                                                 // 512
        oAuth: providersList[p].oAuth,                                                                               // 513
        oAuthUrl: providersList[p].oAuthUrl                                                                          // 514
      };                                                                                                             // 505
      self.added('providers', Random.id(), provider);                                                                // 516
    }                                                                                                                // 517
    self.ready();                                                                                                    // 518
  } catch (error) {                                                                                                  // 519
    console.log('Error in getProviders');                                                                            // 520
    console.log(error);                                                                                              // 521
  }                                                                                                                  // 522
});                                                                                                                  // 523
                                                                                                                     //
Meteor.publish('getProvidersByUser', function (providersUrl) {                                                       // 525
  console.log('getProvidersByUser');                                                                                 // 526
  var self = this;                                                                                                   // 527
  if (providersUrl != null) {                                                                                        // 528
    try {                                                                                                            // 529
      var response = HTTP.get(providersUrl, http_options);                                                           // 530
      var content = JSON.parse(response.content);                                                                    // 531
      var providersList = content._embedded.providers;                                                               // 532
                                                                                                                     //
      for (p in providersList) {                                                                                     // 534
        var provider = {                                                                                             // 535
          id: providersList[p].id,                                                                                   // 536
          name: providersList[p].name,                                                                               // 537
          description: providersList[p].description,                                                                 // 538
          type: providersList[p].type,                                                                               // 539
          url: providersList[p].url,                                                                                 // 540
          enabled: providersList[p].enabled,                                                                         // 541
          deleted: providersList[p].deleted,                                                                         // 542
          link: providersList[p]._links.provider.href,                                                               // 543
          attributesLink: providersList[p]._links.attributeMaps.href                                                 // 544
        };                                                                                                           // 535
        self.added('providersByUser', Random.id(), provider);                                                        // 546
      }                                                                                                              // 547
    } catch (error) {                                                                                                // 548
      console.log('Error in getProvidersByUser');                                                                    // 549
      console.log(error);                                                                                            // 550
    }                                                                                                                // 551
  }                                                                                                                  // 552
  console.log('---------------------------------------------------');                                                // 553
  self.ready();                                                                                                      // 554
});                                                                                                                  // 555
                                                                                                                     //
Meteor.publish('getConsumersInSphere', function (sphereConsumersUrl) {                                               // 557
  var self = this;                                                                                                   // 558
  if (sphereConsumersUrl != null) {                                                                                  // 559
    try {                                                                                                            // 560
      var response = HTTP.get(sphereConsumersUrl, http_options);                                                     // 561
      var content = JSON.parse(response.content);                                                                    // 562
      var consumers = content._embedded.consumers;                                                                   // 563
      for (c in consumers) {                                                                                         // 564
        var consumer = {                                                                                             // 565
          name: consumers[c].name,                                                                                   // 566
          link: consumers[c]._links.self.href                                                                        // 567
        };                                                                                                           // 565
        self.added('consumersInSphere', Random.id(), consumer);                                                      // 569
      }                                                                                                              // 570
    } catch (error) {                                                                                                // 571
      console.log('Error in getConsumersInSphere');                                                                  // 572
      console.log(error);                                                                                            // 573
    }                                                                                                                // 574
  }                                                                                                                  // 575
  self.ready();                                                                                                      // 576
});                                                                                                                  // 577
                                                                                                                     //
Meteor.publish('getCategoriesByProviders', function (providerNames) {                                                // 579
  console.log('getCategoriesByProviders');                                                                           // 580
  var self = this;                                                                                                   // 581
  var url = host + slash + providers + slash + search + slash + findCategoriesByProviderNamesList + providerNames;   // 582
  try {                                                                                                              // 583
    var response = HTTP.get(url, http_options);                                                                      // 584
    var content = JSON.parse(response.content);                                                                      // 585
    var attributeCategories = content._embedded.attributeCategories;                                                 // 586
    for (a in attributeCategories) {                                                                                 // 587
      var attribute = {                                                                                              // 588
        name: attributeCategories[a].name                                                                            // 589
      };                                                                                                             // 588
      self.added('categoriesByProviders', Random.id(), attribute);                                                   // 591
    }                                                                                                                // 592
  } catch (error) {                                                                                                  // 593
    console.log('Error in getCategoriesByProviders');                                                                // 594
    console.log(error);                                                                                              // 595
  }                                                                                                                  // 596
  console.log('---------------------------------------------------');                                                // 597
  self.ready();                                                                                                      // 598
});                                                                                                                  // 599
                                                                                                                     //
Meteor.publish('getAttributes', function () {                                                                        // 601
  console.log('getAttributes');                                                                                      // 602
  var self = this;                                                                                                   // 603
  var url = host + slash + attrs;                                                                                    // 604
  try {                                                                                                              // 605
    var response = HTTP.get(url, http_options);                                                                      // 606
    var content = JSON.parse(response.content);                                                                      // 607
    var attributes = content._embedded.attributes;                                                                   // 608
    for (a in attributes) {                                                                                          // 609
      var attribute = {                                                                                              // 610
        name: attributes[a].name,                                                                                    // 611
        category: attributes[a].subcategory.category.name,                                                           // 612
        subcategory: attributes[a].subcategory.name                                                                  // 613
      };                                                                                                             // 610
      //providerLink:   attributes[a]._links.provider.href                                                           //
      self.added('attributes', Random.id(), attribute);                                                              // 616
    }                                                                                                                // 617
  } catch (error) {                                                                                                  // 618
    console.log('Error in getAttributes');                                                                           // 619
    console.log(error);                                                                                              // 620
  }                                                                                                                  // 621
  console.log('---------------------------------------------------');                                                // 622
  self.ready();                                                                                                      // 623
});                                                                                                                  // 624
                                                                                                                     //
Meteor.publish('getAttributesBySphere', function (sphereAttributesUrl) {                                             // 626
  console.log('getAttributesBySphere');                                                                              // 627
  var self = this;                                                                                                   // 628
  if (sphereAttributesUrl != null) {                                                                                 // 629
    try {                                                                                                            // 630
      var response = HTTP.get(sphereAttributesUrl, http_options);                                                    // 631
      var content = JSON.parse(response.content);                                                                    // 632
      var attributes = content._embedded.attributes;                                                                 // 633
      for (a in attributes) {                                                                                        // 634
        var attribute = {                                                                                            // 635
          name: attributes[a].name,                                                                                  // 636
          attributesLink: attributes[a]._links.self.href                                                             // 637
        };                                                                                                           // 635
        self.added('attributesBySphere', Random.id(), attribute);                                                    // 639
      }                                                                                                              // 640
    } catch (error) {                                                                                                // 641
      console.log('Error in getAttributesBySphere');                                                                 // 642
      console.log(error);                                                                                            // 643
    }                                                                                                                // 644
  }                                                                                                                  // 645
  console.log('---------------------------------------------------');                                                // 646
  self.ready();                                                                                                      // 647
});                                                                                                                  // 648
                                                                                                                     //
Meteor.publish('getSpheresByUser', function (spheresUrl) {                                                           // 650
  var self = this;                                                                                                   // 651
  console.log('getSpheresByUser');                                                                                   // 652
  console.log(spheresUrl);                                                                                           // 653
  try {                                                                                                              // 654
    var response = HTTP.get(spheresUrl, http_options);                                                               // 655
    var content = JSON.parse(response.content);                                                                      // 656
    var spheresList = content._embedded.spheres;                                                                     // 657
    for (s in spheresList) {                                                                                         // 658
      var sphere = {                                                                                                 // 659
        name: spheresList[s].name,                                                                                   // 660
        description: spheresList[s].description,                                                                     // 661
        type: spheresList[s].type,                                                                                   // 662
        link: spheresList[s]._links.self.href,                                                                       // 663
        enabled: spheresList[s].enabled,                                                                             // 664
        dataextracted: spheresList[s].dataextracted                                                                  // 665
      };                                                                                                             // 659
      self.added('spheresByUser', Random.id(), sphere);                                                              // 667
    }                                                                                                                // 668
  } catch (error) {                                                                                                  // 669
    console.log('Error in getSpheresByUser');                                                                        // 670
    console.log(error);                                                                                              // 671
  }                                                                                                                  // 672
  console.log('---------------------------------------------------');                                                // 673
  self.ready();                                                                                                      // 674
});                                                                                                                  // 675
                                                                                                                     //
Meteor.publish('getAttributesByProviders', function (providerNames) {                                                // 677
  var self = this;                                                                                                   // 678
  console.log('getAttributesByProviders');                                                                           // 679
  if (providerNames.length > 0) {                                                                                    // 680
    try {                                                                                                            // 681
      var url = host + slash + attrs + slash + search + slash + findAttributesByProviderNamesList + providerNames.toString();
      var response = HTTP.get(url, http_options);                                                                    // 683
      var content = JSON.parse(response.content);                                                                    // 684
      var attributes = content._embedded.attributes;                                                                 // 685
      for (a in attributes) {                                                                                        // 686
        var attribute = {                                                                                            // 687
          name: attributes[a].name,                                                                                  // 688
          category: attributes[a].categoryName,                                                                      // 689
          subcategory: attributes[a].subcategoryName,                                                                // 690
          enabled: attributes[a].enabled,                                                                            // 691
          link: attributes[a]._links.self.href                                                                       // 692
        };                                                                                                           // 687
        self.added('attributesByProviders', Random.id(), attribute);                                                 // 694
      }                                                                                                              // 695
    } catch (error) {                                                                                                // 698
      console.log('error in getAttributesByProviders');                                                              // 699
      console.log(error);                                                                                            // 700
    }                                                                                                                // 701
  }                                                                                                                  // 702
  console.log('---------------------------------------------------');                                                // 703
  self.ready();                                                                                                      // 704
});                                                                                                                  // 705
                                                                                                                     //
Meteor.publish('getConsumersByUser', function (consumersUrl) {                                                       // 707
  console.log('getConsumersByUser');                                                                                 // 708
  console.log(consumersUrl);                                                                                         // 709
  var self = this;                                                                                                   // 710
  if (consumersUrl != null) {                                                                                        // 711
    try {                                                                                                            // 712
      var response = HTTP.get(consumersUrl, http_options);                                                           // 713
      var content = JSON.parse(response.content);                                                                    // 714
      var consumers = content._embedded.consumers;                                                                   // 715
                                                                                                                     //
      _.each(consumers, function (consumer) {                                                                        // 717
        var consumerObject = {                                                                                       // 718
          name: consumer.name,                                                                                       // 719
          link: consumer._links.self.href,                                                                           // 720
          description: consumer.description                                                                          // 721
        };                                                                                                           // 718
        self.added('consumersByUser', Random.id(), consumerObject);                                                  // 723
      });                                                                                                            // 724
    } catch (error) {                                                                                                // 726
      console.log('Error in getConsumersByUser');                                                                    // 727
      console.log(error);                                                                                            // 728
    }                                                                                                                // 729
  }                                                                                                                  // 730
  console.log('---------------------------------------------------');                                                // 731
  self.ready();                                                                                                      // 732
});                                                                                                                  // 733
                                                                                                                     //
Meteor.publish('getRegisteredEmailsandRegisteredIds', function () {                                                  // 735
  console.log('getRegisteredEmailsandRegisteredIds');                                                                // 736
  var self = this;                                                                                                   // 737
  try {                                                                                                              // 738
    var url = host + slash + people;                                                                                 // 739
    var response = HTTP.get(url, http_options);                                                                      // 740
    var content = JSON.parse(response.content);                                                                      // 741
    var users = content._embedded.people;                                                                            // 742
                                                                                                                     //
    _.each(users, function (user) {                                                                                  // 744
      var email = { email: user.email };                                                                             // 745
      self.added('registeredEmails', Random.id(), email);                                                            // 746
      var personal_id = { personal_id: user.personal_id };                                                           // 747
      self.added('registeredIds', Random.id(), personal_id);                                                         // 748
    });                                                                                                              // 749
  } catch (error) {                                                                                                  // 750
    console.log('Error in getRegisteredEmailsandRegisteredIds');                                                     // 751
    console.log(error);                                                                                              // 752
  }                                                                                                                  // 753
  self.ready();                                                                                                      // 754
});                                                                                                                  // 756
                                                                                                                     //
Meteor.publish('getEntities', function () {                                                                          // 758
  console.log('getEntities');                                                                                        // 759
  var self = this;                                                                                                   // 760
  try {                                                                                                              // 761
    var url = host + slash + entities;                                                                               // 762
    var response = HTTP.get(url, http_options);                                                                      // 763
    var content = JSON.parse(response.content);                                                                      // 764
    var entitiesAPI = content._embedded.entities;                                                                    // 765
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 767
      var entityObject = {                                                                                           // 768
        name: entity.name,                                                                                           // 769
        description: entity.description,                                                                             // 770
        email: entity.email,                                                                                         // 771
        link: entity._links.self.href,                                                                               // 772
        identifier: entity.identifier                                                                                // 773
      };                                                                                                             // 768
      self.added('entities', Random.id(), entityObject);                                                             // 775
    });                                                                                                              // 776
  } catch (error) {                                                                                                  // 778
    console.log('Error in getEntities');                                                                             // 779
    console.log(error);                                                                                              // 780
  }                                                                                                                  // 781
  self.ready();                                                                                                      // 782
});                                                                                                                  // 783
                                                                                                                     //
// FOR USERS SCREENS                                                                                                 //
Meteor.publish('getEntitiesRequestedFromEntities', function (userEmail) {                                            // 787
  console.log('getEntitiesRequestedFromEntities');                                                                   // 788
  var self = this;                                                                                                   // 789
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
  try {                                                                                                              // 792
    var response = HTTP.get(url, http_options);                                                                      // 793
    var content = JSON.parse(response.content);                                                                      // 794
    var entitiesAPI = content._embedded.entities;                                                                    // 795
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 797
      var entityObject = {                                                                                           // 798
        name: entity.name,                                                                                           // 799
        description: entity.description,                                                                             // 800
        email: entity.email,                                                                                         // 801
        link: entity._links.self.href                                                                                // 802
      };                                                                                                             // 798
      self.added('entitiesRequestedFromEntities', Random.id(), entityObject);                                        // 804
    });                                                                                                              // 805
  } catch (error) {                                                                                                  // 806
    console.log('Error in getEntitiesRequestedFromEntities');                                                        // 807
    console.log(error);                                                                                              // 808
  }                                                                                                                  // 809
  self.ready();                                                                                                      // 810
});                                                                                                                  // 811
                                                                                                                     //
Meteor.publish('getEntitiesRequestedFromUsers', function (userEmail) {                                               // 813
  console.log('getEntitiesRequestedFromUsers');                                                                      // 814
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                     //
  var self = this;                                                                                                   // 818
  try {                                                                                                              // 819
    var response = HTTP.get(url, http_options);                                                                      // 820
    var content = JSON.parse(response.content);                                                                      // 821
    var entitiesAPI = content._embedded.entities;                                                                    // 822
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 824
      var entityObject = {                                                                                           // 825
        name: entity.name,                                                                                           // 826
        description: entity.description,                                                                             // 827
        email: entity.email,                                                                                         // 828
        link: entity._links.self.href                                                                                // 829
      };                                                                                                             // 825
      self.added('entitiesRequestedFromUsers', Random.id(), entityObject);                                           // 831
    });                                                                                                              // 832
  } catch (error) {                                                                                                  // 833
    console.log('Error in getEntitiesRequestedFromUsers');                                                           // 834
    console.log(error);                                                                                              // 835
  }                                                                                                                  // 836
  self.ready();                                                                                                      // 837
});                                                                                                                  // 838
                                                                                                                     //
Meteor.publish('getAdminEntities', function (userEmail) {                                                            // 840
  console.log('getAdminEntities');                                                                                   // 841
  var self = this;                                                                                                   // 842
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                     //
  try {                                                                                                              // 847
    var response = HTTP.get(url, http_options);                                                                      // 848
    var content = JSON.parse(response.content);                                                                      // 849
    var entitiesAPI = content._embedded.entities;                                                                    // 850
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 852
      var entityObject = {                                                                                           // 853
        name: entity.name,                                                                                           // 854
        description: entity.description,                                                                             // 855
        email: entity.email,                                                                                         // 856
        link: entity._links.self.href                                                                                // 857
      };                                                                                                             // 853
      self.added('adminEntities', Random.id(), entityObject);                                                        // 859
    });                                                                                                              // 860
  } catch (error) {                                                                                                  // 861
    console.log('Error in getAdminEntities');                                                                        // 862
    console.log(error);                                                                                              // 863
  }                                                                                                                  // 864
  self.ready();                                                                                                      // 865
});                                                                                                                  // 866
                                                                                                                     //
Meteor.publish('getEntitiesAssociated', function (userEmail) {                                                       // 868
  console.log('getEntitiesAssociated');                                                                              // 869
  var self = this;                                                                                                   // 870
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                     //
  try {                                                                                                              // 875
    var response = HTTP.get(url, http_options);                                                                      // 876
    var content = JSON.parse(response.content);                                                                      // 877
    var entitiesAPI = content._embedded.entities;                                                                    // 878
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 880
      var entityObject = {                                                                                           // 881
        name: entity.name,                                                                                           // 882
        description: entity.description,                                                                             // 883
        email: entity.email,                                                                                         // 884
        link: entity._links.self.href                                                                                // 885
      };                                                                                                             // 881
      self.added('entitiesAssociated', Random.id(), entityObject);                                                   // 887
    });                                                                                                              // 888
  } catch (error) {                                                                                                  // 889
    console.log('Error in getEntitiesAssociated');                                                                   // 890
    console.log(error);                                                                                              // 891
  }                                                                                                                  // 892
  self.ready();                                                                                                      // 893
});                                                                                                                  // 894
                                                                                                                     //
// Published called from entities screens                                                                            //
Meteor.publish('getUsersRequestedFromEntities', function (entityEmail) {                                             // 900
  console.log('getUsersRequestedFromEntities');                                                                      // 901
  var self = this;                                                                                                   // 902
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
                                                                                                                     //
  try {                                                                                                              // 907
    var response = HTTP.get(url, http_options);                                                                      // 908
    var content = JSON.parse(response.content);                                                                      // 909
    var peopleAPI = content._embedded.people;                                                                        // 910
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 912
      var personObject = {                                                                                           // 913
        name: person.name,                                                                                           // 914
        surname: person.surname,                                                                                     // 915
        email: person.email,                                                                                         // 916
        link: person._links.self.href                                                                                // 917
      };                                                                                                             // 913
      self.added('usersRequestedFromEntities', Random.id(), personObject);                                           // 919
    });                                                                                                              // 920
  } catch (error) {                                                                                                  // 921
    console.log('Error in getUsersRequestedFromEntities');                                                           // 922
    console.log(error);                                                                                              // 923
  }                                                                                                                  // 924
  self.ready();                                                                                                      // 925
});                                                                                                                  // 926
                                                                                                                     //
Meteor.publish('getUsersRequestedFromUsers', function (entityEmail) {                                                // 928
  console.log('getUsersRequestedFromUsers');                                                                         // 929
  var self = this;                                                                                                   // 930
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                     //
  try {                                                                                                              // 935
    var response = HTTP.get(url, http_options);                                                                      // 936
    var content = JSON.parse(response.content);                                                                      // 937
    var peopleAPI = content._embedded.people;                                                                        // 938
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 940
      var personObject = {                                                                                           // 941
        name: person.name,                                                                                           // 942
        surname: person.surname,                                                                                     // 943
        email: person.email,                                                                                         // 944
        link: person._links.self.href                                                                                // 945
      };                                                                                                             // 941
      self.added('usersRequestedFromUsers', Random.id(), personObject);                                              // 947
    });                                                                                                              // 948
  } catch (error) {                                                                                                  // 949
    console.log('Error in getUsersRequestedFromUsers');                                                              // 950
    console.log(error);                                                                                              // 951
  }                                                                                                                  // 952
  self.ready();                                                                                                      // 953
});                                                                                                                  // 954
                                                                                                                     //
Meteor.publish('getAdminUsers', function (entityEmail) {                                                             // 956
  console.log('getAdminUsers');                                                                                      // 957
  var self = this;                                                                                                   // 958
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                     //
  try {                                                                                                              // 963
    var response = HTTP.get(url, http_options);                                                                      // 964
    var content = JSON.parse(response.content);                                                                      // 965
    var peopleAPI = content._embedded.people;                                                                        // 966
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 968
      var personObject = {                                                                                           // 969
        name: person.name,                                                                                           // 970
        surname: person.surname,                                                                                     // 971
        email: person.email,                                                                                         // 972
        link: person._links.self.href                                                                                // 973
      };                                                                                                             // 969
      self.added('adminUsers', Random.id(), personObject);                                                           // 975
    });                                                                                                              // 976
  } catch (error) {                                                                                                  // 977
    console.log('Error in getAdminUsers');                                                                           // 978
    console.log(error);                                                                                              // 979
  }                                                                                                                  // 980
  self.ready();                                                                                                      // 981
});                                                                                                                  // 982
                                                                                                                     //
Meteor.publish('getUsersAssociated', function (entityEmail) {                                                        // 984
  console.log('getUsersAssociated');                                                                                 // 985
  var self = this;                                                                                                   // 986
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                     //
  try {                                                                                                              // 991
    var response = HTTP.get(url, http_options);                                                                      // 992
    var content = JSON.parse(response.content);                                                                      // 993
    var peopleAPI = content._embedded.people;                                                                        // 994
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 996
      var personObject = {                                                                                           // 997
        name: person.name,                                                                                           // 998
        description: person.description,                                                                             // 999
        email: person.email,                                                                                         // 1000
        link: person._links.self.href                                                                                // 1001
      };                                                                                                             // 997
      self.added('usersAssociated', Random.id(), personObject);                                                      // 1003
    });                                                                                                              // 1004
  } catch (error) {                                                                                                  // 1005
    console.log('Error in getUsersAssociated');                                                                      // 1006
    console.log(error);                                                                                              // 1007
  }                                                                                                                  // 1008
  self.ready();                                                                                                      // 1009
});                                                                                                                  // 1010
                                                                                                                     //
Meteor.publish('getEntitiesWithRelationship', function (userEmail) {                                                 // 1012
  console.log('getEntitiesWithRelationship');                                                                        // 1013
  var self = this;                                                                                                   // 1014
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmail + questionMark + 'email=' + userEmail;
  try {                                                                                                              // 1018
    var response = HTTP.get(url, http_options);                                                                      // 1019
    var content = JSON.parse(response.content);                                                                      // 1020
    var entitiesAPI = content._embedded.entities;                                                                    // 1021
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 1023
      var entityObject = {                                                                                           // 1024
        name: entity.name,                                                                                           // 1025
        description: entity.description,                                                                             // 1026
        email: entity.email,                                                                                         // 1027
        link: entity._links.self.href                                                                                // 1028
      };                                                                                                             // 1024
      self.added('entitiesWithRelationship', Random.id(), entityObject);                                             // 1030
    });                                                                                                              // 1031
  } catch (error) {                                                                                                  // 1032
    console.log('Error in getEntitiesWithRelationship');                                                             // 1033
    console.log(error);                                                                                              // 1034
  }                                                                                                                  // 1035
  self.ready();                                                                                                      // 1036
});                                                                                                                  // 1037
                                                                                                                     //
Meteor.publish('getPeople', function () {                                                                            // 1040
  console.log('getPeople');                                                                                          // 1041
  var self = this;                                                                                                   // 1042
  try {                                                                                                              // 1043
    var url = host + slash + people;                                                                                 // 1044
    var response = HTTP.get(url, http_options);                                                                      // 1045
    var content = JSON.parse(response.content);                                                                      // 1046
    var peopleAPI = content._embedded.people;                                                                        // 1047
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1049
      var personObject = {                                                                                           // 1050
        name: person.name,                                                                                           // 1051
        email: person.email,                                                                                         // 1052
        link: person._links.self.href                                                                                // 1053
      };                                                                                                             // 1050
      self.added('people', Random.id(), personObject);                                                               // 1055
    });                                                                                                              // 1056
  } catch (error) {                                                                                                  // 1058
    console.log('Error in getPeople');                                                                               // 1059
    console.log(error);                                                                                              // 1060
  }                                                                                                                  // 1061
  self.ready();                                                                                                      // 1062
});                                                                                                                  // 1063
                                                                                                                     //
Meteor.publish('getPeopleWithRelationship', function (entityEmail) {                                                 // 1065
  console.log('getPeopleWithRelationship');                                                                          // 1066
  var self = this;                                                                                                   // 1067
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                     //
  try {                                                                                                              // 1072
    var response = HTTP.get(url, http_options);                                                                      // 1073
    var content = JSON.parse(response.content);                                                                      // 1074
    var peopleAPI = content._embedded.people;                                                                        // 1075
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1077
      var personObject = {                                                                                           // 1078
        name: person.name,                                                                                           // 1079
        description: person.description,                                                                             // 1080
        email: person.email,                                                                                         // 1081
        link: person._links.self.href                                                                                // 1082
      };                                                                                                             // 1078
      self.added('peopleWithRelationship', Random.id(), personObject);                                               // 1084
    });                                                                                                              // 1085
  } catch (error) {                                                                                                  // 1086
    console.log('Error in getPeopleWithRelationship');                                                               // 1087
    console.log(error);                                                                                              // 1088
  }                                                                                                                  // 1089
  self.ready();                                                                                                      // 1090
});                                                                                                                  // 1091
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"constants.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/constants.js                                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*                                                                                                                   //
* CONSTANTS                                                                                                          //
*/                                                                                                                   //
                                                                                                                     //
/*host = 'http://localhost:8080';*/                                                                                  //
host = 'http://172.20.49.20:9763/LmpApi';                                                                            // 6
slash = '/';                                                                                                         // 7
people = 'people';                                                                                                   // 8
person = 'person';                                                                                                   // 9
consumers = 'consumers';                                                                                             // 10
spheres = 'spheres';                                                                                                 // 11
providers = 'providers';                                                                                             // 12
entities = 'entities';                                                                                               // 13
providerTokens = 'providerTokens';                                                                                   // 14
                                                                                                                     //
emailParameter = "email=";                                                                                           // 16
providerNameParameter = 'providerName=';                                                                             // 17
providerParameter = 'provider=';                                                                                     // 18
userParameter = 'user=';                                                                                             // 19
passwordParameter = 'password=';                                                                                     // 20
                                                                                                                     //
attrs = 'attributes';                                                                                                // 22
search = 'search';                                                                                                   // 23
                                                                                                                     //
findByIdentifier = 'findByIdentifier?identifier=';                                                                   // 25
findByEmail = 'findFirstByEmail?email=';                                                                             // 26
findCategoriesByProviderNamesList = 'findCategoriesByProviderNamesList?providerNames=';                              // 27
findAttributesByProviderNamesList = 'findAttributesByProviderNamesList?names=';                                      // 28
findAttributesByProviderName = 'findAttributesByProviderName?name=';                                                 // 29
findByproviderNameAndUserEmail = 'findByproviderNameAndUserEmail';                                                   // 30
                                                                                                                     //
findEntitiesByPersonEmailAndState = 'findEntitiesByPersonEmailAndState';                                             // 33
findPeopleByEntityEmailAndState = 'findPeopleByEntityEmailAndState';                                                 // 34
findPersonEntityRelationshipByEntityEmailAndPersonEmail = 'findPersonEntityRelationshipByEntityEmailAndPersonEmail';
findPersonEntityRelationshipsByEntityEmail = 'findPersonEntityRelationshipsByEntityEmail';                           // 36
findEntitiesByPersonEmail = 'findEntitiesByPersonEmail';                                                             // 37
findPeopleByEntityEmail = 'findPeopleByEntityEmail';                                                                 // 38
                                                                                                                     //
personEntityRelationships = 'personEntityRelationships';                                                             // 40
                                                                                                                     //
loginWithPassword = 'loginWithPassword';                                                                             // 42
                                                                                                                     //
createNewToken = 'createNewToken';                                                                                   // 44
                                                                                                                     //
questionMark = '?';                                                                                                  // 46
                                                                                                                     //
ampersand = '&';                                                                                                     // 48
                                                                                                                     //
basic_auth = 'web@hotmail.com:EurecatLMP2016!';                                                                      // 50
                                                                                                                     //
REQUESTED_FROM_ENTITY = 'REQUESTED_FROM_ENTITY';                                                                     // 52
REQUESTED_FROM_USER = 'REQUESTED_FROM_USER';                                                                         // 53
ASSOCIATED = 'ASSOCIATED';                                                                                           // 54
ADMINISTRATOR = 'ADMINISTRATOR';                                                                                     // 55
                                                                                                                     //
// Environment variables                                                                                             //
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';                                                                      // 59
                                                                                                                     //
http_options = { auth: basic_auth };                                                                                 // 61
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/routes.js");
require("./server/LMP.js");
require("./server/constants.js");
//# sourceMappingURL=app.js.map
