var require = meteorInstall({"lib":{"collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections.js                                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// Mongo Collections                                                                                                 //
Spheres = new Mongo.Collection('spheres');                                                                           // 2
Providers = new Mongo.Collection('providers');                                                                       // 3
Consumers = new Mongo.Collection('consumers');                                                                       // 4
ConsumersByUser = new Mongo.Collection('consumersByUser');                                                           // 5
ProvidersByUser = new Mongo.Collection('providersByUser');                                                           // 6
Attributes = new Mongo.Collection('attributes');                                                                     // 7
AttributesDefinition = new Mongo.Collection('attributesDefinition');                                                 // 8
                                                                                                                     //
ConsumersInSphere = new Mongo.Collection('consumersInSphere');                                                       // 10
CategoriesByProviders = new Mongo.Collection('categoriesByProviders');                                               // 11
AttributesByProviders = new Mongo.Collection('attributesByProviders');                                               // 12
AttributesBySphere = new Mongo.Collection('attributesBySphere');                                                     // 13
SpheresByUser = new Mongo.Collection('spheresByUser');                                                               // 14
                                                                                                                     //
RegisteredEmails = new Mongo.Collection('registeredEmails');                                                         // 16
RegisteredIds = new Mongo.Collection('registeredIds');                                                               // 17
Entities = new Mongo.Collection('entities');                                                                         // 18
                                                                                                                     //
EntitiesRequestedFromEntities = new Mongo.Collection('entitiesRequestedFromEntities');                               // 21
EntitiesRequestedFromUsers = new Mongo.Collection('entitiesRequestedFromUsers');                                     // 22
AdminEntities = new Mongo.Collection('adminEntities');                                                               // 23
EntitiesAssociated = new Mongo.Collection('entitiesAssociated');                                                     // 24
                                                                                                                     //
EntitiesWithRelationship = new Mongo.Collection('entitiesWithRelationship');                                         // 26
PeopleWithRelationship = new Mongo.Collection('peopleWithRelationship');                                             // 27
                                                                                                                     //
UsersRequestedFromEntities = new Mongo.Collection('usersRequestedFromEntities');                                     // 29
UsersRequestedFromUsers = new Mongo.Collection('usersRequestedFromUsers');                                           // 30
AdminUsers = new Mongo.Collection('adminUsers');                                                                     // 31
UsersAssociated = new Mongo.Collection('usersAssociated');                                                           // 32
                                                                                                                     //
People = new Mongo.Collection('people');                                                                             // 34
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/routes.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
// Router configuration                                                                                              //
Router.configure({                                                                                                   // 3
  loadingTemplate: 'loading-purple',                                                                                 // 4
  defaultBreadcrumbTitle: 'Home',                                                                                    // 5
  defaultBreadcrumbLastLink: true                                                                                    // 6
});                                                                                                                  // 3
                                                                                                                     //
//Routers                                                                                                            //
Router.route('/', {                                                                                                  // 10
  name: 'login',                                                                                                     // 11
  template: 'index'                                                                                                  // 12
});                                                                                                                  // 10
                                                                                                                     //
Router.route('/index', {                                                                                             // 15
  name: 'index',                                                                                                     // 16
  template: 'index'                                                                                                  // 17
});                                                                                                                  // 15
                                                                                                                     //
Router.route('/register', {                                                                                          // 20
  waitOn: function waitOn() {                                                                                        // 21
    return Meteor.subscribe('getRegisteredEmailsandRegisteredIds');                                                  // 22
  }                                                                                                                  // 23
});                                                                                                                  // 20
                                                                                                                     //
Router.route('/home');                                                                                               // 26
                                                                                                                     //
Router.route('/my_spheres', {                                                                                        // 28
  template: 'my_spheres',                                                                                            // 29
  parent: 'home',                                                                                                    // 30
  title: 'My Spheres',                                                                                               // 31
  waitOn: function waitOn() {                                                                                        // 32
    var user = Session.get('user');                                                                                  // 33
    var spheresUrl = user._links.spheres.href;                                                                       // 34
    return Meteor.subscribe('getSpheresByUser', spheresUrl);                                                         // 35
  }                                                                                                                  // 36
});                                                                                                                  // 28
                                                                                                                     //
Router.route('/new_sphere', {                                                                                        // 39
  name: 'new_sphere',                                                                                                // 40
  template: 'new_sphere',                                                                                            // 41
  title: 'new Sphere',                                                                                               // 42
  parent: 'my_spheres',                                                                                              // 43
  waitOn: function waitOn() {                                                                                        // 44
    var user = Session.get('user');                                                                                  // 45
    var providersUrl = user._links.providers.href;                                                                   // 46
    var consumersUrl = user._links.consumers.href;                                                                   // 47
    var attributes = Attributes.find().fetch();                                                                      // 48
    var providers = ProvidersByUser.find().fetch();                                                                  // 49
    var providerLinks = [];                                                                                          // 50
                                                                                                                     //
    var providerNames = [];                                                                                          // 52
                                                                                                                     //
    for (p in providers) {                                                                                           // 54
      var provider = providers[p];                                                                                   // 55
      var providerLink = provider.attributesLink;                                                                    // 56
      providerLinks.push(providerLink);                                                                              // 57
      providerNames.push(provider.name);                                                                             // 58
    }                                                                                                                // 59
                                                                                                                     //
    var sphere = Session.get('sphere');                                                                              // 61
    var sphereAttributesUrl = null;                                                                                  // 62
    var sphereConsumerUrl = null;                                                                                    // 63
    if (sphere != null) {                                                                                            // 64
      sphereAttributesUrl = sphere._links.attributes.href;                                                           // 65
      sphereConsumerUrl = sphere._links.consumers.href;                                                              // 66
    }                                                                                                                // 67
                                                                                                                     //
    var sphereUserUrl = user._links.spheres.href;                                                                    // 69
                                                                                                                     //
    return [Meteor.subscribe('getProvidersByUser', providersUrl), Meteor.subscribe('getAttributesByProviders', providerNames), Meteor.subscribe('getAttributesBySphere', sphereAttributesUrl), Meteor.subscribe('getConsumersByUser', consumersUrl), Meteor.subscribe('getConsumersInSphere', sphereConsumerUrl)];
  }                                                                                                                  // 78
});                                                                                                                  // 39
                                                                                                                     //
Router.route('/my_providers', {                                                                                      // 81
  template: 'my_providers',                                                                                          // 82
  title: 'My Providers',                                                                                             // 83
  parent: 'home'                                                                                                     // 84
});                                                                                                                  // 81
                                                                                                                     //
Router.route('/new_provider', {                                                                                      // 87
  template: 'new_provider',                                                                                          // 88
  title: 'New Provider',                                                                                             // 89
  parent: 'my_providers',                                                                                            // 90
  waitOn: function waitOn() {                                                                                        // 91
    var user = Session.get('user');                                                                                  // 92
    var providersUrl = user._links.providers.href;                                                                   // 93
    return [Meteor.subscribe('getProviders'), Meteor.subscribe('getProvidersByUser', providersUrl)];                 // 94
  }                                                                                                                  // 97
});                                                                                                                  // 87
                                                                                                                     //
Router.route('/my_consumers', {                                                                                      // 100
  template: 'my_consumers',                                                                                          // 101
  parent: 'home',                                                                                                    // 102
  title: 'Consumers'                                                                                                 // 103
});                                                                                                                  // 100
                                                                                                                     //
Router.route('/new_consumer', {                                                                                      // 106
  template: 'new_consumer',                                                                                          // 107
  title: 'New Consumer',                                                                                             // 108
  parent: 'my_consumers',                                                                                            // 109
  waitOn: function waitOn() {                                                                                        // 110
    var user = Session.get('user');                                                                                  // 111
    var consumersUrl = user._links.consumers.href;                                                                   // 112
    return [Meteor.subscribe('getConsumers'), Meteor.subscribe('getConsumersByUser', consumersUrl)];                 // 113
  }                                                                                                                  // 117
});                                                                                                                  // 106
                                                                                                                     //
Router.route('/my_profile', {                                                                                        // 120
  template: 'my_profile',                                                                                            // 121
  title: 'My Profile',                                                                                               // 122
  parent: 'home',                                                                                                    // 123
  data: function data() {                                                                                            // 124
    return Session.get('user');                                                                                      // 125
  }                                                                                                                  // 126
});                                                                                                                  // 120
                                                                                                                     //
Router.route('/my_entities', {                                                                                       // 129
  template: 'my_entities',                                                                                           // 130
  title: 'My Entities',                                                                                              // 131
  parent: 'home'                                                                                                     // 132
});                                                                                                                  // 129
                                                                                                                     //
Router.route('/new_entity', {                                                                                        // 135
  template: 'new_entity',                                                                                            // 136
  title: 'New Entity',                                                                                               // 137
  parent: 'my_entities',                                                                                             // 138
  waitOn: function waitOn() {                                                                                        // 139
    var userEmail = Session.get('user').email;                                                                       // 140
    return [Meteor.subscribe('getEntities'), Meteor.subscribe('getEntitiesWithRelationship', userEmail)];            // 141
  }                                                                                                                  // 145
});                                                                                                                  // 135
                                                                                                                     //
Router.route('/entity_profile', {                                                                                    // 148
  template: 'entity_profile',                                                                                        // 149
  title: 'Entity Profile',                                                                                           // 150
  parent: 'home',                                                                                                    // 151
  data: function data() {                                                                                            // 152
    return Session.get('user');                                                                                      // 153
  }                                                                                                                  // 154
});                                                                                                                  // 148
                                                                                                                     //
Router.route('/people', {                                                                                            // 157
  template: 'people',                                                                                                // 158
  title: 'People',                                                                                                   // 159
  parent: 'home',                                                                                                    // 160
  data: function data() {                                                                                            // 161
    return Session.get('user');                                                                                      // 162
  }                                                                                                                  // 163
});                                                                                                                  // 157
                                                                                                                     //
Router.route('/new_person', {                                                                                        // 166
  template: 'new_person',                                                                                            // 167
  title: 'New User',                                                                                                 // 168
  parent: 'people',                                                                                                  // 169
  waitOn: function waitOn() {                                                                                        // 170
    var entityEmail = Session.get('user').email;                                                                     // 171
    return [Meteor.subscribe('getPeople'), Meteor.subscribe('getPeopleWithRelationship', entityEmail)];              // 172
  }                                                                                                                  // 176
});                                                                                                                  // 166
                                                                                                                     //
var loginRequired = function loginRequired() {                                                                       // 179
  var userSession = Session.get('user');                                                                             // 180
  if (userSession != null && userSession != undefined) {                                                             // 181
    this.next();                                                                                                     // 182
  } else {                                                                                                           // 183
    Router.go('login');                                                                                              // 184
  }                                                                                                                  // 185
};                                                                                                                   // 186
Router.onBeforeAction(loginRequired, { except: ['login', 'register', 'index'] });                                    // 187
                                                                                                                     //
var cleanSphereSessionVariable = function cleanSphereSessionVariable() {};                                           // 189
                                                                                                                     //
Router.onAfterAction(cleanSphereSessionVariable, { except: ['newSphere'] });                                         // 191
                                                                                                                     //
// New routes for Dashboard                                                                                          //
                                                                                                                     //
Router.route('/dashboard', {                                                                                         // 197
  name: 'dashboard',                                                                                                 // 198
  template: 'dashboard'                                                                                              // 199
});                                                                                                                  // 197
                                                                                                                     //
Router.route('/user', {                                                                                              // 202
  name: 'user',                                                                                                      // 203
  template: 'user',                                                                                                  // 204
  data: function data() {                                                                                            // 205
    return Session.get('user');                                                                                      // 206
  }                                                                                                                  // 207
});                                                                                                                  // 202
                                                                                                                     //
Router.route('/providers', {                                                                                         // 210
  name: 'providers',                                                                                                 // 211
  template: 'providers'                                                                                              // 212
});                                                                                                                  // 210
                                                                                                                     //
Router.route('/consumers', {                                                                                         // 215
  name: 'consumers',                                                                                                 // 216
  template: 'consumers'                                                                                              // 217
});                                                                                                                  // 215
                                                                                                                     //
Router.route('/spheres', {                                                                                           // 220
  name: 'spheres',                                                                                                   // 221
  template: 'spheres'                                                                                                // 222
});                                                                                                                  // 220
                                                                                                                     //
Router.route('/entities', {                                                                                          // 225
  name: 'entities',                                                                                                  // 226
  template: 'entities'                                                                                               // 227
});                                                                                                                  // 225
                                                                                                                     //
Router.route('/notifications', {                                                                                     // 230
  name: 'notifications',                                                                                             // 231
  template: 'notifications'                                                                                          // 232
});                                                                                                                  // 230
                                                                                                                     //
Router.route('/template', {                                                                                          // 235
  name: 'template',                                                                                                  // 236
  template: 'template'                                                                                               // 237
});                                                                                                                  // 235
                                                                                                                     //
Router.route('/icons', {                                                                                             // 240
  name: 'icons',                                                                                                     // 241
  template: 'icons'                                                                                                  // 242
});                                                                                                                  // 240
                                                                                                                     //
Router.route('/users_entity', {                                                                                      // 245
  name: 'users_entity',                                                                                              // 246
  template: 'users_entity'                                                                                           // 247
});                                                                                                                  // 245
                                                                                                                     //
Router.route('/entity', {                                                                                            // 250
  name: 'entity',                                                                                                    // 251
  template: 'entity'                                                                                                 // 252
});                                                                                                                  // 250
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"LMP.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/LMP.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
//declare a simple async function                                                                                    //
function delayedMessge(delay, message, callback) {                                                                   // 2
  setTimeout(function () {                                                                                           // 3
    callback(null, message);                                                                                         // 4
  }, delay);                                                                                                         // 5
}                                                                                                                    // 6
                                                                                                                     //
Meteor.methods({                                                                                                     // 10
                                                                                                                     //
  'upsertSphere': function upsertSphere(sphereObject, httpCommand) {                                                 // 12
    if (httpCommand == 'POST') {                                                                                     // 13
      var url = host + slash + spheres;                                                                              // 14
      var response = HTTP.post(url, {                                                                                // 15
        data: {                                                                                                      // 16
          identifier: sphereObject.identifier,                                                                       // 17
          name: sphereObject.name,                                                                                   // 18
          description: sphereObject.description,                                                                     // 19
          type: sphereObject.type,                                                                                   // 20
          enabled: sphereObject.isEnabled,                                                                           // 21
          deleted: sphereObject.isDeleted,                                                                           // 22
          dataextracted: sphereObject.isDataExtracted                                                                // 23
        },                                                                                                           // 16
        auth: basic_auth                                                                                             // 25
      });                                                                                                            // 15
      return response;                                                                                               // 27
    } else {                                                                                                         // 29
      var response = HTTP.put(sphereObject.url, {                                                                    // 30
        data: {                                                                                                      // 31
          identifier: sphereObject.identifier,                                                                       // 32
          name: sphereObject.name,                                                                                   // 33
          description: sphereObject.description,                                                                     // 34
          type: sphereObject.type,                                                                                   // 35
          enabled: sphereObject.isEnabled,                                                                           // 36
          deleted: sphereObject.isDeleted,                                                                           // 37
          dataextracted: sphereObject.isDataExtracted                                                                // 38
        },                                                                                                           // 31
        auth: basic_auth                                                                                             // 40
      });                                                                                                            // 30
      return response;                                                                                               // 42
    }                                                                                                                // 43
  },                                                                                                                 // 44
                                                                                                                     //
  'upsertEntity': function upsertEntity(entityObject, userUrl) {                                                     // 46
    var url = host + slash + entities;                                                                               // 47
    console.log('in upsertEntity');                                                                                  // 48
    console.log(url);                                                                                                // 49
    var response = HTTP.post(url, {                                                                                  // 50
      data: {                                                                                                        // 51
        identifier: entityObject.identifier,                                                                         // 52
        name: entityObject.name,                                                                                     // 53
        description: entityObject.description,                                                                       // 54
        email: entityObject.email                                                                                    // 55
      },                                                                                                             // 51
      auth: basic_auth                                                                                               // 57
    });                                                                                                              // 50
    console.log(response);                                                                                           // 59
    var location = response.headers.location;                                                                        // 60
    console.log(location);                                                                                           // 61
    return location;                                                                                                 // 62
  },                                                                                                                 // 63
                                                                                                                     //
  'updateEntityRequests': function updateEntityRequests(userUrl, entityUrls) {                                       // 65
    console.log('in updateEntityRequests');                                                                          // 66
                                                                                                                     //
    var entityUrlString = _.map(entityUrls, function (url) {                                                         // 68
      return url + '\n';                                                                                             // 69
    }).join('').trim();                                                                                              // 70
                                                                                                                     //
    var response = HTTP.put(userUrl, {                                                                               // 72
      headers: {                                                                                                     // 73
        "Content-Type": "text/uri-list"                                                                              // 74
      },                                                                                                             // 73
      content: entityUrlString,                                                                                      // 76
      auth: basic_auth                                                                                               // 77
    });                                                                                                              // 72
    return response;                                                                                                 // 79
  },                                                                                                                 // 80
                                                                                                                     //
  'updateEntity': function updateEntity(entityObject, entityUrl) {                                                   // 82
    var response = HTTP.patch(entityUrl, {                                                                           // 83
      data: {                                                                                                        // 84
        name: entityObject.name,                                                                                     // 85
        description: entityObject.description,                                                                       // 86
        email: entityObject.email,                                                                                   // 87
        identifier: entityObject.identifier                                                                          // 88
      },                                                                                                             // 84
      auth: basic_auth                                                                                               // 90
    });                                                                                                              // 83
  },                                                                                                                 // 92
                                                                                                                     //
  'joinSphereAndConsumer': function joinSphereAndConsumer(sphereConsumerUrl, consumersUrl) {                         // 94
    var urlConsumersString = '';                                                                                     // 95
    for (url in consumersUrl) {                                                                                      // 96
      urlConsumersString += consumersUrl[url] + '\n';                                                                // 97
    }                                                                                                                // 98
                                                                                                                     //
    return HTTP.put(sphereConsumerUrl, {                                                                             // 100
      headers: {                                                                                                     // 101
        "Content-Type": "text/uri-list"                                                                              // 102
      },                                                                                                             // 101
      content: urlConsumersString,                                                                                   // 104
      auth: basic_auth                                                                                               // 105
    });                                                                                                              // 100
  },                                                                                                                 // 107
                                                                                                                     //
  'joinSphereAndAttributes': function joinSphereAndAttributes(sphereAttributesUrl, attributesUrl) {                  // 109
    var urlAttributesString = '';                                                                                    // 110
    for (url in attributesUrl) {                                                                                     // 111
      urlAttributesString += attributesUrl[url] + '\n';                                                              // 112
    }                                                                                                                // 113
                                                                                                                     //
    return HTTP.put(sphereAttributesUrl, {                                                                           // 115
      headers: {                                                                                                     // 116
        "Content-Type": "text/uri-list"                                                                              // 117
      },                                                                                                             // 116
      content: urlAttributesString,                                                                                  // 119
      auth: basic_auth                                                                                               // 120
    });                                                                                                              // 115
  },                                                                                                                 // 123
                                                                                                                     //
  'upsertProvider': function upsertProvider(providerObject) {                                                        // 125
    var url = host + slash + providers;                                                                              // 126
    var response = HTTP.post(url, {                                                                                  // 127
      data: {                                                                                                        // 128
        identifier: providerObject.identifier,                                                                       // 129
        name: providerObject.name,                                                                                   // 130
        description: providerObject.description,                                                                     // 131
        url: providerObject.url,                                                                                     // 132
        isEnabled: providerObject.isEnabled,                                                                         // 133
        isDeleted: providerObject.isDeleted                                                                          // 134
      },                                                                                                             // 128
      auth: basic_auth                                                                                               // 136
    });                                                                                                              // 127
    return response;                                                                                                 // 138
  },                                                                                                                 // 139
                                                                                                                     //
  'joinPersonAndProvider': function joinPersonAndProvider(urlProviderPerson, urlProviders) {                         // 141
    var urlProvidersString = '';                                                                                     // 142
    for (url in urlProviders) {                                                                                      // 143
      urlProvidersString += urlProviders[url] + '\n';                                                                // 144
    }                                                                                                                // 145
    console.log(urlProviderPerson);                                                                                  // 146
    console.log(urlProvidersString);                                                                                 // 147
    return HTTP.put(urlProviderPerson, {                                                                             // 148
      headers: {                                                                                                     // 149
        "Content-Type": " text/uri-list",                                                                            // 150
        "auth": "web@hotmail.com:EurecatLMP2016!"                                                                    // 151
      },                                                                                                             // 149
      content: urlProvidersString,                                                                                   // 153
      auth: basic_auth                                                                                               // 154
    });                                                                                                              // 148
  },                                                                                                                 // 156
                                                                                                                     //
  'deletePersonAndProviderRelation': function deletePersonAndProviderRelation(providerId, userId) {                  // 158
    console.log('deletePersonAndProviderRelation');                                                                  // 159
    var url = host + slash + "delete/provider/" + providerId + "/user/" + userId;                                    // 160
                                                                                                                     //
    return HTTP.get(url, http_options);                                                                              // 162
  },                                                                                                                 // 163
                                                                                                                     //
  'joinPersonAndConsumer': function joinPersonAndConsumer(urlConsumerPerson, urlConsumers) {                         // 165
    var urlConsumersString = '';                                                                                     // 166
    for (url in urlConsumers) {                                                                                      // 167
      urlConsumersString += urlConsumers[url] + '\n';                                                                // 168
    }                                                                                                                // 169
    console.log('joinPersonAndConsumer');                                                                            // 170
    console.log(urlConsumersString);                                                                                 // 171
    console.log('---------------------------------------------------');                                              // 172
    return HTTP.put(urlConsumerPerson, {                                                                             // 173
      headers: {                                                                                                     // 174
        "Content-Type": "text/uri-list"                                                                              // 175
      },                                                                                                             // 174
      content: urlConsumersString,                                                                                   // 177
      auth: basic_auth                                                                                               // 178
    });                                                                                                              // 173
  },                                                                                                                 // 180
                                                                                                                     //
  'joinPersonAndSphere': function joinPersonAndSphere(urlSpherePerson, urlSpheres) {                                 // 182
    var urlSpheresString = '';                                                                                       // 183
    console.log('joinPersonAndSphere');                                                                              // 184
    for (url in urlSpheres) {                                                                                        // 185
      urlSpheresString += urlSpheres[url] + '\n';                                                                    // 186
    }                                                                                                                // 187
    console.log(urlSpheresString);                                                                                   // 188
    return HTTP.put(urlSpherePerson, {                                                                               // 189
      headers: {                                                                                                     // 190
        "Content-Type": "text/uri-list"                                                                              // 191
      },                                                                                                             // 190
      content: urlSpheresString,                                                                                     // 193
      auth: basic_auth                                                                                               // 194
    });                                                                                                              // 189
  },                                                                                                                 // 196
                                                                                                                     //
  'upsertConsumer': function upsertConsumer(consumerObject) {                                                        // 198
    var url = host + slash + consumers;                                                                              // 199
    var response = HTTP.post(url, {                                                                                  // 200
      data: {                                                                                                        // 201
        identifier: consumerObject.identifier,                                                                       // 202
        name: consumerObject.name,                                                                                   // 203
        description: consumerObject.description,                                                                     // 204
        isEnabled: consumerObject.isEnabled,                                                                         // 205
        isDeleted: consumerObject.isDeleted                                                                          // 206
      },                                                                                                             // 201
      auth: basic_auth                                                                                               // 208
    });                                                                                                              // 200
    return response;                                                                                                 // 210
  },                                                                                                                 // 211
                                                                                                                     //
  'updateSphereEnabled': function updateSphereEnabled(enabled, sphereUrl) {                                          // 213
    var response = HTTP.patch(sphereUrl, {                                                                           // 214
      data: {                                                                                                        // 215
        enabled: enabled                                                                                             // 216
      },                                                                                                             // 215
      http_options: http_options                                                                                     // 218
    });                                                                                                              // 214
    return response;                                                                                                 // 220
  },                                                                                                                 // 221
                                                                                                                     //
  'updateProviderEnabled': function updateProviderEnabled(enabled, providerUrl) {                                    // 223
    var response = HTTP.patch(providerUrl, {                                                                         // 224
      data: {                                                                                                        // 225
        enabled: enabled                                                                                             // 226
      },                                                                                                             // 225
      auth: basic_auth                                                                                               // 228
    });                                                                                                              // 224
    return response;                                                                                                 // 230
  },                                                                                                                 // 231
                                                                                                                     //
  'registerUser': function registerUser(personObject) {                                                              // 233
    var _id = Meteor.userId();                                                                                       // 234
    var url = host + slash + people + slash;                                                                         // 235
    var response = HTTP.post(url, {                                                                                  // 236
      data: {                                                                                                        // 237
        identifier: _id,                                                                                             // 238
        name: personObject.name,                                                                                     // 239
        surname: personObject.surname,                                                                               // 240
        phone: personObject.phone,                                                                                   // 241
        email: personObject.email,                                                                                   // 242
        password: personObject.password,                                                                             // 243
        identifier: personObject.personal_id                                                                         // 244
      },                                                                                                             // 237
      auth: basic_auth                                                                                               // 246
    }, function (error, response) {                                                                                  // 236
      if (error) {                                                                                                   // 248
        console.log('Error in registerUser');                                                                        // 249
        console.log(error);                                                                                          // 250
      } else {                                                                                                       // 251
        console.log('User added correctly!');                                                                        // 252
        console.log(response);                                                                                       // 253
      }                                                                                                              // 254
    });                                                                                                              // 255
  },                                                                                                                 // 256
                                                                                                                     //
  'loginWithPassword': function (_loginWithPassword) {                                                               // 258
    function loginWithPassword(_x) {                                                                                 // 258
      return _loginWithPassword.apply(this, arguments);                                                              // 258
    }                                                                                                                // 258
                                                                                                                     //
    loginWithPassword.toString = function () {                                                                       // 258
      return _loginWithPassword.toString();                                                                          // 258
    };                                                                                                               // 258
                                                                                                                     //
    return loginWithPassword;                                                                                        // 258
  }(function (loginObject) {                                                                                         // 258
    var url = host + slash + loginWithPassword + questionMark + userParameter + loginObject.email + ampersand + passwordParameter + loginObject.password;
    console.log(url);                                                                                                // 261
    try {                                                                                                            // 262
      var response = HTTP.get(url, http_options);                                                                    // 263
      console.log(response);                                                                                         // 264
                                                                                                                     //
      var code = JSON.parse(response.statusCode);                                                                    // 266
      if (code == undefined || code == null) {                                                                       // 267
        throw new Meteor.Error('400', 'User not found', 'Bad request. Please check with your administrator.');       // 268
        return;                                                                                                      // 269
      } else if (code == 401) {                                                                                      // 270
        throw new Meteor.Error('401', 'Unauthorized access', 'Wrogn authentication');                                // 271
        return;                                                                                                      // 272
      }                                                                                                              // 273
                                                                                                                     //
      var getUserUrl = host + slash + people + slash + search + slash + findByEmail + loginObject.email;             // 275
      console.log(getUserUrl);                                                                                       // 277
      var response = HTTP.get(getUserUrl, http_options);                                                             // 278
      var user = JSON.parse(response.content);                                                                       // 279
      if (user == undefined || user == null) {                                                                       // 280
        throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                           // 281
      }                                                                                                              // 282
      return user;                                                                                                   // 283
    } catch (error) {                                                                                                // 284
      console.log('Error while authenticating the user... ' + error);                                                // 285
      throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                             // 286
    }                                                                                                                // 287
  }),                                                                                                                // 288
                                                                                                                     //
  //Old                                                                                                              //
  'getSpheresByPerson': function getSpheresByPerson(spheresUrl) {                                                    // 291
    try {                                                                                                            // 292
      var response = HTTP.get(spheresUrl, http_options);                                                             // 293
      var content = JSON.parse(response.content);                                                                    // 295
      var spheresList = content._embedded.spheres;                                                                   // 296
      return spheresList;                                                                                            // 297
    } catch (error) {                                                                                                // 298
      console.log(error);                                                                                            // 299
    }                                                                                                                // 300
    return [];                                                                                                       // 301
  },                                                                                                                 // 302
                                                                                                                     //
  'getSpheresByUser': function getSpheresByUser(spheresUrl) {                                                        // 304
    try {                                                                                                            // 305
      var response = HTTP.get(spheresUrl, http_options);                                                             // 306
      var content = JSON.parse(response.content);                                                                    // 308
      var spheresList = content._embedded.spheres;                                                                   // 309
      return spheresList;                                                                                            // 310
    } catch (error) {                                                                                                // 311
      console.log(error);                                                                                            // 312
    }                                                                                                                // 313
    return [];                                                                                                       // 314
  },                                                                                                                 // 315
                                                                                                                     //
  'getSphere': function getSphere(sphereUrl) {                                                                       // 317
    try {                                                                                                            // 318
      var response = HTTP.get(sphereUrl, http_options);                                                              // 319
      var content = JSON.parse(response.content);                                                                    // 321
      return content;                                                                                                // 322
    } catch (error) {                                                                                                // 323
      console.log(error);                                                                                            // 324
    }                                                                                                                // 325
    return '';                                                                                                       // 326
  },                                                                                                                 // 327
                                                                                                                     //
  'updateUser': function updateUser(user) {                                                                          // 329
    HTTP.put(user.link, {                                                                                            // 330
      data: {                                                                                                        // 331
        name: user.name,                                                                                             // 332
        surname: user.surname,                                                                                       // 333
        phone: user.phone,                                                                                           // 334
        email: user.email,                                                                                           // 335
        password: user.password,                                                                                     // 336
        personal_id: user.personal_id,                                                                               // 337
                                                                                                                     //
        identifier: user.identifier,                                                                                 // 339
        address: user.address,                                                                                       // 340
        postalCode: user.postalCode,                                                                                 // 341
        city: user.city,                                                                                             // 342
        country: user.country,                                                                                       // 343
        description: user.description                                                                                // 344
      },                                                                                                             // 331
      auth: basic_auth                                                                                               // 346
    });                                                                                                              // 330
  },                                                                                                                 // 348
                                                                                                                     //
  'getConsumersByUser': function getConsumersByUser(consumersUrl) {                                                  // 350
    try {                                                                                                            // 351
      var response = HTTP.get(consumersUrl, http_options);                                                           // 352
      var content = JSON.parse(response.content);                                                                    // 354
      var consumersList = content._embedded.consumers;                                                               // 355
      return consumersList;                                                                                          // 356
    } catch (error) {                                                                                                // 357
      console.log(error);                                                                                            // 358
    }                                                                                                                // 359
    return [];                                                                                                       // 360
  },                                                                                                                 // 361
                                                                                                                     //
  'getProvidersByUser': function getProvidersByUser(providersUrl) {                                                  // 363
    try {                                                                                                            // 364
      var response = HTTP.get(providersUrl, http_options);                                                           // 365
      var content = JSON.parse(response.content);                                                                    // 367
      var providersList = content._embedded.providers;                                                               // 368
      return providersList;                                                                                          // 369
    } catch (error) {                                                                                                // 370
      console.log(error);                                                                                            // 371
    }                                                                                                                // 372
    return [];                                                                                                       // 373
  },                                                                                                                 // 374
                                                                                                                     //
  'joinPersonAndEntities': function joinPersonAndEntities(urlPersonEntities, entitiesUrl) {                          // 376
    var urlEntitiesString = '';                                                                                      // 377
    for (url in entitiesUrl) {                                                                                       // 378
      urlEntitiesString += entitiesUrl[url] + '\n';                                                                  // 379
    }                                                                                                                // 380
    return HTTP.put(urlPersonEntities, {                                                                             // 381
      headers: {                                                                                                     // 382
        "Content-Type": "text/uri-list"                                                                              // 383
      },                                                                                                             // 382
      content: urlEntitiesString,                                                                                    // 385
      auth: basic_auth                                                                                               // 386
    });                                                                                                              // 381
  },                                                                                                                 // 388
                                                                                                                     //
  'getAndDeletePersonOrganizationRelationshipsByEntityEmail': function getAndDeletePersonOrganizationRelationshipsByEntityEmail(entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipsByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                     //
    var response = HTTP.get(url, http_options);                                                                      // 395
    var content = JSON.parse(response.content);                                                                      // 397
    var associations = content._embedded.personEntityRelationships;                                                  // 398
                                                                                                                     //
    _.each(associations, function (association) {                                                                    // 400
      var associationLink = association._links.self.href;                                                            // 401
      HTTP.call('DELETE', associationLink, http_options);                                                            // 402
    });                                                                                                              // 403
    return content;                                                                                                  // 404
  },                                                                                                                 // 405
                                                                                                                     //
  'deleteEntity': function deleteEntity(entityUrl) {                                                                 // 407
    var response = HTTP.call('DELETE', entityUrl, http_options);                                                     // 408
  },                                                                                                                 // 409
                                                                                                                     //
  'getEntity': function getEntity(entityUrl) {                                                                       // 411
    var response = HTTP.get(entityUrl, http_options);                                                                // 412
    var entity = JSON.parse(response.content);                                                                       // 413
    if (entity == undefined || entity == null) {                                                                     // 414
      throw new Meteor.Error('404', 'Entity not found', 'Entity not found in the Database');                         // 415
    }                                                                                                                // 416
    return entity;                                                                                                   // 417
  },                                                                                                                 // 418
                                                                                                                     //
  'getPersonOrganizationRelationshipByEntityEmailAndPersonEmail': function getPersonOrganizationRelationshipByEntityEmailAndPersonEmail(userEmail, entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipByEntityEmailAndPersonEmail + questionMark + 'entityEmail=' + entityEmail + ampersand + 'personEmail=' + userEmail;
    console.log(url);                                                                                                // 424
    var response = HTTP.get(url, http_options);                                                                      // 425
    console.log(response);                                                                                           // 426
    var content = JSON.parse(response.content);                                                                      // 427
    var associationLink = content._links.self.href;                                                                  // 428
    return associationLink;                                                                                          // 429
  },                                                                                                                 // 430
                                                                                                                     //
  'changePersonOrganizationState': function changePersonOrganizationState(associationLink, state) {                  // 432
    HTTP.patch(associationLink, {                                                                                    // 433
      data: {                                                                                                        // 434
        state: state                                                                                                 // 435
      },                                                                                                             // 434
      auth: basic_auth                                                                                               // 437
    });                                                                                                              // 433
  },                                                                                                                 // 439
                                                                                                                     //
  'deletePersonOrganizationRelationship': function deletePersonOrganizationRelationship(associationLink) {           // 441
    console.log('deleting personOrganizationRelationship...');                                                       // 442
    var response = HTTP.call('delete', associationLink, http_options);                                               // 443
  },                                                                                                                 // 444
                                                                                                                     //
  'insertPersonOrganizationRelationship': function insertPersonOrganizationRelationship(userUrl, entityUrl, state) {
    console.log('insertPersonOrganizationRelationship');                                                             // 447
                                                                                                                     //
    var personEntityRelationshipsUrl = host + slash + personEntityRelationships;                                     // 449
                                                                                                                     //
    var response = HTTP.post(personEntityRelationshipsUrl, {                                                         // 451
      data: {                                                                                                        // 452
        state: state,                                                                                                // 453
        organization: entityUrl,                                                                                     // 454
        person: userUrl                                                                                              // 455
      },                                                                                                             // 452
      auth: basic_auth                                                                                               // 457
    });                                                                                                              // 451
    return response;                                                                                                 // 459
  },                                                                                                                 // 460
                                                                                                                     //
  'findTokenByproviderNameAndUserEmail': function findTokenByproviderNameAndUserEmail(providerName, email) {         // 462
    console.log('in findTokenByproviderNameAndUserEmail');                                                           // 463
                                                                                                                     //
    var url = host + slash + providerTokens + slash + search + slash + findByproviderNameAndUserEmail + questionMark + providerNameParameter + providerName + ampersand + emailParameter + email;
                                                                                                                     //
    try {                                                                                                            // 468
      var response = HTTP.get(url, http_options);                                                                    // 469
      var content = JSON.parse(response.content);                                                                    // 470
      var token = content.token;                                                                                     // 471
      return token;                                                                                                  // 472
    } catch (error) {                                                                                                // 473
      return null;                                                                                                   // 474
    }                                                                                                                // 475
  },                                                                                                                 // 476
                                                                                                                     //
  'createNewToken': function (_createNewToken) {                                                                     // 478
    function createNewToken(_x2, _x3) {                                                                              // 478
      return _createNewToken.apply(this, arguments);                                                                 // 478
    }                                                                                                                // 478
                                                                                                                     //
    createNewToken.toString = function () {                                                                          // 478
      return _createNewToken.toString();                                                                             // 478
    };                                                                                                               // 478
                                                                                                                     //
    return createNewToken;                                                                                           // 478
  }(function (providerName, email) {                                                                                 // 478
    var url = host + slash + createNewToken + questionMark + providerParameter + providerName + ampersand + emailParameter + email;
                                                                                                                     //
    try {                                                                                                            // 482
      return url;                                                                                                    // 483
    } catch (error) {                                                                                                // 484
      console.log(error);                                                                                            // 485
      return null;                                                                                                   // 486
    }                                                                                                                // 487
  }),                                                                                                                // 488
                                                                                                                     //
  'getEntitiesWithRelationship': function getEntitiesWithRelationship(userEmail) {                                   // 490
    console.log('in getEntitiesWithRelationship');                                                                   // 491
    var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmail + questionMark + 'email=' + userEmail;
                                                                                                                     //
    try {                                                                                                            // 495
      var response = HTTP.get(url, http_options);                                                                    // 496
      var content = JSON.parse(response.content);                                                                    // 497
      var entitiesList = content._embedded.entities;                                                                 // 498
                                                                                                                     //
      return entitiesList;                                                                                           // 500
    } catch (error) {                                                                                                // 501
      console.log('error in getEntitiesWithRelationship');                                                           // 502
      console.log(error);                                                                                            // 503
      return null;                                                                                                   // 504
    }                                                                                                                // 505
  }                                                                                                                  // 506
});                                                                                                                  // 10
                                                                                                                     //
Meteor.publish('getConsumers', function () {                                                                         // 511
  var self = this;                                                                                                   // 512
  var url = host + slash + consumers;                                                                                // 513
  try {                                                                                                              // 514
    var response = HTTP.get(url, http_options);                                                                      // 515
    var content = JSON.parse(response.content);                                                                      // 516
    var consumersList = content._embedded.consumers;                                                                 // 517
    for (c in consumersList) {                                                                                       // 518
      var consumer = {                                                                                               // 519
        identifier: consumersList[c].identifier,                                                                     // 520
        name: consumersList[c].name,                                                                                 // 521
        description: consumersList[c].description,                                                                   // 522
        link: consumersList[c]._links.consumer.href                                                                  // 523
                                                                                                                     //
      };                                                                                                             // 519
      //TODO: CHANGE ID FROM CONSUMER.IDENTIFIER TO CONSUMER.ID                                                      //
      self.added('consumers', consumer.identifier, consumer);                                                        // 527
    }                                                                                                                // 528
    self.ready();                                                                                                    // 529
  } catch (error) {                                                                                                  // 530
    console.log('Error in getConsumers');                                                                            // 531
    console.log(error);                                                                                              // 532
  }                                                                                                                  // 533
});                                                                                                                  // 534
                                                                                                                     //
/*Meteor.publish('getSpheres', function(){                                                                           //
  var self = this;                                                                                                   //
  var url = host + slash + spheres;                                                                                  //
  try{                                                                                                               //
    var response = HTTP.get(url, http_options);                                                                      //
    var content = JSON.parse(response.content);                                                                      //
    spheresList = content._embedded.spheres;                                                                         //
    for (s in spheresList){                                                                                          //
      var sphere = {                                                                                                 //
        name:           spheresList[c].name,                                                                         //
        description:    spheresList[c].description,                                                                  //
        type:           spheresList[c].type                                                                          //
      }                                                                                                              //
      self.added('spheres', Random.id(), sphere);                                                                    //
    }                                                                                                                //
    self.ready();                                                                                                    //
  } catch (error){                                                                                                   //
    console.log('Error in getSpheres');                                                                              //
    console.log(error);                                                                                              //
  }                                                                                                                  //
});*/                                                                                                                //
                                                                                                                     //
Meteor.publish('getProviders', function () {                                                                         // 558
  console.log('getProviders');                                                                                       // 559
  var self = this;                                                                                                   // 560
  var url = host + slash + providers;                                                                                // 561
  try {                                                                                                              // 562
    var response = HTTP.get(url, http_options);                                                                      // 563
    var content = JSON.parse(response.content);                                                                      // 564
    var providersList = content._embedded.providers;                                                                 // 565
    for (p in providersList) {                                                                                       // 566
                                                                                                                     //
      var provider = {                                                                                               // 568
        id: providersList[p].id,                                                                                     // 569
        name: providersList[p].name,                                                                                 // 570
        description: providersList[p].description,                                                                   // 571
        type: providersList[p].type,                                                                                 // 572
        url: providersList[p].url,                                                                                   // 573
        enabled: providersList[p].enabled,                                                                           // 574
        deleted: providersList[p].deleted,                                                                           // 575
        link: providersList[p]._links.provider.href,                                                                 // 576
        oAuth: providersList[p].oAuth,                                                                               // 577
        oAuthUrl: providersList[p].oAuthUrl                                                                          // 578
      };                                                                                                             // 568
      /*self.added('providers', Random.id(), provider);*/                                                            //
      self.added('providers', provider.id, provider);                                                                // 581
    }                                                                                                                // 582
    self.ready();                                                                                                    // 583
  } catch (error) {                                                                                                  // 584
    console.log('Error in getProviders');                                                                            // 585
    console.log(error);                                                                                              // 586
  }                                                                                                                  // 587
});                                                                                                                  // 588
                                                                                                                     //
Meteor.publish('getProvidersByUser', function (providersUrl) {                                                       // 590
  console.log('getProvidersByUser');                                                                                 // 591
  var self = this;                                                                                                   // 592
                                                                                                                     //
  if (providersUrl != null) {                                                                                        // 594
    try {                                                                                                            // 595
      var response = HTTP.get(providersUrl, http_options);                                                           // 596
      var content = JSON.parse(response.content);                                                                    // 597
      var providersList = content._embedded.providers;                                                               // 598
                                                                                                                     //
      for (p in providersList) {                                                                                     // 600
        var provider = {                                                                                             // 601
          id: providersList[p].id,                                                                                   // 602
          name: providersList[p].name,                                                                               // 603
          description: providersList[p].description,                                                                 // 604
          type: providersList[p].type,                                                                               // 605
          url: providersList[p].url,                                                                                 // 606
          enabled: providersList[p].enabled,                                                                         // 607
          deleted: providersList[p].deleted,                                                                         // 608
          link: providersList[p]._links.provider.href,                                                               // 609
          attributesLink: providersList[p]._links.attributeMaps.href                                                 // 610
        };                                                                                                           // 601
        self.added('providersByUser', provider.id, provider);                                                        // 612
      }                                                                                                              // 613
    } catch (error) {                                                                                                // 614
      console.log('Error in getProvidersByUser');                                                                    // 615
      console.log(error);                                                                                            // 616
    }                                                                                                                // 617
  }                                                                                                                  // 618
  console.log('---------------------------------------------------');                                                // 619
  self.ready();                                                                                                      // 620
});                                                                                                                  // 621
                                                                                                                     //
Meteor.publish('getConsumersInSphere', function (sphereConsumersUrl) {                                               // 623
  var self = this;                                                                                                   // 624
  if (sphereConsumersUrl != null) {                                                                                  // 625
    try {                                                                                                            // 626
      var response = HTTP.get(sphereConsumersUrl, http_options);                                                     // 627
      var content = JSON.parse(response.content);                                                                    // 628
      var consumers = content._embedded.consumers;                                                                   // 629
      for (c in consumers) {                                                                                         // 630
        var consumer = {                                                                                             // 631
          name: consumers[c].name,                                                                                   // 632
          link: consumers[c]._links.self.href,                                                                       // 633
          identifier: consumer[c].identifer                                                                          // 634
        };                                                                                                           // 631
        self.added('consumersInSphere', consumer.identifier, consumer);                                              // 636
      }                                                                                                              // 637
    } catch (error) {                                                                                                // 638
      console.log('Error in getConsumersInSphere');                                                                  // 639
      console.log(error);                                                                                            // 640
    }                                                                                                                // 641
  }                                                                                                                  // 642
  self.ready();                                                                                                      // 643
});                                                                                                                  // 644
                                                                                                                     //
Meteor.publish('getCategoriesByProviders', function (providerNames) {                                                // 646
  console.log('getCategoriesByProviders');                                                                           // 647
  var self = this;                                                                                                   // 648
  var url = host + slash + providers + slash + search + slash + findCategoriesByProviderNamesList + providerNames;   // 649
  try {                                                                                                              // 650
    var response = HTTP.get(url, http_options);                                                                      // 651
    var content = JSON.parse(response.content);                                                                      // 652
    var attributeCategories = content._embedded.attributeCategories;                                                 // 653
    for (a in attributeCategories) {                                                                                 // 654
      var attribute = {                                                                                              // 655
        name: attributeCategories[a].name                                                                            // 656
      };                                                                                                             // 655
      self.added('categoriesByProviders', Random.id(), attribute);                                                   // 658
    }                                                                                                                // 659
  } catch (error) {                                                                                                  // 660
    console.log('Error in getCategoriesByProviders');                                                                // 661
    console.log(error);                                                                                              // 662
  }                                                                                                                  // 663
  console.log('---------------------------------------------------');                                                // 664
  self.ready();                                                                                                      // 665
});                                                                                                                  // 666
                                                                                                                     //
Meteor.publish('getAttributes', function () {                                                                        // 668
  console.log('getAttributes');                                                                                      // 669
  var self = this;                                                                                                   // 670
  var url = host + slash + attrs;                                                                                    // 671
  try {                                                                                                              // 672
    var response = HTTP.get(url, http_options);                                                                      // 673
    var content = JSON.parse(response.content);                                                                      // 674
    var attributes = content._embedded.attributes;                                                                   // 675
    for (a in attributes) {                                                                                          // 676
      var attribute = {                                                                                              // 677
        name: attributes[a].name,                                                                                    // 678
        category: attributes[a].subcategory.category.name,                                                           // 679
        subcategory: attributes[a].subcategory.name                                                                  // 680
      };                                                                                                             // 677
      //providerLink:   attributes[a]._links.provider.href                                                           //
      self.added('attributes', Random.id(), attribute);                                                              // 683
    }                                                                                                                // 684
  } catch (error) {                                                                                                  // 685
    console.log('Error in getAttributes');                                                                           // 686
    console.log(error);                                                                                              // 687
  }                                                                                                                  // 688
  console.log('---------------------------------------------------');                                                // 689
  self.ready();                                                                                                      // 690
});                                                                                                                  // 691
                                                                                                                     //
Meteor.publish('getAttributesBySphere', function (sphereAttributesUrl) {                                             // 693
  console.log('getAttributesBySphere');                                                                              // 694
  var self = this;                                                                                                   // 695
  if (sphereAttributesUrl != null) {                                                                                 // 696
    try {                                                                                                            // 697
      var response = HTTP.get(sphereAttributesUrl, http_options);                                                    // 698
      var content = JSON.parse(response.content);                                                                    // 699
      var attributes = content._embedded.attributes;                                                                 // 700
      for (a in attributes) {                                                                                        // 701
        var attribute = {                                                                                            // 702
          name: attributes[a].name,                                                                                  // 703
          attributesLink: attributes[a]._links.self.href                                                             // 704
        };                                                                                                           // 702
        self.added('attributesBySphere', Random.id(), attribute);                                                    // 706
      }                                                                                                              // 707
    } catch (error) {                                                                                                // 708
      console.log('Error in getAttributesBySphere');                                                                 // 709
      console.log(error);                                                                                            // 710
    }                                                                                                                // 711
  }                                                                                                                  // 712
  console.log('---------------------------------------------------');                                                // 713
  self.ready();                                                                                                      // 714
});                                                                                                                  // 715
                                                                                                                     //
Meteor.publish('getSpheresByUser', function (spheresUrl) {                                                           // 717
  var self = this;                                                                                                   // 718
  console.log('getSpheresByUser');                                                                                   // 719
  console.log(spheresUrl);                                                                                           // 720
  try {                                                                                                              // 721
    var response = HTTP.get(spheresUrl, http_options);                                                               // 722
    var content = JSON.parse(response.content);                                                                      // 723
    var spheresList = content._embedded.spheres;                                                                     // 724
    for (s in spheresList) {                                                                                         // 725
      var sphere = {                                                                                                 // 726
        id: spheresList[s].id,                                                                                       // 727
        name: spheresList[s].name,                                                                                   // 728
        description: spheresList[s].description,                                                                     // 729
        type: spheresList[s].type,                                                                                   // 730
        link: spheresList[s]._links.self.href,                                                                       // 731
        enabled: spheresList[s].enabled,                                                                             // 732
        dataextracted: spheresList[s].dataextracted                                                                  // 733
      };                                                                                                             // 726
      self.added('spheresByUser', sphere.id, sphere);                                                                // 735
    }                                                                                                                // 736
  } catch (error) {                                                                                                  // 737
    console.log('Error in getSpheresByUser');                                                                        // 738
    console.log(error);                                                                                              // 739
  }                                                                                                                  // 740
  console.log('---------------------------------------------------');                                                // 741
  self.ready();                                                                                                      // 742
});                                                                                                                  // 743
                                                                                                                     //
Meteor.publish('getAttributesByProviders', function (providerNames) {                                                // 745
  var self = this;                                                                                                   // 746
  console.log('getAttributesByProviders');                                                                           // 747
  if (providerNames.length > 0) {                                                                                    // 748
    try {                                                                                                            // 749
      var url = host + slash + attrs + slash + search + slash + findAttributesByProviderNamesList + providerNames.toString();
      var response = HTTP.get(url, http_options);                                                                    // 751
      var content = JSON.parse(response.content);                                                                    // 752
      var attributes = content._embedded.attributes;                                                                 // 753
      for (a in attributes) {                                                                                        // 754
        var attribute = {                                                                                            // 755
          name: attributes[a].name,                                                                                  // 756
          category: attributes[a].categoryName,                                                                      // 757
          subcategory: attributes[a].subcategoryName,                                                                // 758
          enabled: attributes[a].enabled,                                                                            // 759
          link: attributes[a]._links.self.href                                                                       // 760
        };                                                                                                           // 755
        self.added('attributesByProviders', Random.id(), attribute);                                                 // 762
      }                                                                                                              // 763
    } catch (error) {                                                                                                // 766
      console.log('error in getAttributesByProviders');                                                              // 767
      console.log(error);                                                                                            // 768
    }                                                                                                                // 769
  }                                                                                                                  // 770
  console.log('---------------------------------------------------');                                                // 771
  self.ready();                                                                                                      // 772
});                                                                                                                  // 773
                                                                                                                     //
Meteor.publish('getConsumersByUser', function (consumersUrl) {                                                       // 775
  console.log('getConsumersByUser');                                                                                 // 776
  console.log(consumersUrl);                                                                                         // 777
  var self = this;                                                                                                   // 778
  if (consumersUrl != null) {                                                                                        // 779
    try {                                                                                                            // 780
      var response = HTTP.get(consumersUrl, http_options);                                                           // 781
      var content = JSON.parse(response.content);                                                                    // 782
      var consumers = content._embedded.consumers;                                                                   // 783
                                                                                                                     //
      _.each(consumers, function (consumer) {                                                                        // 785
        var consumerObject = {                                                                                       // 786
          name: consumer.name,                                                                                       // 787
          link: consumer._links.self.href,                                                                           // 788
          description: consumer.description                                                                          // 789
        };                                                                                                           // 786
        self.added('consumersByUser', Random.id(), consumerObject);                                                  // 791
      });                                                                                                            // 792
    } catch (error) {                                                                                                // 794
      console.log('Error in getConsumersByUser');                                                                    // 795
      console.log(error);                                                                                            // 796
    }                                                                                                                // 797
  }                                                                                                                  // 798
  console.log('---------------------------------------------------');                                                // 799
  self.ready();                                                                                                      // 800
});                                                                                                                  // 801
                                                                                                                     //
Meteor.publish('getRegisteredEmailsandRegisteredIds', function () {                                                  // 803
  console.log('getRegisteredEmailsandRegisteredIds');                                                                // 804
  var self = this;                                                                                                   // 805
  try {                                                                                                              // 806
    var url = host + slash + people;                                                                                 // 807
    var response = HTTP.get(url, http_options);                                                                      // 808
    var content = JSON.parse(response.content);                                                                      // 809
    var users = content._embedded.people;                                                                            // 810
                                                                                                                     //
    _.each(users, function (user) {                                                                                  // 812
      var email = { email: user.email };                                                                             // 813
      self.added('registeredEmails', Random.id(), email);                                                            // 814
      var personal_id = { personal_id: user.personal_id };                                                           // 815
      self.added('registeredIds', Random.id(), personal_id);                                                         // 816
    });                                                                                                              // 817
  } catch (error) {                                                                                                  // 818
    console.log('Error in getRegisteredEmailsandRegisteredIds');                                                     // 819
    console.log(error);                                                                                              // 820
  }                                                                                                                  // 821
  self.ready();                                                                                                      // 822
});                                                                                                                  // 824
                                                                                                                     //
Meteor.publish('getEntities', function () {                                                                          // 826
  console.log('getEntities');                                                                                        // 827
  var self = this;                                                                                                   // 828
  try {                                                                                                              // 829
    var url = host + slash + entities;                                                                               // 830
    var response = HTTP.get(url, http_options);                                                                      // 831
    var content = JSON.parse(response.content);                                                                      // 832
    var entitiesAPI = content._embedded.entities;                                                                    // 833
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 835
      var entityObject = {                                                                                           // 836
        name: entity.name,                                                                                           // 837
        description: entity.description,                                                                             // 838
        email: entity.email,                                                                                         // 839
        link: entity._links.self.href,                                                                               // 840
        identifier: entity.identifier                                                                                // 841
      };                                                                                                             // 836
      self.added('entities', entityObject.identifier, entityObject);                                                 // 843
    });                                                                                                              // 844
  } catch (error) {                                                                                                  // 846
    console.log('Error in getEntities');                                                                             // 847
    console.log(error);                                                                                              // 848
  }                                                                                                                  // 849
  self.ready();                                                                                                      // 850
});                                                                                                                  // 851
                                                                                                                     //
// FOR USERS SCREENS                                                                                                 //
Meteor.publish('getEntitiesRequestedFromEntities', function (userEmail) {                                            // 855
  console.log('getEntitiesRequestedFromEntities');                                                                   // 856
  var self = this;                                                                                                   // 857
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
  try {                                                                                                              // 860
    var response = HTTP.get(url, http_options);                                                                      // 861
    var content = JSON.parse(response.content);                                                                      // 862
    var entitiesAPI = content._embedded.entities;                                                                    // 863
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 865
      var entityObject = {                                                                                           // 866
        name: entity.name,                                                                                           // 867
        description: entity.description,                                                                             // 868
        email: entity.email,                                                                                         // 869
        link: entity._links.self.href,                                                                               // 870
        identifier: entity.identifier                                                                                // 871
      };                                                                                                             // 866
      self.added('entitiesRequestedFromEntities', entityObject.identifier, entityObject);                            // 873
    });                                                                                                              // 874
  } catch (error) {                                                                                                  // 875
    console.log('Error in getEntitiesRequestedFromEntities');                                                        // 876
    console.log(error);                                                                                              // 877
  }                                                                                                                  // 878
  self.ready();                                                                                                      // 879
});                                                                                                                  // 880
                                                                                                                     //
Meteor.publish('getEntitiesRequestedFromUsers', function (userEmail) {                                               // 882
  console.log('getEntitiesRequestedFromUsers');                                                                      // 883
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                     //
  var self = this;                                                                                                   // 887
  try {                                                                                                              // 888
    var response = HTTP.get(url, http_options);                                                                      // 889
    var content = JSON.parse(response.content);                                                                      // 890
    var entitiesAPI = content._embedded.entities;                                                                    // 891
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 893
      var entityObject = {                                                                                           // 894
        name: entity.name,                                                                                           // 895
        description: entity.description,                                                                             // 896
        email: entity.email,                                                                                         // 897
        link: entity._links.self.href,                                                                               // 898
        identifier: entity.identifier                                                                                // 899
      };                                                                                                             // 894
      self.added('entitiesRequestedFromUsers', entityObject.identifier, entityObject);                               // 901
    });                                                                                                              // 902
  } catch (error) {                                                                                                  // 903
    console.log('Error in getEntitiesRequestedFromUsers');                                                           // 904
    console.log(error);                                                                                              // 905
  }                                                                                                                  // 906
  self.ready();                                                                                                      // 907
});                                                                                                                  // 908
                                                                                                                     //
Meteor.publish('getAdminEntities', function (userEmail) {                                                            // 910
  console.log('getAdminEntities');                                                                                   // 911
  var self = this;                                                                                                   // 912
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                     //
  try {                                                                                                              // 917
    var response = HTTP.get(url, http_options);                                                                      // 918
    var content = JSON.parse(response.content);                                                                      // 919
    var entitiesAPI = content._embedded.entities;                                                                    // 920
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 922
      var entityObject = {                                                                                           // 923
        name: entity.name,                                                                                           // 924
        description: entity.description,                                                                             // 925
        email: entity.email,                                                                                         // 926
        link: entity._links.self.href,                                                                               // 927
        identifier: entity.identifier                                                                                // 928
      };                                                                                                             // 923
      self.added('adminEntities', entityObject.identifier, entityObject);                                            // 930
    });                                                                                                              // 931
  } catch (error) {                                                                                                  // 932
    console.log('Error in getAdminEntities');                                                                        // 933
    console.log(error);                                                                                              // 934
  }                                                                                                                  // 935
  self.ready();                                                                                                      // 936
});                                                                                                                  // 937
                                                                                                                     //
Meteor.publish('getEntitiesAssociated', function (userEmail) {                                                       // 939
  console.log('getEntitiesAssociated');                                                                              // 940
  var self = this;                                                                                                   // 941
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                     //
  try {                                                                                                              // 946
    var response = HTTP.get(url, http_options);                                                                      // 947
    var content = JSON.parse(response.content);                                                                      // 948
    var entitiesAPI = content._embedded.entities;                                                                    // 949
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 951
      var entityObject = {                                                                                           // 952
        name: entity.name,                                                                                           // 953
        description: entity.description,                                                                             // 954
        email: entity.email,                                                                                         // 955
        link: entity._links.self.href,                                                                               // 956
        identifier: entity.identifier                                                                                // 957
      };                                                                                                             // 952
      self.added('entitiesAssociated', entityObject.identifier, entityObject);                                       // 959
    });                                                                                                              // 960
  } catch (error) {                                                                                                  // 961
    console.log('Error in getEntitiesAssociated');                                                                   // 962
    console.log(error);                                                                                              // 963
  }                                                                                                                  // 964
  self.ready();                                                                                                      // 965
});                                                                                                                  // 966
                                                                                                                     //
// Published called from entities screens                                                                            //
Meteor.publish('getUsersRequestedFromEntities', function (entityEmail) {                                             // 972
  console.log('getUsersRequestedFromEntities');                                                                      // 973
  var self = this;                                                                                                   // 974
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
                                                                                                                     //
  try {                                                                                                              // 979
    var response = HTTP.get(url, http_options);                                                                      // 980
    var content = JSON.parse(response.content);                                                                      // 981
    var peopleAPI = content._embedded.people;                                                                        // 982
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 984
      var personObject = {                                                                                           // 985
        name: person.name,                                                                                           // 986
        surname: person.surname,                                                                                     // 987
        email: person.email,                                                                                         // 988
        link: person._links.self.href,                                                                               // 989
        id: person.id                                                                                                // 990
                                                                                                                     //
      };                                                                                                             // 985
      self.added('usersRequestedFromEntities', personObject.id, personObject);                                       // 993
    });                                                                                                              // 994
  } catch (error) {                                                                                                  // 995
    console.log('Error in getUsersRequestedFromEntities');                                                           // 996
    console.log(error);                                                                                              // 997
  }                                                                                                                  // 998
  self.ready();                                                                                                      // 999
});                                                                                                                  // 1000
                                                                                                                     //
Meteor.publish('getUsersRequestedFromUsers', function (entityEmail) {                                                // 1002
  console.log('getUsersRequestedFromUsers');                                                                         // 1003
  var self = this;                                                                                                   // 1004
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                     //
  try {                                                                                                              // 1009
    var response = HTTP.get(url, http_options);                                                                      // 1010
    var content = JSON.parse(response.content);                                                                      // 1011
    var peopleAPI = content._embedded.people;                                                                        // 1012
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1014
      var personObject = {                                                                                           // 1015
        name: person.name,                                                                                           // 1016
        surname: person.surname,                                                                                     // 1017
        email: person.email,                                                                                         // 1018
        link: person._links.self.href,                                                                               // 1019
        id: person.id                                                                                                // 1020
      };                                                                                                             // 1015
      self.added('usersRequestedFromUsers', personObject.id, personObject);                                          // 1022
    });                                                                                                              // 1023
  } catch (error) {                                                                                                  // 1024
    console.log('Error in getUsersRequestedFromUsers');                                                              // 1025
    console.log(error);                                                                                              // 1026
  }                                                                                                                  // 1027
  self.ready();                                                                                                      // 1028
});                                                                                                                  // 1029
                                                                                                                     //
Meteor.publish('getAdminUsers', function (entityEmail) {                                                             // 1031
  console.log('getAdminUsers');                                                                                      // 1032
  var self = this;                                                                                                   // 1033
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                     //
  try {                                                                                                              // 1038
    var response = HTTP.get(url, http_options);                                                                      // 1039
    var content = JSON.parse(response.content);                                                                      // 1040
    var peopleAPI = content._embedded.people;                                                                        // 1041
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1043
      var personObject = {                                                                                           // 1044
        id: person.id,                                                                                               // 1045
        name: person.name,                                                                                           // 1046
        surname: person.surname,                                                                                     // 1047
        email: person.email,                                                                                         // 1048
        link: person._links.self.href                                                                                // 1049
      };                                                                                                             // 1044
      self.added('adminUsers', personObject.id, personObject);                                                       // 1051
    });                                                                                                              // 1052
  } catch (error) {                                                                                                  // 1053
    console.log('Error in getAdminUsers');                                                                           // 1054
    console.log(error);                                                                                              // 1055
  }                                                                                                                  // 1056
  self.ready();                                                                                                      // 1057
});                                                                                                                  // 1058
                                                                                                                     //
Meteor.publish('getUsersAssociated', function (entityEmail) {                                                        // 1060
  console.log('getUsersAssociated');                                                                                 // 1061
  var self = this;                                                                                                   // 1062
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                     //
  try {                                                                                                              // 1067
    var response = HTTP.get(url, http_options);                                                                      // 1068
    var content = JSON.parse(response.content);                                                                      // 1069
    var peopleAPI = content._embedded.people;                                                                        // 1070
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1072
      var personObject = {                                                                                           // 1073
        name: person.name,                                                                                           // 1074
        description: person.description,                                                                             // 1075
        email: person.email,                                                                                         // 1076
        link: person._links.self.href,                                                                               // 1077
        id: person.id                                                                                                // 1078
      };                                                                                                             // 1073
      self.added('usersAssociated', personObject.id, personObject);                                                  // 1080
    });                                                                                                              // 1081
  } catch (error) {                                                                                                  // 1082
    console.log('Error in getUsersAssociated');                                                                      // 1083
    console.log(error);                                                                                              // 1084
  }                                                                                                                  // 1085
  self.ready();                                                                                                      // 1086
});                                                                                                                  // 1087
                                                                                                                     //
Meteor.publish('getEntitiesWithRelationship', function (userEmail) {                                                 // 1089
  console.log('getEntitiesWithRelationship');                                                                        // 1090
  var self = this;                                                                                                   // 1091
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmail + questionMark + 'email=' + userEmail;
  try {                                                                                                              // 1095
    var response = HTTP.get(url, http_options);                                                                      // 1096
    var content = JSON.parse(response.content);                                                                      // 1097
    var entitiesAPI = content._embedded.entities;                                                                    // 1098
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 1100
      var entityObject = {                                                                                           // 1101
        name: entity.name,                                                                                           // 1102
        description: entity.description,                                                                             // 1103
        email: entity.email,                                                                                         // 1104
        link: entity._links.self.href,                                                                               // 1105
        identifier: entity.identifier                                                                                // 1106
      };                                                                                                             // 1101
      self.added('entitiesWithRelationship', entity.identifier, entityObject);                                       // 1108
    });                                                                                                              // 1109
  } catch (error) {                                                                                                  // 1110
    console.log('Error in getEntitiesWithRelationship');                                                             // 1111
    console.log(error);                                                                                              // 1112
  }                                                                                                                  // 1113
  self.ready();                                                                                                      // 1114
});                                                                                                                  // 1115
                                                                                                                     //
Meteor.publish('getPeople', function () {                                                                            // 1118
  console.log('getPeople');                                                                                          // 1119
  var self = this;                                                                                                   // 1120
  try {                                                                                                              // 1121
    var url = host + slash + people;                                                                                 // 1122
    var response = HTTP.get(url, http_options);                                                                      // 1123
    var content = JSON.parse(response.content);                                                                      // 1124
    var peopleAPI = content._embedded.people;                                                                        // 1125
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1127
      var personObject = {                                                                                           // 1128
        name: person.name,                                                                                           // 1129
        email: person.email,                                                                                         // 1130
        link: person._links.self.href,                                                                               // 1131
        id: person.id                                                                                                // 1132
      };                                                                                                             // 1128
      self.added('people', personObject.id, personObject);                                                           // 1134
    });                                                                                                              // 1135
  } catch (error) {                                                                                                  // 1137
    console.log('Error in getPeople');                                                                               // 1138
    console.log(error);                                                                                              // 1139
  }                                                                                                                  // 1140
  self.ready();                                                                                                      // 1141
});                                                                                                                  // 1142
                                                                                                                     //
Meteor.publish('getPeopleWithRelationship', function (entityEmail) {                                                 // 1144
  console.log('getPeopleWithRelationship');                                                                          // 1145
  var self = this;                                                                                                   // 1146
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                     //
  try {                                                                                                              // 1151
    var response = HTTP.get(url, http_options);                                                                      // 1152
    var content = JSON.parse(response.content);                                                                      // 1153
    var peopleAPI = content._embedded.people;                                                                        // 1154
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1156
      var personObject = {                                                                                           // 1157
        name: person.name,                                                                                           // 1158
        description: person.description,                                                                             // 1159
        email: person.email,                                                                                         // 1160
        link: person._links.self.href,                                                                               // 1161
        id: person.id                                                                                                // 1162
      };                                                                                                             // 1157
      self.added('peopleWithRelationship', personObject.id, personObject);                                           // 1164
    });                                                                                                              // 1165
  } catch (error) {                                                                                                  // 1166
    console.log('Error in getPeopleWithRelationship');                                                               // 1167
    console.log(error);                                                                                              // 1168
  }                                                                                                                  // 1169
  self.ready();                                                                                                      // 1170
});                                                                                                                  // 1171
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"constants.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/constants.js                                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*                                                                                                                   //
* CONSTANTS                                                                                                          //
*/                                                                                                                   //
                                                                                                                     //
/*host = 'http://localhost:8080';*/                                                                                  //
host = 'http://172.20.49.20:9763/LmpApi';                                                                            // 6
slash = '/';                                                                                                         // 7
people = 'people';                                                                                                   // 8
person = 'person';                                                                                                   // 9
consumers = 'consumers';                                                                                             // 10
spheres = 'spheres';                                                                                                 // 11
providers = 'providers';                                                                                             // 12
entities = 'entities';                                                                                               // 13
providerTokens = 'providerTokens';                                                                                   // 14
                                                                                                                     //
emailParameter = "email=";                                                                                           // 16
providerNameParameter = 'providerName=';                                                                             // 17
providerParameter = 'provider=';                                                                                     // 18
userParameter = 'user=';                                                                                             // 19
passwordParameter = 'password=';                                                                                     // 20
                                                                                                                     //
attrs = 'attributes';                                                                                                // 22
search = 'search';                                                                                                   // 23
                                                                                                                     //
findByIdentifier = 'findByIdentifier?identifier=';                                                                   // 25
findByEmail = 'findFirstByEmail?email=';                                                                             // 26
findCategoriesByProviderNamesList = 'findCategoriesByProviderNamesList?providerNames=';                              // 27
findAttributesByProviderNamesList = 'findAttributesByProviderNamesList?names=';                                      // 28
findAttributesByProviderName = 'findAttributesByProviderName?name=';                                                 // 29
findByproviderNameAndUserEmail = 'findByproviderNameAndUserEmail';                                                   // 30
                                                                                                                     //
findEntitiesByPersonEmailAndState = 'findEntitiesByPersonEmailAndState';                                             // 33
findPeopleByEntityEmailAndState = 'findPeopleByEntityEmailAndState';                                                 // 34
findPersonEntityRelationshipByEntityEmailAndPersonEmail = 'findPersonEntityRelationshipByEntityEmailAndPersonEmail';
findPersonEntityRelationshipsByEntityEmail = 'findPersonEntityRelationshipsByEntityEmail';                           // 36
findEntitiesByPersonEmail = 'findEntitiesByPersonEmail';                                                             // 37
findPeopleByEntityEmail = 'findPeopleByEntityEmail';                                                                 // 38
                                                                                                                     //
personEntityRelationships = 'personEntityRelationships';                                                             // 40
                                                                                                                     //
loginWithPassword = 'loginWithPassword';                                                                             // 42
                                                                                                                     //
createNewToken = 'createNewToken';                                                                                   // 44
                                                                                                                     //
questionMark = '?';                                                                                                  // 46
                                                                                                                     //
ampersand = '&';                                                                                                     // 48
                                                                                                                     //
basic_auth = 'web@hotmail.com:EurecatLMP2016!';                                                                      // 50
                                                                                                                     //
REQUESTED_FROM_ENTITY = 'REQUESTED_FROM_ENTITY';                                                                     // 52
REQUESTED_FROM_USER = 'REQUESTED_FROM_USER';                                                                         // 53
ASSOCIATED = 'ASSOCIATED';                                                                                           // 54
ADMINISTRATOR = 'ADMINISTRATOR';                                                                                     // 55
                                                                                                                     //
// Environment variables                                                                                             //
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';                                                                      // 59
                                                                                                                     //
http_options = { auth: basic_auth };                                                                                 // 61
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/routes.js");
require("./server/LMP.js");
require("./server/constants.js");
//# sourceMappingURL=app.js.map
