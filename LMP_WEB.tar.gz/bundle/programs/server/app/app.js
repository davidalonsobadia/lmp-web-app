var require = meteorInstall({"lib":{"collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/collections.js                                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// Mongo Collections                                                                                                 //
Spheres = new Mongo.Collection('spheres');                                                                           // 2
Providers = new Mongo.Collection('providers');                                                                       // 3
Consumers = new Mongo.Collection('consumers');                                                                       // 4
ConsumersByUser = new Mongo.Collection('consumersByUser');                                                           // 5
ProvidersByUser = new Mongo.Collection('providersByUser');                                                           // 6
Attributes = new Mongo.Collection('attributes');                                                                     // 7
AttributesDefinition = new Mongo.Collection('attributesDefinition');                                                 // 8
                                                                                                                     //
ConsumersInSphere = new Mongo.Collection('consumersInSphere');                                                       // 10
CategoriesByProviders = new Mongo.Collection('categoriesByProviders');                                               // 11
AttributesByProviders = new Mongo.Collection('attributesByProviders');                                               // 12
AttributesBySphere = new Mongo.Collection('attributesBySphere');                                                     // 13
SpheresByUser = new Mongo.Collection('spheresByUser');                                                               // 14
                                                                                                                     //
RegisteredEmails = new Mongo.Collection('registeredEmails');                                                         // 16
RegisteredIds = new Mongo.Collection('registeredIds');                                                               // 17
Entities = new Mongo.Collection('entities');                                                                         // 18
                                                                                                                     //
EntitiesRequestedFromEntities = new Mongo.Collection('entitiesRequestedFromEntities');                               // 21
EntitiesRequestedFromUsers = new Mongo.Collection('entitiesRequestedFromUsers');                                     // 22
AdminEntities = new Mongo.Collection('adminEntities');                                                               // 23
EntitiesAssociated = new Mongo.Collection('entitiesAssociated');                                                     // 24
                                                                                                                     //
EntitiesWithRelationship = new Mongo.Collection('entitiesWithRelationship');                                         // 26
PeopleWithRelationship = new Mongo.Collection('peopleWithRelationship');                                             // 27
                                                                                                                     //
UsersRequestedFromEntities = new Mongo.Collection('usersRequestedFromEntities');                                     // 29
UsersRequestedFromUsers = new Mongo.Collection('usersRequestedFromUsers');                                           // 30
AdminUsers = new Mongo.Collection('adminUsers');                                                                     // 31
UsersAssociated = new Mongo.Collection('usersAssociated');                                                           // 32
                                                                                                                     //
People = new Mongo.Collection('people');                                                                             // 34
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/routes.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
// Router configuration                                                                                              //
Router.configure({                                                                                                   // 3
  loadingTemplate: 'loader',                                                                                         // 4
  defaultBreadcrumbTitle: 'Home',                                                                                    // 5
  defaultBreadcrumbLastLink: true                                                                                    // 6
});                                                                                                                  // 3
                                                                                                                     //
Router.route('/newToken', {                                                                                          // 9
  name: 'newToken',                                                                                                  // 10
  where: 'server',                                                                                                   // 11
  action: function action() {                                                                                        // 12
    var query = this.params.query;                                                                                   // 13
    var decodedUrl = decodeURIComponent(query.url);                                                                  // 14
    this.response.writeHead(302, {                                                                                   // 15
      'Location': decodedUrl                                                                                         // 16
    });                                                                                                              // 15
    this.response.end();                                                                                             // 18
  }                                                                                                                  // 19
});                                                                                                                  // 9
                                                                                                                     //
//Routers                                                                                                            //
Router.route('/', {                                                                                                  // 24
  name: 'login',                                                                                                     // 25
  template: 'login'                                                                                                  // 26
});                                                                                                                  // 24
                                                                                                                     //
Router.route('/register', {                                                                                          // 29
  waitOn: function waitOn() {                                                                                        // 30
    return Meteor.subscribe('getRegisteredEmailsandRegisteredIds');                                                  // 31
  }                                                                                                                  // 32
});                                                                                                                  // 29
                                                                                                                     //
Router.route('/home');                                                                                               // 35
                                                                                                                     //
Router.route('/my_spheres', {                                                                                        // 37
  template: 'my_spheres',                                                                                            // 38
  parent: 'home',                                                                                                    // 39
  title: 'My Spheres',                                                                                               // 40
  waitOn: function waitOn() {                                                                                        // 41
    var user = Session.get('user');                                                                                  // 42
    var spheresUrl = user._links.spheres.href;                                                                       // 43
    return Meteor.subscribe('getSpheresByUser', spheresUrl);                                                         // 44
  }                                                                                                                  // 45
});                                                                                                                  // 37
                                                                                                                     //
Router.route('/new_sphere', {                                                                                        // 48
  name: 'new_sphere',                                                                                                // 49
  template: 'new_sphere',                                                                                            // 50
  title: 'new Sphere',                                                                                               // 51
  parent: 'my_spheres',                                                                                              // 52
  waitOn: function waitOn() {                                                                                        // 53
    var user = Session.get('user');                                                                                  // 54
    var providersUrl = user._links.providers.href;                                                                   // 55
    var consumersUrl = user._links.consumers.href;                                                                   // 56
    var attributes = Attributes.find().fetch();                                                                      // 57
    var providers = ProvidersByUser.find().fetch();                                                                  // 58
    var providerLinks = [];                                                                                          // 59
                                                                                                                     //
    var providerNames = [];                                                                                          // 61
                                                                                                                     //
    for (p in providers) {                                                                                           // 63
      var provider = providers[p];                                                                                   // 64
      var providerLink = provider.attributesLink;                                                                    // 65
      providerLinks.push(providerLink);                                                                              // 66
      providerNames.push(provider.name);                                                                             // 67
    }                                                                                                                // 68
                                                                                                                     //
    var sphere = Session.get('sphere');                                                                              // 70
    var sphereAttributesUrl = null;                                                                                  // 71
    var sphereConsumerUrl = null;                                                                                    // 72
    if (sphere != null) {                                                                                            // 73
      sphereAttributesUrl = sphere._links.attributes.href;                                                           // 74
      sphereConsumerUrl = sphere._links.consumers.href;                                                              // 75
    }                                                                                                                // 76
                                                                                                                     //
    var sphereUserUrl = user._links.spheres.href;                                                                    // 78
                                                                                                                     //
    return [/*Meteor.subscribe('getAttributes')                                                                      // 80
            ,*/Meteor.subscribe('getProvidersByUser', providersUrl), Meteor.subscribe('getAttributesByProviders', providerNames), Meteor.subscribe('getAttributesBySphere', sphereAttributesUrl), Meteor.subscribe('getConsumersByUser', consumersUrl), Meteor.subscribe('getConsumersInSphere', sphereConsumerUrl)];
  }                                                                                                                  // 87
});                                                                                                                  // 48
                                                                                                                     //
Router.route('/my_providers', {                                                                                      // 90
  template: 'my_providers',                                                                                          // 91
  title: 'My Providers',                                                                                             // 92
  parent: 'home'                                                                                                     // 93
});                                                                                                                  // 90
                                                                                                                     //
Router.route('/new_provider', {                                                                                      // 96
  template: 'new_provider',                                                                                          // 97
  title: 'New Provider',                                                                                             // 98
  parent: 'my_providers',                                                                                            // 99
  waitOn: function waitOn() {                                                                                        // 100
    var user = Session.get('user');                                                                                  // 101
    var providersUrl = user._links.providers.href;                                                                   // 102
    return [Meteor.subscribe('getProviders'), Meteor.subscribe('getProvidersByUser', providersUrl)];                 // 103
  }                                                                                                                  // 106
});                                                                                                                  // 96
                                                                                                                     //
Router.route('/my_consumers', {                                                                                      // 109
  template: 'my_consumers',                                                                                          // 110
  parent: 'home',                                                                                                    // 111
  title: 'Consumers'                                                                                                 // 112
});                                                                                                                  // 109
                                                                                                                     //
Router.route('/new_consumer', {                                                                                      // 115
  template: 'new_consumer',                                                                                          // 116
  title: 'New Consumer',                                                                                             // 117
  parent: 'my_consumers',                                                                                            // 118
  waitOn: function waitOn() {                                                                                        // 119
    var user = Session.get('user');                                                                                  // 120
    var consumersUrl = user._links.consumers.href;                                                                   // 121
    return [Meteor.subscribe('getConsumers'), Meteor.subscribe('getConsumersByUser', consumersUrl)];                 // 122
  }                                                                                                                  // 126
});                                                                                                                  // 115
                                                                                                                     //
Router.route('/my_profile', {                                                                                        // 129
  template: 'my_profile',                                                                                            // 130
  title: 'My Profile',                                                                                               // 131
  parent: 'home',                                                                                                    // 132
  data: function data() {                                                                                            // 133
    return Session.get('user');                                                                                      // 134
  }                                                                                                                  // 135
});                                                                                                                  // 129
                                                                                                                     //
Router.route('/my_entities', {                                                                                       // 138
  template: 'my_entities',                                                                                           // 139
  title: 'My Entities',                                                                                              // 140
  parent: 'home'                                                                                                     // 141
});                                                                                                                  // 138
                                                                                                                     //
Router.route('/new_entity', {                                                                                        // 144
  template: 'new_entity',                                                                                            // 145
  title: 'New Entity',                                                                                               // 146
  parent: 'my_entities',                                                                                             // 147
  waitOn: function waitOn() {                                                                                        // 148
    var userEmail = Session.get('user').email;                                                                       // 149
    return [Meteor.subscribe('getEntities'), Meteor.subscribe('getEntitiesWithRelationship', userEmail)];            // 150
  }                                                                                                                  // 154
});                                                                                                                  // 144
                                                                                                                     //
Router.route('/entity_profile', {                                                                                    // 157
  template: 'entity_profile',                                                                                        // 158
  title: 'Entity Profile',                                                                                           // 159
  parent: 'home',                                                                                                    // 160
  data: function data() {                                                                                            // 161
    return Session.get('user');                                                                                      // 162
  }                                                                                                                  // 163
});                                                                                                                  // 157
                                                                                                                     //
Router.route('/people', {                                                                                            // 166
  template: 'people',                                                                                                // 167
  title: 'People',                                                                                                   // 168
  parent: 'home',                                                                                                    // 169
  data: function data() {                                                                                            // 170
    return Session.get('user');                                                                                      // 171
  }                                                                                                                  // 172
});                                                                                                                  // 166
                                                                                                                     //
Router.route('/new_person', {                                                                                        // 175
  template: 'new_person',                                                                                            // 176
  title: 'New User',                                                                                                 // 177
  parent: 'people',                                                                                                  // 178
  waitOn: function waitOn() {                                                                                        // 179
    var entityEmail = Session.get('user').email;                                                                     // 180
    return [Meteor.subscribe('getPeople'), Meteor.subscribe('getPeopleWithRelationship', entityEmail)];              // 181
  }                                                                                                                  // 185
});                                                                                                                  // 175
                                                                                                                     //
var loginRequired = function loginRequired() {                                                                       // 188
  var userSession = Session.get('user');                                                                             // 189
  if (userSession != null && userSession != undefined) {                                                             // 190
    this.next();                                                                                                     // 191
  } else {                                                                                                           // 192
    Router.go('login');                                                                                              // 193
  }                                                                                                                  // 194
};                                                                                                                   // 195
Router.onBeforeAction(loginRequired, { except: ['login', 'register', 'newToken', 'cancelOauth'] });                  // 196
                                                                                                                     //
var cleanSphereSessionVariable = function cleanSphereSessionVariable() {};                                           // 198
                                                                                                                     //
Router.onAfterAction(cleanSphereSessionVariable, { except: ['newSphere'] });                                         // 200
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"LMP.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/LMP.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
//declare a simple async function                                                                                    //
function delayedMessge(delay, message, callback) {                                                                   // 2
  setTimeout(function () {                                                                                           // 3
    callback(null, message);                                                                                         // 4
  }, delay);                                                                                                         // 5
}                                                                                                                    // 6
                                                                                                                     //
Meteor.methods({                                                                                                     // 10
                                                                                                                     //
  'upsertSphere': function upsertSphere(sphereObject, httpCommand) {                                                 // 12
    if (httpCommand == 'POST') {                                                                                     // 13
      var url = host + slash + spheres;                                                                              // 14
      var response = HTTP.post(url, {                                                                                // 15
        data: {                                                                                                      // 16
          identifier: sphereObject.identifier,                                                                       // 17
          name: sphereObject.name,                                                                                   // 18
          description: sphereObject.description,                                                                     // 19
          type: sphereObject.type,                                                                                   // 20
          enabled: sphereObject.isEnabled,                                                                           // 21
          deleted: sphereObject.isDeleted,                                                                           // 22
          dataextracted: sphereObject.isDataExtracted                                                                // 23
        },                                                                                                           // 16
        auth: basic_auth                                                                                             // 25
      });                                                                                                            // 15
      return response;                                                                                               // 27
    } else {                                                                                                         // 29
      var response = HTTP.put(sphereObject.url, {                                                                    // 30
        data: {                                                                                                      // 31
          identifier: sphereObject.identifier,                                                                       // 32
          name: sphereObject.name,                                                                                   // 33
          description: sphereObject.description,                                                                     // 34
          type: sphereObject.type,                                                                                   // 35
          enabled: sphereObject.isEnabled,                                                                           // 36
          deleted: sphereObject.isDeleted,                                                                           // 37
          dataextracted: sphereObject.isDataExtracted                                                                // 38
        },                                                                                                           // 31
        auth: basic_auth                                                                                             // 40
      });                                                                                                            // 30
      return response;                                                                                               // 42
    }                                                                                                                // 43
  },                                                                                                                 // 44
                                                                                                                     //
  'upsertEntity': function upsertEntity(entityObject, userUrl) {                                                     // 46
    var url = host + slash + entities;                                                                               // 47
                                                                                                                     //
    var response = HTTP.post(url, {                                                                                  // 49
      data: {                                                                                                        // 50
        identifier: entityObject.identifier,                                                                         // 51
        name: entityObject.name,                                                                                     // 52
        description: entityObject.description,                                                                       // 53
        email: entityObject.email                                                                                    // 54
      },                                                                                                             // 50
      auth: basic_auth                                                                                               // 56
    });                                                                                                              // 49
    var location = response.headers.location;                                                                        // 58
    return location;                                                                                                 // 59
  },                                                                                                                 // 60
                                                                                                                     //
  'updateEntityRequests': function updateEntityRequests(userUrl, entityUrls) {                                       // 62
    console.log('in updateEntityRequests');                                                                          // 63
                                                                                                                     //
    var entityUrlString = _.map(entityUrls, function (url) {                                                         // 65
      return url + '\n';                                                                                             // 66
    }).join('').trim();                                                                                              // 67
                                                                                                                     //
    var response = HTTP.put(userUrl, {                                                                               // 69
      headers: {                                                                                                     // 70
        "Content-Type": "text/uri-list"                                                                              // 71
      },                                                                                                             // 70
      content: entityUrlString,                                                                                      // 73
      auth: basic_auth                                                                                               // 74
    });                                                                                                              // 69
    return response;                                                                                                 // 76
  },                                                                                                                 // 77
                                                                                                                     //
  'updateEntity': function updateEntity(entityObject, entityUrl) {                                                   // 79
    var response = HTTP.patch(entityUrl, {                                                                           // 80
      data: {                                                                                                        // 81
        name: entityObject.name,                                                                                     // 82
        description: entityObject.description,                                                                       // 83
        email: entityObject.email                                                                                    // 84
      },                                                                                                             // 81
      auth: basic_auth                                                                                               // 86
    });                                                                                                              // 80
  },                                                                                                                 // 88
                                                                                                                     //
  'joinSphereAndConsumer': function joinSphereAndConsumer(sphereConsumerUrl, consumersUrl) {                         // 90
    var urlConsumersString = '';                                                                                     // 91
    for (url in consumersUrl) {                                                                                      // 92
      urlConsumersString += consumersUrl[url] + '\n';                                                                // 93
    }                                                                                                                // 94
                                                                                                                     //
    return HTTP.put(sphereConsumerUrl, {                                                                             // 96
      headers: {                                                                                                     // 97
        "Content-Type": "text/uri-list"                                                                              // 98
      },                                                                                                             // 97
      content: urlConsumersString,                                                                                   // 100
      auth: basic_auth                                                                                               // 101
    });                                                                                                              // 96
  },                                                                                                                 // 103
                                                                                                                     //
  'joinSphereAndAttributes': function joinSphereAndAttributes(sphereAttributesUrl, attributesUrl) {                  // 105
    var urlAttributesString = '';                                                                                    // 106
    for (url in attributesUrl) {                                                                                     // 107
      urlAttributesString += attributesUrl[url] + '\n';                                                              // 108
    }                                                                                                                // 109
                                                                                                                     //
    return HTTP.put(sphereAttributesUrl, {                                                                           // 111
      headers: {                                                                                                     // 112
        "Content-Type": "text/uri-list"                                                                              // 113
      },                                                                                                             // 112
      content: urlAttributesString,                                                                                  // 115
      auth: basic_auth                                                                                               // 116
    });                                                                                                              // 111
  },                                                                                                                 // 119
                                                                                                                     //
  'upsertProvider': function upsertProvider(providerObject) {                                                        // 121
    var url = host + slash + providers;                                                                              // 122
    var response = HTTP.post(url, {                                                                                  // 123
      data: {                                                                                                        // 124
        identifier: providerObject.identifier,                                                                       // 125
        name: providerObject.name,                                                                                   // 126
        description: providerObject.description,                                                                     // 127
        url: providerObject.url,                                                                                     // 128
        isEnabled: providerObject.isEnabled,                                                                         // 129
        isDeleted: providerObject.isDeleted                                                                          // 130
      },                                                                                                             // 124
      auth: basic_auth                                                                                               // 132
    });                                                                                                              // 123
    return response;                                                                                                 // 134
  },                                                                                                                 // 135
                                                                                                                     //
  'joinPersonAndProvider': function joinPersonAndProvider(urlProviderPerson, urlProviders) {                         // 137
    var urlProvidersString = '';                                                                                     // 138
    for (url in urlProviders) {                                                                                      // 139
      urlProvidersString += urlProviders[url] + '\n';                                                                // 140
    }                                                                                                                // 141
    console.log(urlProviderPerson);                                                                                  // 142
    console.log(urlProvidersString);                                                                                 // 143
    return HTTP.put(urlProviderPerson, {                                                                             // 144
      headers: {                                                                                                     // 145
        "Content-Type": " text/uri-list",                                                                            // 146
        "auth": "web@hotmail.com:EurecatLMP2016!"                                                                    // 147
      },                                                                                                             // 145
      content: urlProvidersString,                                                                                   // 149
      auth: basic_auth                                                                                               // 150
    });                                                                                                              // 144
  },                                                                                                                 // 152
                                                                                                                     //
  'deletePersonAndProviderRelation': function deletePersonAndProviderRelation(providerId, userId) {                  // 154
    console.log('deletePersonAndProviderRelation');                                                                  // 155
    var url = host + slash + "delete/provider/" + providerId + "/user/" + userId;                                    // 156
                                                                                                                     //
    return HTTP.get(url, http_options);                                                                              // 158
  },                                                                                                                 // 159
                                                                                                                     //
  'joinPersonAndConsumer': function joinPersonAndConsumer(urlConsumerPerson, urlConsumers) {                         // 161
    var urlConsumersString = '';                                                                                     // 162
    for (url in urlConsumers) {                                                                                      // 163
      urlConsumersString += urlConsumers[url] + '\n';                                                                // 164
    }                                                                                                                // 165
    console.log('joinPersonAndConsumer');                                                                            // 166
    console.log(urlConsumersString);                                                                                 // 167
    console.log('---------------------------------------------------');                                              // 168
    return HTTP.put(urlConsumerPerson, {                                                                             // 169
      headers: {                                                                                                     // 170
        "Content-Type": "text/uri-list"                                                                              // 171
      },                                                                                                             // 170
      content: urlConsumersString,                                                                                   // 173
      auth: basic_auth                                                                                               // 174
    });                                                                                                              // 169
  },                                                                                                                 // 176
                                                                                                                     //
  'joinPersonAndSphere': function joinPersonAndSphere(urlSpherePerson, urlSpheres) {                                 // 178
    var urlSpheresString = '';                                                                                       // 179
    console.log('joinPersonAndSphere');                                                                              // 180
    for (url in urlSpheres) {                                                                                        // 181
      urlSpheresString += urlSpheres[url] + '\n';                                                                    // 182
    }                                                                                                                // 183
    console.log(urlSpheresString);                                                                                   // 184
    return HTTP.put(urlSpherePerson, {                                                                               // 185
      headers: {                                                                                                     // 186
        "Content-Type": "text/uri-list"                                                                              // 187
      },                                                                                                             // 186
      content: urlSpheresString,                                                                                     // 189
      auth: basic_auth                                                                                               // 190
    });                                                                                                              // 185
  },                                                                                                                 // 192
                                                                                                                     //
  'upsertConsumer': function upsertConsumer(consumerObject) {                                                        // 194
    var url = host + slash + consumers;                                                                              // 195
    var response = HTTP.post(url, {                                                                                  // 196
      data: {                                                                                                        // 197
        identifier: consumerObject.identifier,                                                                       // 198
        name: consumerObject.name,                                                                                   // 199
        description: consumerObject.description,                                                                     // 200
        isEnabled: consumerObject.isEnabled,                                                                         // 201
        isDeleted: consumerObject.isDeleted                                                                          // 202
      },                                                                                                             // 197
      auth: basic_auth                                                                                               // 204
    });                                                                                                              // 196
    return response;                                                                                                 // 206
  },                                                                                                                 // 207
                                                                                                                     //
  'updateSphereEnabled': function updateSphereEnabled(enabled, sphereUrl) {                                          // 209
    var response = HTTP.patch(sphereUrl, {                                                                           // 210
      data: {                                                                                                        // 211
        enabled: enabled                                                                                             // 212
      },                                                                                                             // 211
      http_options: http_options                                                                                     // 214
    });                                                                                                              // 210
    return response;                                                                                                 // 216
  },                                                                                                                 // 217
                                                                                                                     //
  'updateProviderEnabled': function updateProviderEnabled(enabled, providerUrl) {                                    // 219
    var response = HTTP.patch(providerUrl, {                                                                         // 220
      data: {                                                                                                        // 221
        enabled: enabled                                                                                             // 222
      },                                                                                                             // 221
      auth: basic_auth                                                                                               // 224
    });                                                                                                              // 220
    return response;                                                                                                 // 226
  },                                                                                                                 // 227
                                                                                                                     //
  'registerUser': function registerUser(personObject) {                                                              // 229
    var _id = Meteor.userId();                                                                                       // 230
    var url = host + slash + people + slash;                                                                         // 231
    var response = HTTP.post(url, {                                                                                  // 232
      data: {                                                                                                        // 233
        identifier: _id,                                                                                             // 234
        name: personObject.name,                                                                                     // 235
        surname: personObject.surname,                                                                               // 236
        phone: personObject.phone,                                                                                   // 237
        email: personObject.email,                                                                                   // 238
        password: personObject.password,                                                                             // 239
        personal_id: personObject.personal_id                                                                        // 240
      },                                                                                                             // 233
      auth: basic_auth                                                                                               // 242
    }, function (error, response) {                                                                                  // 232
      if (error) {                                                                                                   // 244
        console.log('Error in registerUser');                                                                        // 245
        console.log(error);                                                                                          // 246
      } else {                                                                                                       // 247
        console.log('User added correctly!');                                                                        // 248
        console.log(response);                                                                                       // 249
      }                                                                                                              // 250
    });                                                                                                              // 251
  },                                                                                                                 // 252
                                                                                                                     //
  'loginWithPassword': function loginWithPassword(loginObject) {                                                     // 254
    var url = host + slash + people + slash + search + slash + findByEmail + loginObject.email;                      // 255
    try {                                                                                                            // 256
      var response = HTTP.get(url, http_options);                                                                    // 257
      var user = JSON.parse(response.content);                                                                       // 259
      if (user == undefined || user == null) {                                                                       // 260
        throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                           // 261
      }                                                                                                              // 262
      return user;                                                                                                   // 263
    } catch (error) {                                                                                                // 264
      console.log('Error while authenticating the user... ' + error);                                                // 265
      throw new Meteor.Error('404', 'User not found', 'User not found in the Database');                             // 266
    }                                                                                                                // 267
  },                                                                                                                 // 268
                                                                                                                     //
  'getSpheresByPerson': function getSpheresByPerson(spheresUrl) {                                                    // 270
    try {                                                                                                            // 271
      var response = HTTP.get(spheresUrl, http_options);                                                             // 272
      var content = JSON.parse(response.content);                                                                    // 274
      var spheresList = content._embedded.spheres;                                                                   // 275
      return spheresList;                                                                                            // 276
    } catch (error) {                                                                                                // 277
      console.log(error);                                                                                            // 278
    }                                                                                                                // 279
    return [];                                                                                                       // 280
  },                                                                                                                 // 281
                                                                                                                     //
  'getSphere': function getSphere(sphereUrl) {                                                                       // 283
    try {                                                                                                            // 284
      var response = HTTP.get(sphereUrl, http_options);                                                              // 285
      var content = JSON.parse(response.content);                                                                    // 287
      return content;                                                                                                // 288
    } catch (error) {                                                                                                // 289
      console.log(error);                                                                                            // 290
    }                                                                                                                // 291
    return '';                                                                                                       // 292
  },                                                                                                                 // 293
                                                                                                                     //
  'updateUser': function updateUser(user) {                                                                          // 295
    HTTP.put(user.link, {                                                                                            // 296
      data: {                                                                                                        // 297
        name: user.name,                                                                                             // 298
        surname: user.surname,                                                                                       // 299
        phone: user.phone,                                                                                           // 300
        email: user.email,                                                                                           // 301
        password: user.password,                                                                                     // 302
        personal_id: user.personal_id                                                                                // 303
      },                                                                                                             // 297
      auth: basic_auth                                                                                               // 305
    });                                                                                                              // 296
  },                                                                                                                 // 307
                                                                                                                     //
  'getConsumersByUser': function getConsumersByUser(consumersUrl) {                                                  // 309
    try {                                                                                                            // 310
      var response = HTTP.get(consumersUrl, http_options);                                                           // 311
      var content = JSON.parse(response.content);                                                                    // 313
      var consumersList = content._embedded.consumers;                                                               // 314
      return consumersList;                                                                                          // 315
    } catch (error) {                                                                                                // 316
      console.log(error);                                                                                            // 317
    }                                                                                                                // 318
    return [];                                                                                                       // 319
  },                                                                                                                 // 320
                                                                                                                     //
  'joinPersonAndEntities': function joinPersonAndEntities(urlPersonEntities, entitiesUrl) {                          // 322
    var urlEntitiesString = '';                                                                                      // 323
    for (url in entitiesUrl) {                                                                                       // 324
      urlEntitiesString += entitiesUrl[url] + '\n';                                                                  // 325
    }                                                                                                                // 326
    return HTTP.put(urlPersonEntities, {                                                                             // 327
      headers: {                                                                                                     // 328
        "Content-Type": "text/uri-list"                                                                              // 329
      },                                                                                                             // 328
      content: urlEntitiesString,                                                                                    // 331
      auth: basic_auth                                                                                               // 332
    });                                                                                                              // 327
  },                                                                                                                 // 334
                                                                                                                     //
  'getAndDeletePersonOrganizationRelationshipsByEntityEmail': function getAndDeletePersonOrganizationRelationshipsByEntityEmail(entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipsByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                     //
    var response = HTTP.get(url, http_options);                                                                      // 341
    var content = JSON.parse(response.content);                                                                      // 343
    var associations = content._embedded.personEntityRelationships;                                                  // 344
                                                                                                                     //
    _.each(associations, function (association) {                                                                    // 346
      var associationLink = association._links.self.href;                                                            // 347
      HTTP.call('DELETE', associationLink, http_options);                                                            // 348
    });                                                                                                              // 349
    return content;                                                                                                  // 350
  },                                                                                                                 // 351
                                                                                                                     //
  'deleteEntity': function deleteEntity(entityUrl) {                                                                 // 353
    var response = HTTP.call('DELETE', entityUrl, http_options);                                                     // 354
  },                                                                                                                 // 355
                                                                                                                     //
  'getEntity': function getEntity(entityUrl) {                                                                       // 357
    var response = HTTP.get(entityUrl, http_options);                                                                // 358
    var entity = JSON.parse(response.content);                                                                       // 359
    if (entity == undefined || entity == null) {                                                                     // 360
      throw new Meteor.Error('404', 'Entity not found', 'Entity not found in the Database');                         // 361
    }                                                                                                                // 362
    return entity;                                                                                                   // 363
  },                                                                                                                 // 364
                                                                                                                     //
  'getPersonOrganizationRelationshipByEntityEmailAndPersonEmail': function getPersonOrganizationRelationshipByEntityEmailAndPersonEmail(userEmail, entityEmail) {
    var url = host + slash + personEntityRelationships + slash + search + slash + findPersonEntityRelationshipByEntityEmailAndPersonEmail + questionMark + 'entityEmail=' + entityEmail + ampersand + 'personEmail=' + userEmail;
    var response = HTTP.get(url, http_options);                                                                      // 370
    var content = JSON.parse(response.content);                                                                      // 371
    var associationLink = content._links.self.href;                                                                  // 372
    return associationLink;                                                                                          // 373
  },                                                                                                                 // 374
                                                                                                                     //
  'changePersonOrganizationState': function changePersonOrganizationState(associationLink, state) {                  // 376
    HTTP.patch(associationLink, {                                                                                    // 377
      data: {                                                                                                        // 378
        state: state                                                                                                 // 379
      },                                                                                                             // 378
      auth: basic_auth                                                                                               // 381
    });                                                                                                              // 377
  },                                                                                                                 // 383
                                                                                                                     //
  'deletePersonOrganizationRelationship': function deletePersonOrganizationRelationship(associationLink) {           // 385
    console.log('deleting personOrganizationRelationship...');                                                       // 386
    var response = HTTP.call('delete', associationLink, http_options);                                               // 387
  },                                                                                                                 // 388
                                                                                                                     //
  'insertPersonOrganizationRelationship': function insertPersonOrganizationRelationship(userUrl, entityUrl, state) {
    console.log('insertPersonOrganizationRelationship');                                                             // 391
                                                                                                                     //
    var personEntityRelationshipsUrl = host + slash + personEntityRelationships;                                     // 393
                                                                                                                     //
    var response = HTTP.post(personEntityRelationshipsUrl, {                                                         // 395
      data: {                                                                                                        // 396
        state: state,                                                                                                // 397
        organization: entityUrl,                                                                                     // 398
        person: userUrl                                                                                              // 399
      },                                                                                                             // 396
      auth: basic_auth                                                                                               // 401
    });                                                                                                              // 395
    return response;                                                                                                 // 403
  },                                                                                                                 // 404
                                                                                                                     //
  'findTokenByproviderNameAndUserEmail': function findTokenByproviderNameAndUserEmail(providerName, email) {         // 406
    console.log('in findTokenByproviderNameAndUserEmail');                                                           // 407
                                                                                                                     //
    var url = host + slash + providerTokens + slash + search + slash + findByproviderNameAndUserEmail + questionMark + providerNameParameter + providerName + ampersand + emailParameter + email;
                                                                                                                     //
    try {                                                                                                            // 412
      var response = HTTP.get(url, http_options);                                                                    // 413
      var content = JSON.parse(response.content);                                                                    // 414
      var token = content.token;                                                                                     // 415
      return token;                                                                                                  // 416
    } catch (error) {                                                                                                // 417
      return null;                                                                                                   // 418
    }                                                                                                                // 419
  },                                                                                                                 // 420
                                                                                                                     //
  'createNewToken': function (_createNewToken) {                                                                     // 422
    function createNewToken(_x, _x2) {                                                                               // 422
      return _createNewToken.apply(this, arguments);                                                                 // 422
    }                                                                                                                // 422
                                                                                                                     //
    createNewToken.toString = function () {                                                                          // 422
      return _createNewToken.toString();                                                                             // 422
    };                                                                                                               // 422
                                                                                                                     //
    return createNewToken;                                                                                           // 422
  }(function (providerName, email) {                                                                                 // 422
    var url = host + slash + createNewToken + questionMark + providerParameter + providerName + ampersand + emailParameter + email;
                                                                                                                     //
    try {                                                                                                            // 426
      return url;                                                                                                    // 427
    } catch (error) {                                                                                                // 428
      console.log(error);                                                                                            // 429
      return null;                                                                                                   // 430
    }                                                                                                                // 431
  })                                                                                                                 // 432
});                                                                                                                  // 10
                                                                                                                     //
Meteor.publish('getConsumers', function () {                                                                         // 435
  var self = this;                                                                                                   // 436
  var url = host + slash + consumers;                                                                                // 437
  try {                                                                                                              // 438
    var response = HTTP.get(url, http_options);                                                                      // 439
    var content = JSON.parse(response.content);                                                                      // 440
    var consumersList = content._embedded.consumers;                                                                 // 441
    for (c in consumersList) {                                                                                       // 442
      var consumer = {                                                                                               // 443
        name: consumersList[c].name,                                                                                 // 444
        description: consumersList[c].description,                                                                   // 445
        link: consumersList[c]._links.consumer.href                                                                  // 446
      };                                                                                                             // 443
      self.added('consumers', Random.id(), consumer);                                                                // 448
    }                                                                                                                // 449
    self.ready();                                                                                                    // 450
  } catch (error) {                                                                                                  // 451
    console.log('Error in getConsumers');                                                                            // 452
    console.log(error);                                                                                              // 453
  }                                                                                                                  // 454
});                                                                                                                  // 455
                                                                                                                     //
Meteor.publish('getSpheres', function () {                                                                           // 457
  var self = this;                                                                                                   // 458
  var url = host + slash + spheres;                                                                                  // 459
  try {                                                                                                              // 460
    var response = HTTP.get(url, http_options);                                                                      // 461
    var content = JSON.parse(response.content);                                                                      // 462
    spheresList = content._embedded.spheres;                                                                         // 463
    for (s in spheresList) {                                                                                         // 464
      var sphere = {                                                                                                 // 465
        name: spheresList[c].name,                                                                                   // 466
        description: spheresList[c].description,                                                                     // 467
        type: spheresList[c].type                                                                                    // 468
      };                                                                                                             // 465
      self.added('spheres', Random.id(), sphere);                                                                    // 470
    }                                                                                                                // 471
    self.ready();                                                                                                    // 472
  } catch (error) {                                                                                                  // 473
    console.log('Error in getSpheres');                                                                              // 474
    console.log(error);                                                                                              // 475
  }                                                                                                                  // 476
});                                                                                                                  // 477
                                                                                                                     //
Meteor.publish('getProviders', function () {                                                                         // 479
  console.log('getProviders');                                                                                       // 480
  var self = this;                                                                                                   // 481
  var url = host + slash + providers;                                                                                // 482
  try {                                                                                                              // 483
    var response = HTTP.get(url, http_options);                                                                      // 484
    var content = JSON.parse(response.content);                                                                      // 485
    var providersList = content._embedded.providers;                                                                 // 486
    for (p in providersList) {                                                                                       // 487
                                                                                                                     //
      var provider = {                                                                                               // 489
        name: providersList[p].name,                                                                                 // 490
        description: providersList[p].description,                                                                   // 491
        type: providersList[p].type,                                                                                 // 492
        url: providersList[p].url,                                                                                   // 493
        enabled: providersList[p].enabled,                                                                           // 494
        deleted: providersList[p].deleted,                                                                           // 495
        link: providersList[p]._links.provider.href,                                                                 // 496
        oAuth: providersList[p].oAuth,                                                                               // 497
        oAuthUrl: providersList[p].oAuthUrl                                                                          // 498
      };                                                                                                             // 489
      self.added('providers', Random.id(), provider);                                                                // 500
    }                                                                                                                // 501
    self.ready();                                                                                                    // 502
  } catch (error) {                                                                                                  // 503
    console.log('Error in getProviders');                                                                            // 504
    console.log(error);                                                                                              // 505
  }                                                                                                                  // 506
});                                                                                                                  // 507
                                                                                                                     //
Meteor.publish('getProvidersByUser', function (providersUrl) {                                                       // 509
  console.log('getProvidersByUser');                                                                                 // 510
  var self = this;                                                                                                   // 511
  if (providersUrl != null) {                                                                                        // 512
    try {                                                                                                            // 513
      var response = HTTP.get(providersUrl, http_options);                                                           // 514
      var content = JSON.parse(response.content);                                                                    // 515
      var providersList = content._embedded.providers;                                                               // 516
                                                                                                                     //
      for (p in providersList) {                                                                                     // 518
        var provider = {                                                                                             // 519
          id: providersList[p].id,                                                                                   // 520
          name: providersList[p].name,                                                                               // 521
          description: providersList[p].description,                                                                 // 522
          type: providersList[p].type,                                                                               // 523
          url: providersList[p].url,                                                                                 // 524
          enabled: providersList[p].enabled,                                                                         // 525
          deleted: providersList[p].deleted,                                                                         // 526
          link: providersList[p]._links.provider.href,                                                               // 527
          attributesLink: providersList[p]._links.attributeMaps.href                                                 // 528
        };                                                                                                           // 519
        self.added('providersByUser', Random.id(), provider);                                                        // 530
      }                                                                                                              // 531
    } catch (error) {                                                                                                // 532
      console.log('Error in getProvidersByUser');                                                                    // 533
      console.log(error);                                                                                            // 534
    }                                                                                                                // 535
  }                                                                                                                  // 536
  console.log('---------------------------------------------------');                                                // 537
  self.ready();                                                                                                      // 538
});                                                                                                                  // 539
                                                                                                                     //
Meteor.publish('getConsumersInSphere', function (sphereConsumersUrl) {                                               // 541
  var self = this;                                                                                                   // 542
  if (sphereConsumersUrl != null) {                                                                                  // 543
    try {                                                                                                            // 544
      var response = HTTP.get(sphereConsumersUrl, http_options);                                                     // 545
      var content = JSON.parse(response.content);                                                                    // 546
      var consumers = content._embedded.consumers;                                                                   // 547
      for (c in consumers) {                                                                                         // 548
        var consumer = {                                                                                             // 549
          name: consumers[c].name,                                                                                   // 550
          link: consumers[c]._links.self.href                                                                        // 551
        };                                                                                                           // 549
        self.added('consumersInSphere', Random.id(), consumer);                                                      // 553
      }                                                                                                              // 554
    } catch (error) {                                                                                                // 555
      console.log('Error in getConsumersInSphere');                                                                  // 556
      console.log(error);                                                                                            // 557
    }                                                                                                                // 558
  }                                                                                                                  // 559
  self.ready();                                                                                                      // 560
});                                                                                                                  // 561
                                                                                                                     //
Meteor.publish('getCategoriesByProviders', function (providerNames) {                                                // 563
  console.log('getCategoriesByProviders');                                                                           // 564
  var self = this;                                                                                                   // 565
  var url = host + slash + providers + slash + search + slash + findCategoriesByProviderNamesList + providerNames;   // 566
  try {                                                                                                              // 567
    var response = HTTP.get(url, http_options);                                                                      // 568
    var content = JSON.parse(response.content);                                                                      // 569
    var attributeCategories = content._embedded.attributeCategories;                                                 // 570
    for (a in attributeCategories) {                                                                                 // 571
      var attribute = {                                                                                              // 572
        name: attributeCategories[a].name                                                                            // 573
      };                                                                                                             // 572
      self.added('categoriesByProviders', Random.id(), attribute);                                                   // 575
    }                                                                                                                // 576
  } catch (error) {                                                                                                  // 577
    console.log('Error in getCategoriesByProviders');                                                                // 578
    console.log(error);                                                                                              // 579
  }                                                                                                                  // 580
  console.log('---------------------------------------------------');                                                // 581
  self.ready();                                                                                                      // 582
});                                                                                                                  // 583
                                                                                                                     //
Meteor.publish('getAttributes', function () {                                                                        // 585
  console.log('getAttributes');                                                                                      // 586
  var self = this;                                                                                                   // 587
  var url = host + slash + attrs;                                                                                    // 588
  try {                                                                                                              // 589
    var response = HTTP.get(url, http_options);                                                                      // 590
    var content = JSON.parse(response.content);                                                                      // 591
    var attributes = content._embedded.attributes;                                                                   // 592
    for (a in attributes) {                                                                                          // 593
      var attribute = {                                                                                              // 594
        name: attributes[a].name,                                                                                    // 595
        category: attributes[a].subcategory.category.name,                                                           // 596
        subcategory: attributes[a].subcategory.name                                                                  // 597
      };                                                                                                             // 594
      //providerLink:   attributes[a]._links.provider.href                                                           //
      self.added('attributes', Random.id(), attribute);                                                              // 600
    }                                                                                                                // 601
  } catch (error) {                                                                                                  // 602
    console.log('Error in getAttributes');                                                                           // 603
    console.log(error);                                                                                              // 604
  }                                                                                                                  // 605
  console.log('---------------------------------------------------');                                                // 606
  self.ready();                                                                                                      // 607
});                                                                                                                  // 608
                                                                                                                     //
Meteor.publish('getAttributesBySphere', function (sphereAttributesUrl) {                                             // 610
  console.log('getAttributesBySphere');                                                                              // 611
  var self = this;                                                                                                   // 612
  if (sphereAttributesUrl != null) {                                                                                 // 613
    try {                                                                                                            // 614
      var response = HTTP.get(sphereAttributesUrl, http_options);                                                    // 615
      var content = JSON.parse(response.content);                                                                    // 616
      var attributes = content._embedded.attributes;                                                                 // 617
      for (a in attributes) {                                                                                        // 618
        console.log(attributes[a]);                                                                                  // 619
        var attribute = {                                                                                            // 620
          name: attributes[a].name,                                                                                  // 621
          attributesLink: attributes[a]._links.self.href                                                             // 622
        };                                                                                                           // 620
        self.added('attributesBySphere', Random.id(), attribute);                                                    // 624
      }                                                                                                              // 625
    } catch (error) {                                                                                                // 626
      console.log('Error in getAttributesBySphere');                                                                 // 627
      console.log(error);                                                                                            // 628
    }                                                                                                                // 629
  }                                                                                                                  // 630
  console.log('---------------------------------------------------');                                                // 631
  self.ready();                                                                                                      // 632
});                                                                                                                  // 633
                                                                                                                     //
Meteor.publish('getSpheresByUser', function (spheresUrl) {                                                           // 635
  var self = this;                                                                                                   // 636
  console.log('getSpheresByUser');                                                                                   // 637
  console.log(spheresUrl);                                                                                           // 638
  try {                                                                                                              // 639
    var response = HTTP.get(spheresUrl, http_options);                                                               // 640
    var content = JSON.parse(response.content);                                                                      // 641
    var spheresList = content._embedded.spheres;                                                                     // 642
    for (s in spheresList) {                                                                                         // 643
      var sphere = {                                                                                                 // 644
        name: spheresList[s].name,                                                                                   // 645
        description: spheresList[s].description,                                                                     // 646
        type: spheresList[s].type,                                                                                   // 647
        link: spheresList[s]._links.self.href,                                                                       // 648
        enabled: spheresList[s].enabled,                                                                             // 649
        dataextracted: spheresList[s].dataextracted                                                                  // 650
      };                                                                                                             // 644
      self.added('spheresByUser', Random.id(), sphere);                                                              // 652
    }                                                                                                                // 653
  } catch (error) {                                                                                                  // 654
    console.log('Error in getSpheresByUser');                                                                        // 655
    console.log(error);                                                                                              // 656
  }                                                                                                                  // 657
  console.log('---------------------------------------------------');                                                // 658
  self.ready();                                                                                                      // 659
});                                                                                                                  // 660
                                                                                                                     //
Meteor.publish('getAttributesByProviders', function (providerNames) {                                                // 662
  var self = this;                                                                                                   // 663
  console.log('getAttributesByProviders');                                                                           // 664
  if (providerNames.length > 0) {                                                                                    // 665
    try {                                                                                                            // 666
      var url = host + slash + attrs + slash + search + slash + findAttributesByProviderNamesList + providerNames.toString();
      var response = HTTP.get(url, http_options);                                                                    // 668
      var content = JSON.parse(response.content);                                                                    // 669
      var attributes = content._embedded.attributes;                                                                 // 670
      for (a in attributes) {                                                                                        // 671
        var attribute = {                                                                                            // 672
          name: attributes[a].name,                                                                                  // 673
          category: attributes[a].categoryName,                                                                      // 674
          subcategory: attributes[a].subcategoryName,                                                                // 675
          enabled: attributes[a].enabled,                                                                            // 676
          link: attributes[a]._links.self.href                                                                       // 677
        };                                                                                                           // 672
        self.added('attributesByProviders', Random.id(), attribute);                                                 // 679
      }                                                                                                              // 680
    } catch (error) {                                                                                                // 683
      console.log('error in getAttributesByProviders');                                                              // 684
      console.log(error);                                                                                            // 685
    }                                                                                                                // 686
  }                                                                                                                  // 687
  console.log('---------------------------------------------------');                                                // 688
  self.ready();                                                                                                      // 689
});                                                                                                                  // 690
                                                                                                                     //
Meteor.publish('getConsumersByUser', function (consumersUrl) {                                                       // 692
  console.log('getConsumersByUser');                                                                                 // 693
  console.log(consumersUrl);                                                                                         // 694
  var self = this;                                                                                                   // 695
  if (consumersUrl != null) {                                                                                        // 696
    try {                                                                                                            // 697
      var response = HTTP.get(consumersUrl, http_options);                                                           // 698
      var content = JSON.parse(response.content);                                                                    // 699
      var consumers = content._embedded.consumers;                                                                   // 700
                                                                                                                     //
      _.each(consumers, function (consumer) {                                                                        // 702
        var consumerObject = {                                                                                       // 703
          name: consumer.name,                                                                                       // 704
          link: consumer._links.self.href,                                                                           // 705
          description: consumer.description                                                                          // 706
        };                                                                                                           // 703
        self.added('consumersByUser', Random.id(), consumerObject);                                                  // 708
      });                                                                                                            // 709
    } catch (error) {                                                                                                // 711
      console.log('Error in getConsumersByUser');                                                                    // 712
      console.log(error);                                                                                            // 713
    }                                                                                                                // 714
  }                                                                                                                  // 715
  console.log('---------------------------------------------------');                                                // 716
  self.ready();                                                                                                      // 717
});                                                                                                                  // 718
                                                                                                                     //
Meteor.publish('getRegisteredEmailsandRegisteredIds', function () {                                                  // 720
  console.log('getRegisteredEmailsandRegisteredIds');                                                                // 721
  var self = this;                                                                                                   // 722
  try {                                                                                                              // 723
    var url = host + slash + people;                                                                                 // 724
    var response = HTTP.get(url, http_options);                                                                      // 725
    var content = JSON.parse(response.content);                                                                      // 726
    var users = content._embedded.people;                                                                            // 727
                                                                                                                     //
    _.each(users, function (user) {                                                                                  // 729
      var email = { email: user.email };                                                                             // 730
      self.added('registeredEmails', Random.id(), email);                                                            // 731
      var personal_id = { personal_id: user.personal_id };                                                           // 732
      self.added('registeredIds', Random.id(), personal_id);                                                         // 733
    });                                                                                                              // 734
  } catch (error) {                                                                                                  // 735
    console.log('Error in getRegisteredEmailsandRegisteredIds');                                                     // 736
    console.log(error);                                                                                              // 737
  }                                                                                                                  // 738
  self.ready();                                                                                                      // 739
});                                                                                                                  // 741
                                                                                                                     //
Meteor.publish('getEntities', function () {                                                                          // 743
  console.log('getEntities');                                                                                        // 744
  var self = this;                                                                                                   // 745
  try {                                                                                                              // 746
    var url = host + slash + entities;                                                                               // 747
    var response = HTTP.get(url, http_options);                                                                      // 748
    var content = JSON.parse(response.content);                                                                      // 749
    var entitiesAPI = content._embedded.entities;                                                                    // 750
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 752
      var entityObject = {                                                                                           // 753
        name: entity.name,                                                                                           // 754
        description: entity.description,                                                                             // 755
        email: entity.email,                                                                                         // 756
        link: entity._links.self.href,                                                                               // 757
        identifier: entity.identifier                                                                                // 758
      };                                                                                                             // 753
      self.added('entities', Random.id(), entityObject);                                                             // 760
    });                                                                                                              // 761
  } catch (error) {                                                                                                  // 763
    console.log('Error in getEntities');                                                                             // 764
    console.log(error);                                                                                              // 765
  }                                                                                                                  // 766
  self.ready();                                                                                                      // 767
});                                                                                                                  // 768
                                                                                                                     //
// FOR USERS SCREENS                                                                                                 //
Meteor.publish('getEntitiesRequestedFromEntities', function (userEmail) {                                            // 772
  console.log('getEntitiesRequestedFromEntities');                                                                   // 773
  var self = this;                                                                                                   // 774
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
  try {                                                                                                              // 777
    var response = HTTP.get(url, http_options);                                                                      // 778
    var content = JSON.parse(response.content);                                                                      // 779
    var entitiesAPI = content._embedded.entities;                                                                    // 780
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 782
      var entityObject = {                                                                                           // 783
        name: entity.name,                                                                                           // 784
        description: entity.description,                                                                             // 785
        email: entity.email,                                                                                         // 786
        link: entity._links.self.href                                                                                // 787
      };                                                                                                             // 783
      self.added('entitiesRequestedFromEntities', Random.id(), entityObject);                                        // 789
    });                                                                                                              // 790
  } catch (error) {                                                                                                  // 791
    console.log('Error in getEntitiesRequestedFromEntities');                                                        // 792
    console.log(error);                                                                                              // 793
  }                                                                                                                  // 794
  self.ready();                                                                                                      // 795
});                                                                                                                  // 796
                                                                                                                     //
Meteor.publish('getEntitiesRequestedFromUsers', function (userEmail) {                                               // 798
  console.log('getEntitiesRequestedFromUsers');                                                                      // 799
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                     //
  var self = this;                                                                                                   // 803
  try {                                                                                                              // 804
    var response = HTTP.get(url, http_options);                                                                      // 805
    var content = JSON.parse(response.content);                                                                      // 806
    var entitiesAPI = content._embedded.entities;                                                                    // 807
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 809
      var entityObject = {                                                                                           // 810
        name: entity.name,                                                                                           // 811
        description: entity.description,                                                                             // 812
        email: entity.email,                                                                                         // 813
        link: entity._links.self.href                                                                                // 814
      };                                                                                                             // 810
      self.added('entitiesRequestedFromUsers', Random.id(), entityObject);                                           // 816
    });                                                                                                              // 817
  } catch (error) {                                                                                                  // 818
    console.log('Error in getEntitiesRequestedFromUsers');                                                           // 819
    console.log(error);                                                                                              // 820
  }                                                                                                                  // 821
  self.ready();                                                                                                      // 822
});                                                                                                                  // 823
                                                                                                                     //
Meteor.publish('getAdminEntities', function (userEmail) {                                                            // 825
  console.log('getAdminEntities');                                                                                   // 826
  var self = this;                                                                                                   // 827
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                     //
  try {                                                                                                              // 832
    var response = HTTP.get(url, http_options);                                                                      // 833
    var content = JSON.parse(response.content);                                                                      // 834
    var entitiesAPI = content._embedded.entities;                                                                    // 835
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 837
      var entityObject = {                                                                                           // 838
        name: entity.name,                                                                                           // 839
        description: entity.description,                                                                             // 840
        email: entity.email,                                                                                         // 841
        link: entity._links.self.href                                                                                // 842
      };                                                                                                             // 838
      self.added('adminEntities', Random.id(), entityObject);                                                        // 844
    });                                                                                                              // 845
  } catch (error) {                                                                                                  // 846
    console.log('Error in getAdminEntities');                                                                        // 847
    console.log(error);                                                                                              // 848
  }                                                                                                                  // 849
  self.ready();                                                                                                      // 850
});                                                                                                                  // 851
                                                                                                                     //
Meteor.publish('getEntitiesAssociated', function (userEmail) {                                                       // 853
  console.log('getEntitiesAssociated');                                                                              // 854
  var self = this;                                                                                                   // 855
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmailAndState + questionMark + 'email=' + userEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                     //
  try {                                                                                                              // 860
    var response = HTTP.get(url, http_options);                                                                      // 861
    var content = JSON.parse(response.content);                                                                      // 862
    var entitiesAPI = content._embedded.entities;                                                                    // 863
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 865
      var entityObject = {                                                                                           // 866
        name: entity.name,                                                                                           // 867
        description: entity.description,                                                                             // 868
        email: entity.email,                                                                                         // 869
        link: entity._links.self.href                                                                                // 870
      };                                                                                                             // 866
      self.added('entitiesAssociated', Random.id(), entityObject);                                                   // 872
    });                                                                                                              // 873
  } catch (error) {                                                                                                  // 874
    console.log('Error in getEntitiesAssociated');                                                                   // 875
    console.log(error);                                                                                              // 876
  }                                                                                                                  // 877
  self.ready();                                                                                                      // 878
});                                                                                                                  // 879
                                                                                                                     //
// Published called from entities screens                                                                            //
Meteor.publish('getUsersRequestedFromEntities', function (entityEmail) {                                             // 885
  console.log('getUsersRequestedFromEntities');                                                                      // 886
  var self = this;                                                                                                   // 887
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_ENTITY;
                                                                                                                     //
  try {                                                                                                              // 892
    var response = HTTP.get(url, http_options);                                                                      // 893
    var content = JSON.parse(response.content);                                                                      // 894
    var peopleAPI = content._embedded.people;                                                                        // 895
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 897
      var personObject = {                                                                                           // 898
        name: person.name,                                                                                           // 899
        surname: person.surname,                                                                                     // 900
        email: person.email,                                                                                         // 901
        link: person._links.self.href                                                                                // 902
      };                                                                                                             // 898
      self.added('usersRequestedFromEntities', Random.id(), personObject);                                           // 904
    });                                                                                                              // 905
  } catch (error) {                                                                                                  // 906
    console.log('Error in getUsersRequestedFromEntities');                                                           // 907
    console.log(error);                                                                                              // 908
  }                                                                                                                  // 909
  self.ready();                                                                                                      // 910
});                                                                                                                  // 911
                                                                                                                     //
Meteor.publish('getUsersRequestedFromUsers', function (entityEmail) {                                                // 913
  console.log('getUsersRequestedFromUsers');                                                                         // 914
  var self = this;                                                                                                   // 915
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + REQUESTED_FROM_USER;
                                                                                                                     //
  try {                                                                                                              // 920
    var response = HTTP.get(url, http_options);                                                                      // 921
    var content = JSON.parse(response.content);                                                                      // 922
    var peopleAPI = content._embedded.people;                                                                        // 923
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 925
      var personObject = {                                                                                           // 926
        name: person.name,                                                                                           // 927
        surname: person.surname,                                                                                     // 928
        email: person.email,                                                                                         // 929
        link: person._links.self.href                                                                                // 930
      };                                                                                                             // 926
      self.added('usersRequestedFromUsers', Random.id(), personObject);                                              // 932
    });                                                                                                              // 933
  } catch (error) {                                                                                                  // 934
    console.log('Error in getUsersRequestedFromUsers');                                                              // 935
    console.log(error);                                                                                              // 936
  }                                                                                                                  // 937
  self.ready();                                                                                                      // 938
});                                                                                                                  // 939
                                                                                                                     //
Meteor.publish('getAdminUsers', function (entityEmail) {                                                             // 941
  console.log('getAdminUsers');                                                                                      // 942
  var self = this;                                                                                                   // 943
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ADMINISTRATOR;
                                                                                                                     //
  try {                                                                                                              // 948
    var response = HTTP.get(url, http_options);                                                                      // 949
    var content = JSON.parse(response.content);                                                                      // 950
    var peopleAPI = content._embedded.people;                                                                        // 951
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 953
      var personObject = {                                                                                           // 954
        name: person.name,                                                                                           // 955
        surname: person.surname,                                                                                     // 956
        email: person.email,                                                                                         // 957
        link: person._links.self.href                                                                                // 958
      };                                                                                                             // 954
      self.added('adminUsers', Random.id(), personObject);                                                           // 960
    });                                                                                                              // 961
  } catch (error) {                                                                                                  // 962
    console.log('Error in getAdminUsers');                                                                           // 963
    console.log(error);                                                                                              // 964
  }                                                                                                                  // 965
  self.ready();                                                                                                      // 966
});                                                                                                                  // 967
                                                                                                                     //
Meteor.publish('getUsersAssociated', function (entityEmail) {                                                        // 969
  console.log('getUsersAssociated');                                                                                 // 970
  var self = this;                                                                                                   // 971
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmailAndState + questionMark + 'email=' + entityEmail + ampersand + 'state=' + ASSOCIATED;
                                                                                                                     //
  try {                                                                                                              // 976
    var response = HTTP.get(url, http_options);                                                                      // 977
    var content = JSON.parse(response.content);                                                                      // 978
    var peopleAPI = content._embedded.people;                                                                        // 979
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 981
      var personObject = {                                                                                           // 982
        name: person.name,                                                                                           // 983
        description: person.description,                                                                             // 984
        email: person.email,                                                                                         // 985
        link: person._links.self.href                                                                                // 986
      };                                                                                                             // 982
      self.added('usersAssociated', Random.id(), personObject);                                                      // 988
    });                                                                                                              // 989
  } catch (error) {                                                                                                  // 990
    console.log('Error in getUsersAssociated');                                                                      // 991
    console.log(error);                                                                                              // 992
  }                                                                                                                  // 993
  self.ready();                                                                                                      // 994
});                                                                                                                  // 995
                                                                                                                     //
Meteor.publish('getEntitiesWithRelationship', function (userEmail) {                                                 // 997
  console.log('getEntitiesWithRelationship');                                                                        // 998
  var self = this;                                                                                                   // 999
                                                                                                                     //
  var url = host + slash + entities + slash + search + slash + findEntitiesByPersonEmail + questionMark + 'email=' + userEmail;
  try {                                                                                                              // 1003
    var response = HTTP.get(url, http_options);                                                                      // 1004
    var content = JSON.parse(response.content);                                                                      // 1005
    var entitiesAPI = content._embedded.entities;                                                                    // 1006
                                                                                                                     //
    _.each(entitiesAPI, function (entity) {                                                                          // 1008
      var entityObject = {                                                                                           // 1009
        name: entity.name,                                                                                           // 1010
        description: entity.description,                                                                             // 1011
        email: entity.email,                                                                                         // 1012
        link: entity._links.self.href                                                                                // 1013
      };                                                                                                             // 1009
      self.added('entitiesWithRelationship', Random.id(), entityObject);                                             // 1015
    });                                                                                                              // 1016
  } catch (error) {                                                                                                  // 1017
    console.log('Error in getEntitiesWithRelationship');                                                             // 1018
    console.log(error);                                                                                              // 1019
  }                                                                                                                  // 1020
  self.ready();                                                                                                      // 1021
});                                                                                                                  // 1022
                                                                                                                     //
Meteor.publish('getPeople', function () {                                                                            // 1025
  console.log('getPeople');                                                                                          // 1026
  var self = this;                                                                                                   // 1027
  try {                                                                                                              // 1028
    var url = host + slash + people;                                                                                 // 1029
    var response = HTTP.get(url, http_options);                                                                      // 1030
    var content = JSON.parse(response.content);                                                                      // 1031
    var peopleAPI = content._embedded.people;                                                                        // 1032
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1034
      var personObject = {                                                                                           // 1035
        name: person.name,                                                                                           // 1036
        email: person.email,                                                                                         // 1037
        link: person._links.self.href                                                                                // 1038
      };                                                                                                             // 1035
      self.added('people', Random.id(), personObject);                                                               // 1040
    });                                                                                                              // 1041
  } catch (error) {                                                                                                  // 1043
    console.log('Error in getPeople');                                                                               // 1044
    console.log(error);                                                                                              // 1045
  }                                                                                                                  // 1046
  self.ready();                                                                                                      // 1047
});                                                                                                                  // 1048
                                                                                                                     //
Meteor.publish('getPeopleWithRelationship', function (entityEmail) {                                                 // 1050
  console.log('getPeopleWithRelationship');                                                                          // 1051
  var self = this;                                                                                                   // 1052
                                                                                                                     //
  var url = host + slash + people + slash + search + slash + findPeopleByEntityEmail + questionMark + 'email=' + entityEmail;
                                                                                                                     //
  try {                                                                                                              // 1057
    var response = HTTP.get(url, http_options);                                                                      // 1058
    var content = JSON.parse(response.content);                                                                      // 1059
    var peopleAPI = content._embedded.people;                                                                        // 1060
                                                                                                                     //
    _.each(peopleAPI, function (person) {                                                                            // 1062
      var personObject = {                                                                                           // 1063
        name: person.name,                                                                                           // 1064
        description: person.description,                                                                             // 1065
        email: person.email,                                                                                         // 1066
        link: person._links.self.href                                                                                // 1067
      };                                                                                                             // 1063
      self.added('peopleWithRelationship', Random.id(), personObject);                                               // 1069
    });                                                                                                              // 1070
  } catch (error) {                                                                                                  // 1071
    console.log('Error in getPeopleWithRelationship');                                                               // 1072
    console.log(error);                                                                                              // 1073
  }                                                                                                                  // 1074
  self.ready();                                                                                                      // 1075
});                                                                                                                  // 1076
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"constants.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/constants.js                                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*                                                                                                                   //
* CONSTANTS                                                                                                          //
*/                                                                                                                   //
                                                                                                                     //
/*host = 'http://localhost:8080';*/                                                                                  //
host = 'http://172.20.10.216:9763/LmpApi/';                                                                          // 6
slash = '/';                                                                                                         // 7
people = 'people';                                                                                                   // 8
person = 'person';                                                                                                   // 9
consumers = 'consumers';                                                                                             // 10
spheres = 'spheres';                                                                                                 // 11
providers = 'providers';                                                                                             // 12
entities = 'entities';                                                                                               // 13
providerTokens = 'providerTokens';                                                                                   // 14
                                                                                                                     //
emailParameter = "email=";                                                                                           // 16
providerNameParameter = 'providerName=';                                                                             // 17
providerParameter = 'provider=';                                                                                     // 18
userParameter = 'user=';                                                                                             // 19
                                                                                                                     //
attrs = 'attributes';                                                                                                // 21
search = 'search';                                                                                                   // 22
                                                                                                                     //
findByIdentifier = 'findByIdentifier?identifier=';                                                                   // 24
findByEmail = 'findFirstByEmail?email=';                                                                             // 25
findCategoriesByProviderNamesList = 'findCategoriesByProviderNamesList?providerNames=';                              // 26
findAttributesByProviderNamesList = 'findAttributesByProviderNamesList?names=';                                      // 27
findAttributesByProviderName = 'findAttributesByProviderName?name=';                                                 // 28
findByproviderNameAndUserEmail = 'findByproviderNameAndUserEmail';                                                   // 29
                                                                                                                     //
findEntitiesByPersonEmailAndState = 'findEntitiesByPersonEmailAndState';                                             // 32
findPeopleByEntityEmailAndState = 'findPeopleByEntityEmailAndState';                                                 // 33
findPersonEntityRelationshipByEntityEmailAndPersonEmail = 'findPersonEntityRelationshipByEntityEmailAndPersonEmail';
findPersonEntityRelationshipsByEntityEmail = 'findPersonEntityRelationshipsByEntityEmail';                           // 35
findEntitiesByPersonEmail = 'findEntitiesByPersonEmail';                                                             // 36
findPeopleByEntityEmail = 'findPeopleByEntityEmail';                                                                 // 37
                                                                                                                     //
personEntityRelationships = 'personEntityRelationships';                                                             // 39
                                                                                                                     //
createNewToken = 'createNewToken';                                                                                   // 41
                                                                                                                     //
questionMark = '?';                                                                                                  // 43
                                                                                                                     //
ampersand = '&';                                                                                                     // 45
                                                                                                                     //
basic_auth = 'web@hotmail.com:EurecatLMP2016!';                                                                      // 47
                                                                                                                     //
REQUESTED_FROM_ENTITY = 'REQUESTED_FROM_ENTITY';                                                                     // 49
REQUESTED_FROM_USER = 'REQUESTED_FROM_USER';                                                                         // 50
ASSOCIATED = 'ASSOCIATED';                                                                                           // 51
ADMINISTRATOR = 'ADMINISTRATOR';                                                                                     // 52
                                                                                                                     //
// Environment variables                                                                                             //
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';                                                                      // 56
                                                                                                                     //
http_options = { auth: basic_auth };                                                                                 // 58
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/routes.js");
require("./server/LMP.js");
require("./server/constants.js");
//# sourceMappingURL=app.js.map
