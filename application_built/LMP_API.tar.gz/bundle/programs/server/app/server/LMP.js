(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/LMP.js                                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
/*                                                                     //
* CONSTANTS                                                            //
*/                                                                     //
                                                                       //
/*localhost = 'http://localhost:8080';*/                               //
localhost = 'https://bd-vm-d-wso2as:9443/LmpApi';                      // 7
slash = '/';                                                           // 8
people = 'people';                                                     // 9
person = 'person';                                                     // 10
consumers = 'consumers';                                               // 11
spheres = 'spheres';                                                   // 12
providers = 'providers';                                               // 13
search = 'search';                                                     // 14
findByIdentifier = 'findByIdentifier?identifier=';                     // 15
findByEmail = 'findFirstByEmail?email=';                               // 16
findCategoriesByProviderNamesList = 'findCategoriesByProviderNamesList?providerNames=';
findAttributesByProviderNamesList = 'findAttributesByProviderNamesList?providerNames=';
                                                                       //
// Environment variables                                               //
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';                        // 22
                                                                       //
Meteor.methods({                                                       // 25
                                                                       //
  /*  'getUserId' : function(){                                        //
      return Meteor.userId();                                          //
    },*/                                                               //
  'upsertSphere': function (sphereObject, httpCommand) {               // 30
    /*    Spheres.upsert({                                             //
          //Query                                                      //
          _id: sphereObject.sphereId                                   //
        }, {                                                           //
          //Modifier                                                   //
          $set: {                                                      //
            userId :            Meteor.userId(),                       //
            label :             sphereObject.label,                    //
            description :       sphereObject.description,              //
            consumers :         sphereObject.consumers,                //
            createdAt :         sphereObject.createdAt,                //
            checkedAttributes:  sphereObject.checkedAttributes,        //
            enabled:            sphereObject.enabled                   //
          }                                                            //
        });*/                                                          //
                                                                       //
    if (httpCommand == 'POST') {                                       // 47
      var url = localhost + slash + spheres;                           // 48
      var response = HTTP.post(url, {                                  // 49
        data: {                                                        // 50
          identifier: sphereObject.identifier,                         // 51
          name: sphereObject.name,                                     // 52
          description: sphereObject.description,                       // 53
          type: sphereObject.type,                                     // 54
          isEnabled: sphereObject.isEnabled,                           // 55
          isDeleted: sphereObject.isDeleted                            // 56
        }                                                              //
      });                                                              //
      return response;                                                 // 59
    } else {                                                           //
      var response = HTTP.put(sphereObject.url, {                      // 62
        data: {                                                        // 63
          identifier: sphereObject.identifier,                         // 64
          name: sphereObject.name,                                     // 65
          description: sphereObject.description,                       // 66
          type: sphereObject.type,                                     // 67
          isEnabled: sphereObject.isEnabled,                           // 68
          isDeleted: sphereObject.isDeleted                            // 69
        }                                                              //
      });                                                              //
      return response;                                                 // 72
    }                                                                  //
  },                                                                   //
                                                                       //
  'joinSphereAndConsumer': function (sphereConsumerUrl, consumersUrl) {
    var urlConsumersString = '';                                       // 79
    for (url in babelHelpers.sanitizeForInObject(consumersUrl)) {      // 80
      urlConsumersString += consumersUrl[url] + '\n';                  // 81
    }                                                                  //
                                                                       //
    return HTTP.put(sphereConsumerUrl, {                               // 84
      headers: {                                                       // 85
        "Content-Type": "text/uri-list"                                // 86
      },                                                               //
      content: urlConsumersString                                      // 88
    });                                                                //
  },                                                                   //
                                                                       //
  'joinSphereAndAttributes': function (sphereAttributesUrl, attributesUrl) {
                                                                       //
    console.log(attributesUrl);                                        // 94
    console.log(sphereAttributesUrl);                                  // 95
    var urlAttributesString = '';                                      // 96
    for (url in babelHelpers.sanitizeForInObject(attributesUrl)) {     // 97
      urlAttributesString += attributesUrl[url] + '\n';                // 98
    }                                                                  //
                                                                       //
    return HTTP.put(sphereAttributesUrl, {                             // 101
      headers: {                                                       // 102
        "Content-Type": "text/uri-list"                                // 103
      },                                                               //
      content: urlAttributesString                                     // 105
    });                                                                //
  },                                                                   //
                                                                       //
  'upsertProvider': function (providerObject) {                        // 110
    /*    Providers.upsert({                                           //
          _id: providerObject.providerId                               //
        }, {                                                           //
          $set: {                                                      //
            userId:             Meteor.userId(),                       //
            name:               providerObject.name,                   //
            description:        providerObject.description,            //
            url:                providerObject.url,                    //
            attributes:         providerObject.attributes,             //
            createdAt:          providerObject.createdAt,              //
            checkedAttributes:  providerObject.checkedAttributes,      //
            enabled:            providerObject.enabled                 //
          }                                                            //
        });*/                                                          //
                                                                       //
    /*    var url = localhost + slash + providers;                     //
        var response = HTTP.post(url, {                                //
          data: {                                                      //
            identifier:         providerObject.identifier,             //
            name:               providerObject.name,                   //
            description:        providerObject.description,            //
            url:                providerObject.url,                    //
            isEnabled:          providerObject.isEnabled,              //
            isDeleted:          providerObject.isDeleted               //
          }                                                            //
        });                                                            //
                                                                       //
        var urlNewProvider = response.headers.location;                //
                                                                       //
        var urlAssociation = urlNewProvider + slash + person;          //
        console.log('urlAssociation: ' + urlAssociation);              //
        console.log('urlPerson: ' + urlPerson)                         //
                                                                       //
        var response2 = HTTP.put(urlAssociation, {                     //
          headers: {                                                   //
            "Content-Type":       "text/uri-list"                      //
          },                                                           //
          content: urlPerson                                           //
        });                                                            //
        return response;*/                                             //
                                                                       //
    /*    var url = localhost + slash + providers;                     //
        var response = HTTP.post(url, {                                //
          data: {                                                      //
            identifier:         providerObject.identifier,             //
            name:               providerObject.name,                   //
            description:        providerObject.description,            //
            url:                providerObject.url,                    //
            enabled:            providerObject.isEnabled,              //
            deleted:            providerObject.isDeleted,              //
            person:             urlPerson                              //
          }                                                            //
        });*/                                                          //
                                                                       //
    // TODO: SE TENDRÁ UNA LISTA DE PROVEEDORES. CUANDO ESTA LISTA ESTÉ LISTA, SE ELEGIRÁ UN PROVEEDOR
    // Y ESE QUEDARÁ VINCULADO AL USUARIO QUE HA HECHO ESA ACCIÓN. LA ACCIÓN QUEDARÁ ASOCIADA CON EL MÉTODO PUT
    // SIGUIENDO ESTA RESPUESTA: http://stackoverflow.com/questions/17981252/how-to-update-reference-object-in-spring-data-rest?rq=1
                                                                       //
    var url = localhost + slash + providers;                           // 169
    var response = HTTP.post(url, {                                    // 170
      data: {                                                          // 171
        identifier: providerObject.identifier,                         // 172
        name: providerObject.name,                                     // 173
        description: providerObject.description,                       // 174
        url: providerObject.url,                                       // 175
        isEnabled: providerObject.isEnabled,                           // 176
        isDeleted: providerObject.isDeleted                            // 177
      }                                                                //
    });                                                                //
    return response;                                                   // 180
  },                                                                   //
                                                                       //
  'joinPersonAndProvider': function (urlProviderPerson, urlProviders) {
                                                                       //
    var urlProvidersString = '';                                       // 185
    for (url in babelHelpers.sanitizeForInObject(urlProviders)) {      // 186
      urlProvidersString += urlProviders[url] + '\n';                  // 187
    }                                                                  //
                                                                       //
    return HTTP.put(urlProviderPerson, {                               // 190
      headers: {                                                       // 191
        "Content-Type": "text/uri-list"                                // 192
      },                                                               //
      content: urlProvidersString                                      // 194
    });                                                                //
  },                                                                   //
                                                                       //
  'joinPersonAndConsumer': function (urlConsumerPerson, urlConsumers) {
                                                                       //
    var urlConsumersString = '';                                       // 200
    for (url in babelHelpers.sanitizeForInObject(urlConsumers)) {      // 201
      urlConsumersString += urlConsumers[url] + '\n';                  // 202
    }                                                                  //
                                                                       //
    return HTTP.put(urlConsumerPerson, {                               // 205
      headers: {                                                       // 206
        "Content-Type": "text/uri-list"                                // 207
      },                                                               //
      content: urlConsumersString                                      // 209
    });                                                                //
  },                                                                   //
                                                                       //
  'joinPersonAndSphere': function (urlSpherePerson, urlSpheres) {      // 213
    var urlSpheresString = '';                                         // 214
    for (url in babelHelpers.sanitizeForInObject(urlSpheres)) {        // 215
      urlSpheresString += urlSpheres[url] + '\n';                      // 216
    }                                                                  //
                                                                       //
    return HTTP.put(urlSpherePerson, {                                 // 219
      headers: {                                                       // 220
        "Content-Type": "text/uri-list"                                // 221
      },                                                               //
      content: urlSpheresString                                        // 223
    });                                                                //
  },                                                                   //
                                                                       //
  'upsertConsumer': function (consumerObject) {                        // 227
    var url = localhost + slash + consumers;                           // 228
    var response = HTTP.post(url, {                                    // 229
      data: {                                                          // 230
        identifier: consumerObject.identifier,                         // 231
        name: consumerObject.name,                                     // 232
        description: consumerObject.description,                       // 233
        isEnabled: consumerObject.isEnabled,                           // 234
        isDeleted: consumerObject.isDeleted                            // 235
      }                                                                //
    });                                                                //
    return response;                                                   // 238
  },                                                                   //
                                                                       //
  'updateSphereEnabled': function (enabledObject) {                    // 241
    Spheres.update({                                                   // 242
      _id: enabledObject.documentId                                    // 244
    }, {                                                               //
      $set: {                                                          // 246
        enabled: enabledObject.isEnabled                               // 247
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  'registerUser': function (personObject) {                            // 252
    var _id = Meteor.userId();                                         // 253
    var url = localhost + slash + people + slash;                      // 254
    var response = HTTP.post(url, {                                    // 255
      data: {                                                          // 256
        identifier: _id,                                               // 257
        name: personObject.name,                                       // 258
        surname: personObject.surname,                                 // 259
        email: personObject.email,                                     // 260
        password: personObject.password                                // 261
      }                                                                //
    }, function (error, response) {                                    //
      if (error) {                                                     // 264
        console.log('Error: ' + error);                                // 265
      } else {                                                         //
        console.log('User added correctly!');                          // 267
        console.log(response);                                         // 268
      }                                                                //
    });                                                                //
  },                                                                   //
                                                                       //
  'loginWithPassword': function (loginObject) {                        // 273
    var url = localhost + slash + people + slash + search + slash + findByEmail + loginObject.email;
    try {                                                              // 275
      console.log(url);                                                // 276
                                                                       //
      var response = HTTP.get(url);                                    // 278
                                                                       //
      console.log(response);                                           // 280
                                                                       //
      var user = JSON.parse(response.content);                         // 282
                                                                       //
      console.log(user);                                               // 284
                                                                       //
      if (user == undefined || user == null) {                         // 286
        throw new Meteor.Error('404', 'User not found', 'User not found in the Database');
      }                                                                //
                                                                       //
      return user;                                                     // 290
    } catch (error) {                                                  //
      console.log('Error while authenticating the user... ' + error);  // 292
      throw new Meteor.Error('404', 'User not found', 'User not found in the Database');
    }                                                                  //
  },                                                                   //
                                                                       //
  'getConsumersbyPerson': function (consumersUrl) {                    // 297
    try {                                                              // 298
      var response = HTTP.get(consumersUrl);                           // 299
      var content = JSON.parse(response.content);                      // 300
      var consumersList = content._embedded.consumers;                 // 301
      return consumersList;                                            // 302
    } catch (error) {                                                  //
      console.log(error);                                              // 304
    }                                                                  //
    return [];                                                         // 306
  },                                                                   //
                                                                       //
  'getConsumers': function () {                                        // 309
    var url = localhost + slash + consumers;                           // 310
    var consumersList;                                                 // 311
    try {                                                              // 312
      var response = HTTP.get(url);                                    // 313
      var content = JSON.parse(response.content);                      // 314
      consumersList = content._embedded.consumers;                     // 315
    } catch (error) {                                                  //
      console.log(error);                                              // 318
    }                                                                  //
    return consumersList;                                              // 320
  },                                                                   //
                                                                       //
  'getProvidersbyPerson': function (providersUrl) {                    // 323
    try {                                                              // 324
      var response = HTTP.get(providersUrl);                           // 325
      var content = JSON.parse(response.content);                      // 326
      var providersList = content._embedded.providers;                 // 327
      return providersList;                                            // 328
    } catch (error) {                                                  //
      console.log(error);                                              // 330
    }                                                                  //
    return [];                                                         // 332
  },                                                                   //
                                                                       //
  'getSpheresByPerson': function (spheresUrl) {                        // 335
    try {                                                              // 336
      var response = HTTP.get(spheresUrl);                             // 337
      var content = JSON.parse(response.content);                      // 338
      var spheresList = content._embedded.spheres;                     // 339
      return spheresList;                                              // 340
    } catch (error) {                                                  //
      console.log(error);                                              // 342
    }                                                                  //
    return [];                                                         // 344
  },                                                                   //
                                                                       //
  'getProviders': function () {                                        // 347
    var url = localhost + slash + providers;                           // 348
    var providersList;                                                 // 349
    try {                                                              // 350
      var response = HTTP.get(url);                                    // 351
      var content = JSON.parse(response.content);                      // 352
      providersList = content._embedded.providers;                     // 353
    } catch (error) {                                                  //
      console.log(error);                                              // 356
    }                                                                  //
    return providersList;                                              // 358
  },                                                                   //
                                                                       //
  'getSpheres': function () {                                          // 361
    var url = localhost + slash + spheres;                             // 362
    try {                                                              // 363
      var response = HTTP.get(url);                                    // 364
      var content = JSON.parse(response.content);                      // 365
      spheresList = content._embedded.spheres;                         // 366
      return spheresList;                                              // 367
    } catch (error) {                                                  //
      console.log(error);                                              // 369
    }                                                                  //
    return '';                                                         // 371
  },                                                                   //
                                                                       //
  'getSphere': function (sphereUrl) {                                  // 374
    try {                                                              // 375
      var response = HTTP.get(sphereUrl);                              // 376
      var content = JSON.parse(response.content);                      // 377
      return content;                                                  // 378
    } catch (error) {                                                  //
      console.log(error);                                              // 380
    }                                                                  //
    return '';                                                         // 382
  },                                                                   //
                                                                       //
  'getConsumersInSphere': function (sphereConsumersUrl) {              // 385
    try {                                                              // 386
      var response = HTTP.get(sphereConsumersUrl);                     // 387
      var content = JSON.parse(response.content);                      // 388
      var consumers = content._embedded.consumers;                     // 389
      return consumers;                                                // 390
    } catch (error) {                                                  //
      console.log(error);                                              // 392
    }                                                                  //
    return [];                                                         // 394
  },                                                                   //
                                                                       //
  'getCategoriesByProviders': function (providerNames) {               // 397
    var url = localhost + slash + providers + slash + search + slash + findCategoriesByProviderNamesList + providerNames;
    try {                                                              // 399
      var response = HTTP.get(url);                                    // 400
      var content = JSON.parse(response.content);                      // 401
      var attributeCategories = content._embedded.attributeCategories;
      return attributeCategories;                                      // 403
    } catch (error) {                                                  //
      console.log(error);                                              // 405
    }                                                                  //
  },                                                                   //
                                                                       //
  'getAttributesByProviders': function (providerNames) {               // 409
    var url = localhost + slash + providers + slash + search + slash + findAttributesByProviderNamesList + providerNames;
    try {                                                              // 411
      var response = HTTP.get(url);                                    // 412
      var content = JSON.parse(response.content);                      // 413
      var attributes = content._embedded.attributes;                   // 414
      return attributes;                                               // 415
    } catch (error) {                                                  //
      console.log(error);                                              // 417
    }                                                                  //
  },                                                                   //
                                                                       //
  'getAttributesBySphere': function (sphereAttributesUrl) {            // 421
    try {                                                              // 422
      var response = HTTP.get(sphereAttributesUrl);                    // 423
      var content = JSON.parse(response.content);                      // 424
      var attributes = content._embedded.attributes;                   // 425
      return attributes;                                               // 426
    } catch (error) {                                                  //
      console.log(error);                                              // 428
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/*Meteor.publish('getProviders', function(){                           //
  return Providers.find({userId: this.userId}, { sort: {createdAt: 1} });
});                                                                    //
                                                                       //
Meteor.publish('getSpheres', function(){                               //
  return Spheres.find({userId: this.userId}, { sort: {createdAt: 1} });
});                                                                    //
                                                                       //
Meteor.publish('getSphereById', function(sphereId){                    //
  return Spheres.find({_id: sphereId});                                //
});*/                                                                  //
                                                                       //
/*Meteor.publish('getConsumers', function(){                           //
  //return Consumers.find({userId: this.userId}, { sort: {createdAt: 1} });
  //return Consumers.find();                                           //
                                                                       //
/*  var self = this;                                                   //
  var userId = this.userId;                                            //
  try {                                                                //
    var url = localhost + slash + people + slash + search + slash + findByIdentifier + userId;
    console.log(url);*/                                                //
                                                                       //
/*    var options = {                                                  //
        headers: {'Content-Type': 'application/json'}                  //
      }                                                                //
                                                                       //
    var response = HTTP.call('GET', url, options, function(error, response){
      if (error) {                                                     //
        console.log(error);                                            //
      } else {                                                         //
        console.log(response)                                          //
        var content = response.content;                                //
        var json = JSON.parse(content);                                //
        console.log(typeof json);                                      //
        console.log(json.surname);                                     //
      }                                                                //
    });*/                                                              //
                                                                       //
/*    var response = HTTP.get(url);                                    //
                                                                       //
    var content = JSON.parse(response.content);                        //
                                                                       //
    var consumersLink = content._links.consumers.href;                 //
    console.log(consumersLink);*/                                      //
                                                                       //
/*  } catch (error) {                                                  //
    console.log(error);                                                //
  }*/                                                                  //
                                                                       //
/*  var url = localhost + slash + consumers;                           //
  HTTP.call('GET', url, {}, function(error, response){                 //
    if(error){                                                         //
      console.log(error);                                              //
    } else {                                                           //
      var content = JSON.parse(response.content);                      //
      return content;                                                  //
    }                                                                  //
  });                                                                  //
  return {};                                                           //
});*/                                                                  //
                                                                       //
/*Meteor.publish('getAttributesDefinition', function(){                //
  return AttributesDefinition.find();                                  //
});                                                                    //
                                                                       //
Meteor.publish('getAttributes', function(){                            //
  return Attributes.find();                                            //
});                                                                    //
                                                                       //
Meteor.publish('getProviderById', function(providerId){                //
  return Providers.find({_id: providerId});                            //
});                                                                    //
                                                                       //
Meteor.publish('getAttributesFromProvider', function(providerName){    //
  return Attributes.find({serviceProvider: providerName});             //
});*/                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=LMP.js.map
